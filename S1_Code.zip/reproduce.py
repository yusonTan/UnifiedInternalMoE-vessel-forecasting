"""Portable review entry point. No historical Windows path is needed by this CLI."""
from pathlib import Path
import argparse,csv,hashlib,json,math,statistics,sys
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'source_snapshot'))

def readrows(p):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rr):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024**2),b''):h.update(b)
 return h.hexdigest()
def verify(args):
 manifest=BASE/args.manifest
 entries=json.loads(manifest.read_text(encoding='utf-8'))['files'];bad=[]
 for r in entries:
  p=BASE/r['path']
  if not p.is_file() or digest(p)!=r['sha256']:bad.append(r['path'])
 print(json.dumps({'checked':len(entries),'mismatches':bad}));return int(bool(bad))
def tables(args):
 specs={
  'main10':('four_domain_10seed_per_seed.csv','four_domain_10seed_mean_std.csv',('domain','model')),
  'independent5':('independent_per_seed.csv','independent_mean_std.csv',('mode','source','model')),
  'capacity10':('capacity_per_seed.csv','capacity_mean_std.csv',('domain','model')),
  'internal5':('internal_per_seed.csv','internal_mean_std.csv',('family','domain','model')),
 }
 checks=[]
 for suite,(per,summary,keys) in specs.items():
  rr=readrows(BASE/'results'/suite/per);expected=readrows(BASE/'results'/suite/summary);rebuilt=[];worst=0.
  for row in expected:
   group=[r for r in rr if all(r[k]==row[k] for k in keys)];assert group,(suite,row)
   new={k:row[k] for k in keys};new['n_seeds']=len(group)
   for col,value in row.items():
    if not col.endswith('_mean'):continue
    m=col[:-5]
    if m not in group[0]:continue
    values=[float(r[m]) for r in group];mean=statistics.mean(values);sd=statistics.stdev(values)
    new[m+'_mean']=mean;new[m+'_std']=sd
    worst=max(worst,abs(mean-float(value)),abs(sd-float(row[m+'_std'])))
   rebuilt.append(new)
  write(Path(args.out)/f'{suite}_recomputed.csv',rebuilt)
  checks.append({'suite':suite,'rows':len(rebuilt),'max_abs_error':worst,'passed':worst<1e-6})
 print(json.dumps(checks,indent=2));return int(not all(x['passed'] for x in checks))
def external(args):
 import numpy as np
 rr=readrows(BASE/'results/independent5/independent_per_seed.csv');worst=0.
 for r in rr:
  p=BASE/'independent_predictions'/r['mode']/r['source']/('seed_'+r['seed'])/(r['model']+'.npz')
  with np.load(p) as z:
   d=np.linalg.norm(z['prediction'].astype(float)-z['target'].astype(float),axis=-1)
   for h in (5,10,20,30,45,60):
    for name,value in [('ADE',d[:,:3*h].mean()),('FDE',d[:,3*h-1].mean())]:worst=max(worst,abs(value-float(r[f'{name}@{h}'])))
 print(json.dumps({'prediction_groups':len(rr),'max_abs_metric_error_m':float(worst),'passed':bool(worst<1e-6)}));return int(worst>=1e-6)
def smoke(args):
 import numpy as np,torch
 from amf.unified_predictor import UnifiedInternalMoE
 from amf.data import RobustTrajectoryScaler
 torch.set_num_threads(2);torch.manual_seed(42)
 model=UnifiedInternalMoE().eval();x=torch.zeros(2,90,6)
 with torch.inference_mode():p,aux=model(x,return_aux=True)
 assert p.shape==(2,180,2) and torch.isfinite(p).all()
 difference=float((p-aux['internal_candidates'].mean(1)).abs().max())
 assert difference<1e-4
 print(json.dumps({'synthetic_only':True,'shape':list(p.shape),'uniform_initial_fusion_difference':difference,'torch':torch.__version__,'CUDA_available':torch.cuda.is_available()}));return 0
def infer(args):
 import numpy as np,torch
 from amf.unified_predictor import UnifiedInternalMoE
 from amf.data import RobustTrajectoryScaler
 torch.set_num_threads(4);device=torch.device(args.device)
 folder=BASE/'checkpoints'/args.domain/f'seed_{args.seed}'
 model=UnifiedInternalMoE().to(device).eval();model.load_state_dict(torch.load(folder/'best.pt',map_location='cpu',weights_only=False)['model'],strict=True)
 scaler=RobustTrajectoryScaler.load(folder/'scaler.json')
 path=Path(args.history) if args.history else BASE/'replay_inputs'/args.domain/'history.npy'
 h=np.load(path,mmap_mode='r');n=min(args.limit,len(h)) if args.limit else len(h);pp=[]
 with torch.inference_mode():
  for i in range(0,n,args.batch):pp.append(scaler.inverse_positions(model(torch.from_numpy(scaler.transform_history(np.asarray(h[i:min(i+args.batch,n)])).copy()).to(device)).cpu().numpy()))
 dest=Path(args.out);dest.parent.mkdir(parents=True,exist_ok=True);np.save(dest,np.concatenate(pp));print(json.dumps({'output':str(dest),'windows':n}));return 0
def train_one(args):
 import shutil,numpy as np,torch
 from torch.utils.data import DataLoader
 import external_ais_common as common
 import external_ais_train as training
 from amf.data import EnvShipDataset,RobustTrajectoryScaler
 cfg=json.loads(Path(args.config).read_text(encoding='utf-8-sig'));out=Path(args.out).resolve();cache=Path(args.cache).resolve()
 if not torch.cuda.is_available():raise RuntimeError('Original training requires CUDA; no silent CPU substitution.')
 if args.model=='sa_repair' and args.stage not in ('pretrain','repair'):raise ValueError('SA needs --stage pretrain or repair')
 common.OUT=out;(out/'cache').mkdir(parents=True,exist_ok=True)
 def split_path(s):
  if (cache/s/'history.npy').exists():return cache/s
  options=list(cache.glob('*_'+s))
  if len(options)!=1:raise ValueError('Supply a single-domain cache directory with train/val or domain_train/domain_val children.')
  return options[0]
 scaler=RobustTrajectoryScaler.fit(np.load(split_path('train')/'history.npy',mmap_mode='r'),np.load(split_path('train')/'future.npy',mmap_mode='r'));scaler.save(out/'cache/scaler.json')
 original=training.spec(args.model,args.stage)
 if 'training_protocol' in cfg:spec=cfg['training_protocol']
 else:
  spec={**original,'epochs':cfg.get('epochs',original['epochs']),'patience':cfg.get('patience',original['patience']),
        'lr':cfg.get('learning_rate',original['lr']),'batch_size':cfg.get('batch_size',original['batch_size']),
        'minimum_lr':cfg.get('min_learning_rate',cfg.get('minimum_learning_rate',original['minimum_lr'])),
        'repair_seconds':cfg.get('max_training_seconds',original.get('repair_seconds',0))}
 training.spec=lambda name,stage='train':spec
 def loaders(scaler,batch,smoke=False):
  return {s:DataLoader(EnvShipDataset(split_path(s),scaler),batch_size=batch,shuffle=s=='train',num_workers=0,pin_memory=True) for s in ('train','val')}
 training.loaders=loaders
 if args.model=='sa_repair' and args.stage=='repair':
  if not args.pretrained:raise ValueError('--pretrained is required for SA repair')
  p=training.run_dir('sa_repair',args.seed,'pretrain')/'best.pt';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(args.pretrained,p)
 if args.model=='sa_repair':training.train_sa(args.seed,args.stage)
 else:training.train_comparator(args.model,args.seed)
 print('Training finished. Legacy stage test files are validation proxies; no formal test was evaluated.')
 return 0
def prepare_envship(args):
 import shutil
 from amf.data import resolve_split_file,build_cache
 for domain in ('dma','noaa','norway','piraeus'):
  for split in ('train','val','test'):
   produced=build_cache(resolve_split_file(Path(args.data),domain,split),Path(args.out)/domain)
   canonical=Path(args.out)/domain/(domain+'_'+split)
   if produced!=canonical:
    if canonical.exists():raise FileExistsError('Canonical output already exists: '+str(canonical))
    produced.rename(canonical)
   print(canonical)
 return 0
def prepare_finland(args):
 import shutil
 import external_ais_common as common
 import external_ais_prepare as prepare
 common.OUT=Path(args.out).resolve();common.ROOT=Path(args.envship_cache).resolve().parent
 common.OUT.mkdir(parents=True,exist_ok=True)
 if not (common.OUT/'SOURCE_PLAN.json').exists():shutil.copy2(BASE/'data_manifests/finland/SOURCE_PLAN.json',common.OUT/'SOURCE_PLAN.json')
 prepare.prepare();return 0
def fit_routes(args):
 import external_ais_common as common
 import external_ais_evaluate as evaluation
 common.OUT=Path(args.out).resolve();common.SEEDS=tuple(args.seeds)
 evaluation.fit_external_routes();return 0
def main():
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='command',required=True)
 a=s.add_parser('verify');a.add_argument('--manifest',default='MANIFEST.json');a=s.add_parser('tables');a.add_argument('--out',default=str(BASE/'regenerated'))
 s.add_parser('external-metrics');s.add_parser('smoke')
 a=s.add_parser('infer');a.add_argument('--domain',choices=('dma','noaa','norway','piraeus','finland'),required=True);a.add_argument('--seed',type=int,default=42);a.add_argument('--history');a.add_argument('--limit',type=int,default=2);a.add_argument('--batch',type=int,default=16);a.add_argument('--device',default='cpu');a.add_argument('--out',required=True)
 a=s.add_parser('train-one');a.add_argument('--model',required=True);a.add_argument('--seed',type=int,default=42);a.add_argument('--stage',default='train');a.add_argument('--cache',required=True);a.add_argument('--config',required=True);a.add_argument('--pretrained');a.add_argument('--out',required=True)
 a=s.add_parser('prepare-envship');a.add_argument('--data',required=True);a.add_argument('--out',required=True)
 a=s.add_parser('prepare-finland');a.add_argument('--envship-cache',required=True);a.add_argument('--out',required=True)
 a=s.add_parser('fit-routes');a.add_argument('--out',required=True);a.add_argument('--seeds',type=int,nargs='+',default=[42,52,62,72,82])
 args=p.parse_args();return {'verify':verify,'tables':tables,'external-metrics':external,'smoke':smoke,'infer':infer,'train-one':train_one,'prepare-envship':prepare_envship,'prepare-finland':prepare_finland,'fit-routes':fit_routes}[args.command](args)
if __name__=='__main__':raise SystemExit(main())
