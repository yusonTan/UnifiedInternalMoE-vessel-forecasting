# Before public release

- Approve a code licence covering author-owned contributions; retain third-party notices.
- Confirm the EnvShip data entry, release version, access conditions and permissions.
- Deposit code/results and obtain a real repository URL or DOI.
- Decide which trained checkpoints and derived trajectory arrays can be redistributed.
- Update the manuscript and submission-form data statements to match that deposit.
- Keep main10, supplementary five-seed cohorts and historical diagnostic3 separate.
- A full retraining of every experiment was not performed during packaging.
