# Before public release

- Confirm the proposed MIT code / CC BY 4.0 author-owned table licences.
- Public lightweight repository: https://github.com/yusonTan/UnifiedInternalMoE-vessel-forecasting.
- Upstream data terms and notices are recorded in DATA_RIGHTS.md and release_audit/.
- Verify upstream release identity against original experimental input hashes.
- No project-specific DOI exists; a GitHub URL is not a minted DOI.
- Decide which trained checkpoints and derived trajectory arrays can be redistributed.
- Update the manuscript and submission-form data statements to match that deposit.
- Keep main10, supplementary five-seed cohorts and historical diagnostic3 separate.
- A full retraining of every experiment was not performed during packaging.
