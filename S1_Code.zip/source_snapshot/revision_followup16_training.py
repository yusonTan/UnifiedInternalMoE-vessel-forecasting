"""Isolated epoch-boundary resumability; leaves the original trainer unchanged."""
import json
import random
import sys
import time
from pathlib import Path
import numpy as np
import torch
import amf.trainer as trainer


def snapshot_rng():
    return {'python': random.getstate(), 'numpy': np.random.get_state(),
            'torch': torch.get_rng_state(),
            'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    torch.set_rng_state(state['torch'].cpu())
    if state['cuda']:
        torch.cuda.set_rng_state_all([x.cpu() for x in state['cuda']])


def main():
    torch.set_num_threads(4)
    torch.set_num_interop_threads(2)
    args = sys.argv[1:]
    def value(flag):
        return args[args.index(flag) + 1]
    run = Path(value('--output-dir')) / value('--domain') / ('seed_' + value('--seed'))
    run.mkdir(parents=True, exist_ok=True)
    last = run / 'last.pt'
    prior = torch.load(last, map_location='cpu', weights_only=False) if '--resume' in args and last.exists() else None
    if prior is not None and 'followup16_rng' not in prior:
        raise RuntimeError('Cannot claim RNG-safe resume from a legacy checkpoint')
    previous_elapsed = float(prior.get('followup16_elapsed', 0.)) if prior else 0.
    amp, active_started = {}, [None]
    original_grad_scaler, original_save = trainer.GradScaler, trainer._atomic_torch_save
    original_load, original_train = trainer.torch.load, trainer.train_model

    def grad_scaler(*a, **kw):
        obj = original_grad_scaler(*a, **kw)
        amp['scaler'] = obj
        return obj

    def save(payload, path):
        if Path(path).name == 'last.pt':
            payload = dict(payload)
            payload['followup16_rng'] = snapshot_rng()
            payload['followup16_amp'] = amp['scaler'].state_dict()
            payload['followup16_elapsed'] = previous_elapsed + time.time() - active_started[0]
        original_save(payload, path)

    def load(path, *a, **kw):
        obj = original_load(path, *a, **kw)
        if not hasattr(path, 'read') and Path(path).resolve() == last.resolve() and prior is not None:
            restore_rng(obj['followup16_rng'])
            amp['scaler'].load_state_dict(obj['followup16_amp'])
            print('Restored RNG and AMP at completed epoch boundary', flush=True)
        return obj

    def train(*a, **kw):
        original_cap = kw['max_training_seconds']
        if prior:
            stopped = prior['epoch'] >= kw['epochs'] or prior['stale'] >= kw['patience']
            stopped = stopped or (original_cap > 0 and previous_elapsed >= original_cap)
            if stopped:
                # Re-enter only the evaluation tail; do not add epochs after early stop.
                kw['epochs'] = prior['epoch']
            if original_cap > 0:
                kw['max_training_seconds'] = max(.001, original_cap - previous_elapsed)
        active_started[0] = time.time()
        return original_train(*a, **kw)

    trainer.GradScaler, trainer._atomic_torch_save = grad_scaler, save
    trainer.torch.load, trainer.train_model = load, train
    # Import after patching so train.py binds the isolated resumable wrapper.
    import train as entry
    sys.argv = ['train.py', *args]
    (run / 'revision_runtime.json').write_text(json.dumps({
        'CPU_threads': 4, 'loader_workers': 0, 'effective_arguments': args,
        'resume_epoch_boundary_RNG_and_AMP': True, 'prior_elapsed_seconds': previous_elapsed,
        'repair_time_cap_cumulative_across_resume': True}, indent=2), encoding='utf-8')
    entry.main()


if __name__ == '__main__':
    main()
