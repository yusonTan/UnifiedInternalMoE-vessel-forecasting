"""Read-only historical inputs for CV15 protection and cross-region extension."""
from __future__ import annotations
import csv
import json
import os
import time
from pathlib import Path
import numpy as np
import torch
from run_revision_10seed import run_of, sha, FileLock
from run_plos_rigor_suite import atomic_json, expand_route
from evaluate_compact_committee import group_folds, project_simplex

ROOT = Path(__file__).resolve().parent
OUT = Path('E:/OE_external_cv_transfer_20261016')
MAIN = Path('E:/OE_revision10seed_20261012')
DOMAINS = ('dma','noaa','norway','piraeus')
SEEDS = (42,52,62,72,82,92,102,112,122,132)
EXPERTS = ('sa_repair','transformer_cv','itransformer_fa_faithful','mstformer_faithful','direct_gru')
BACKBONES = EXPERTS + ('direct_lstm','tcn_cv')
MODELS = BACKBONES + ('UnifiedInternalMoE',)
METRICS = tuple(f'{k}@{h}' for h in (5,10,20,30,45,60) for k in ('ADE','FDE'))
BETAS = (0.,.1,.25,.5)
RIDGES = (0.,.001,.01,.05,.2,1.)
CODE = ('revision_extension_common.py','revision_external_feasibility.py','revision_cv_transfer.py',
        'run_revision_cv_transfer.py','verify_cv_transfer_csv.mjs','tests/test_cv_transfer.py',
        'start_revision_cv_transfer.ps1','monitor_revision_cv_transfer.ps1','独立AIS_CV15保护_迁移扩展_20261016.md')

def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def emit(event, **kw):
    OUT.mkdir(parents=True,exist_ok=True)
    r={'time':time.strftime('%Y-%m-%d %H:%M:%S'),'event':event,**kw}
    with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    atomic_json(OUT/'STATUS.json',r)
    print(json.dumps(r,ensure_ascii=False),flush=True)

def table(name,rows):
    if not rows:raise ValueError('Empty result is not completed')
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.csv.tmp')
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with tmp.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
    os.replace(tmp,p)

def archive(p,**a):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp.npz')
    np.savez_compressed(tmp,**a);os.replace(tmp,p)

def data(domain,split):
    return tuple(np.load(ROOT/'cache'/domain/f'{domain}_{split}'/f'{k}.npy',mmap_mode='r') for k in ('history','future','mmsi'))

def prediction_path(model,domain,seed):
    digest=sha(run_of(model,domain,seed)/'best.pt')
    candidates=[MAIN/'predictions'/model/domain/f'seed_{seed}.npz']
    candidates += [ROOT/p/'predictions'/model/domain/f'seed_{seed}.npz' for p in ('revision_7h_20261009','revision_2h_20261009')]
    for p in candidates:
        if p.exists():
            with np.load(p) as z:
                if str(z['checkpoint_sha256'].item())==digest:return p
    raise RuntimeError('Audited prediction cache missing; historical directories must not be written: '+str((model,domain,seed)))

def load_candidates(domain,seed,split):
    lock=read(OUT/'PROTOCOL.json');pp=[];truth=ids=index=None
    for name in EXPERTS:
        p=lock['prediction_caches'][f'{name}/{domain}/{seed}']
        with np.load(p) as z:
            y,i,j=(z[split+k] for k in ('_target','_MMSI','_window_index'))
            if truth is None:truth,ids,index=y.copy(),i.copy(),j.copy()
            elif not np.array_equal(ids,i) or not np.array_equal(index,j) or np.max(np.abs(truth-y))>.05:
                raise RuntimeError('Candidate alignment failure')
            pp.append(z[split+'_prediction'].copy())
    hx,fy,mi=data(domain,split)
    if not np.array_equal(ids,mi) or not np.array_equal(index,np.arange(len(mi))) or np.max(np.abs(truth-fy))>.05:
        raise RuntimeError('Prediction cache does not match canonical metric coordinates')
    return np.stack(pp,axis=1),truth,ids,index

def cv15(h):
    positions=np.asarray(h[...,:2],dtype=np.float32)
    velocity=np.diff(positions[:,-15:],axis=1).mean(axis=1)
    return positions[:,-1:]+np.arange(1,181,dtype=np.float32)[None,:,None]*velocity[:,None]

def blend(p,route):return np.einsum('nktd,tk->ntd',p,expand_route(route)).astype(np.float32)

def errors(p,y):
    d=np.linalg.norm(p.astype(np.float64)-y.astype(np.float64),axis=-1)
    return {m:d[:,:3*int(m.split('@')[1])].mean(1) if m.startswith('ADE') else d[:,3*int(m.split('@')[1])-1] for m in METRICS}

def J(e):return (np.mean(e['ADE@5'])/20+np.mean(e['ADE@10'])/50+2*np.mean(e['ADE@60'])/600)/4

def route_score(p,y,r):return J(errors(blend(p,r),y))

def summarize(rows,keys):
    out=[]
    for group in sorted({tuple(r[k] for k in keys) for r in rows}):
        rr=[r for r in rows if tuple(r[k] for k in keys)==group]
        if len(rr)!=10 or {r['seed'] for r in rr}!=set(SEEDS):raise RuntimeError('Incomplete ten-seed cohort '+str(group))
        row=dict(zip(keys,group));row['n_seeds']=10
        for m in ('test_J',*METRICS):
            v=np.asarray([r[m] for r in rr]);row[m+'_mean']=float(v.mean());row[m+'_std']=float(v.std(ddof=1))
        out.append(row)
    return out

class FloorFitter:
    """Anchor LS plus ridge-to-SA, subject to simplex and a CV15 weight floor.

    w=beta*e_CV+(1-beta)*u, u on simplex. Gram matrices are streamed and
    prefix-horizon squared-error surrogates are NOT claimed to optimize ADE.
    """
    def __init__(self,p,y,indices=None):
        self.p,self.y=p,y;self.indices=np.arange(len(y)) if indices is None else np.asarray(indices)
        self.k=p.shape[1];self.grams={}
    def gram(self,s):
        if s not in self.grams:
            g=np.zeros((self.k,self.k));count=0
            for start in range(0,len(self.indices),256):
                ii=self.indices[start:start+256]
                e=(self.p[ii,:,:s].astype(np.float64)-self.y[ii,None,:s]).transpose(1,0,2,3).reshape(self.k,-1)
                g+=e@e.T;count+=e.shape[1]
            self.grams[s]=g/count
        return self.grams[s]
    def fit(self,ridge,beta):
        if not 0<=beta<1 or (self.k!=6 and beta!=0):raise ValueError('CV floor needs six experts and beta in [0,1)')
        a=np.zeros(self.k);a[0]=1.;b=np.zeros(self.k)
        if self.k==6:b[-1]=beta
        result=[]
        for s in (15,30,180):
            g=self.gram(s);scale=max(float(np.trace(g)/self.k),1e-12)
            q=g+ridge*scale*np.eye(self.k);c=1-beta
            lips=max(2*c*c*float(np.linalg.eigvalsh(q).max()),1e-12);u=a.copy()
            for _ in range(500):
                w=b+c*u;gradient=2*c*(q@w-ridge*scale*a)
                v=project_simplex(u-gradient/lips)
                if np.max(np.abs(v-u))<1e-10:u=v;break
                u=v
            result.append(b+c*u)
        return {'steps':[15,30,180],'weights':np.stack(result)}

def choose_candidates(p,y,ids,seed,indices=None):
    ix=np.arange(len(y)) if indices is None else np.asarray(indices)
    folds=group_folds(ids[ix],seed)
    if any(not h.any() or not (~h).any() for h in folds):raise ValueError('Empty MMSI validation fold')
    fits=[FloorFitter(p,y,ix[~h]) for h in folds];rank=[]
    betas=BETAS if p.shape[1]==6 else (0.,)
    for beta in betas:
        for ridge in RIDGES:
            values=[route_score(p[ix[h]],y[ix[h]],fit.fit(ridge,beta)) for h,fit in zip(folds,fits)]
            rank.append({'beta':beta,'ridge':ridge,'fold_scores':values,'selection_J':float(np.mean(values)+.25*np.std(values))})
    rank.sort(key=lambda x:(x['selection_J'],x['beta'],x['ridge']))
    by_beta={b:next(r for r in rank if r['beta']==b) for b in betas}
    return by_beta,rank[0],rank

def complete(folder,deep=False):
    folder=Path(folder);marker=folder/'COMPLETE.json'
    if not marker.exists():return False
    r=read(marker)
    if not r.get('complete'):return False
    for name,digest in r['files'].items():
        p=folder/name
        if not p.exists() or (deep and sha(p)!=digest):raise RuntimeError('Accepted output changed: '+str(p))
    return True

def accept(folder,names,**kw):
    atomic_json(Path(folder)/'COMPLETE.json',{'complete':True,'time':time.strftime('%Y-%m-%d %H:%M:%S'),
        'files':{n:sha(Path(folder)/n) for n in names},**kw})

def check_frozen(deep=False):
    lock=read(OUT/'PROTOCOL.json')
    for p,r in lock['frozen_files'].items():
        path=Path(p)
        if path.stat().st_size!=r['bytes'] or path.stat().st_mtime_ns!=r['mtime_ns'] or (deep and sha(path)!=r['sha256']):
            raise RuntimeError('Frozen historical input changed '+p)
    if {n:sha(ROOT/n) for n in CODE}!=lock['code_hashes']:raise RuntimeError('Campaign code changed after lock')
