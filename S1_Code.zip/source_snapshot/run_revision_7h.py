"""Finish four-region seed expansion without changing original training rules."""
from __future__ import annotations
import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
import numpy as np
import torch
from run_complete_study_stage import common_sa_command
from run_plos_rigor_suite import atomic_json, write_csv
from run_revision_2h import set_arg, sha

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'revision_7h_20261009'
PREVIOUS = ROOT / 'revision_2h_20261009'
DOMAINS = ('dma', 'noaa', 'norway', 'piraeus')
BIG = ('dma', 'noaa')
NEW = (72, 82)
SEEDS = (42, 52, 62, 72, 82)
MODELS = ('direct_lstm', 'direct_gru', 'tcn_cv', 'transformer_cv',
          'itransformer_fa_faithful', 'sa_repair', 'mstformer_faithful')
HISTORICAL_MINUTES = {'direct_lstm': (5.08, 3.98), 'direct_gru': (5.21, 3.92),
    'tcn_cv': (3.70, 4.14), 'transformer_cv': (8.11, 10.06),
    'itransformer_fa_faithful': (6.54, 6.33), 'mstformer_faithful': (29.08, 23.41),
    'SA_pretraining': (30.75, 26.64), 'SA_repair': (10., 10.)}


def log(event, **details):
    OUT.mkdir(parents=True, exist_ok=True)
    row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, **details}
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
    atomic_json(OUT / 'STATUS.json', row)
    print(json.dumps(row, ensure_ascii=False, default=str), flush=True)


def run_of(model, domain, seed):
    if seed in NEW:
        source = OUT if domain in BIG else PREVIOUS
        if model == 'sa_repair':
            return source / 'SA_seed_repair' / domain / f'seed_{seed}'
        family = 'faithful_sota' if 'faithful' in model else 'runs'
        return source / 'comparisons' / family / model / domain / f'seed_{seed}'
    if model == 'sa_repair':
        return ROOT / 'eight_hour_diagnostic/repairs/router_sharp150_cov_0p0' / domain / f'seed_{seed}'
    family = 'faithful_sota' if 'faithful' in model else 'runs'
    return ROOT / 'complete_3seed_4domain_study/comparisons' / family / model / domain / f'seed_{seed}'


def sa_args(domain, seed, output, stage, predecessor=None):
    args = common_sa_command(output, domain, seed, 'full')[3:]
    set_arg(args, '--num-workers', 0)
    set_arg(args, '--router-temperature-override', 1.0)
    if stage == 'repair':
        set_arg(args, '--epochs', 60)
        set_arg(args, '--learning-rate', .00002)
        set_arg(args, '--patience', 12)
        set_arg(args, '--max-training-seconds', 600)
        set_arg(args, '--router-temperature-override', 1.5)
        set_arg(args, '--component-ablation', 'router_sharp150')
        set_arg(args, '--init-checkpoint', predecessor)
    return args


def tasks():
    # Seed-major scheduling preserves a complete four-domain four-seed layer.
    for seed in NEW:
        for domain in BIG:
            for name in MODELS:
                if name == 'sa_repair':
                    base = OUT / 'SA_seed_pretraining'
                    predecessor = base / domain / f'seed_{seed}' / 'best.pt'
                    yield {'label': f'SA_pretraining/{domain}/{seed}', 'model': 'SA_pretraining',
                           'domain': domain, 'seed': seed, 'script': 'train',
                           'args': sa_args(domain, seed, base, 'pretrain'),
                           'marker': predecessor.parent / 'test_metrics.json'}
                    yield {'label': f'SA_repair/{domain}/{seed}', 'model': 'SA_repair',
                           'domain': domain, 'seed': seed, 'script': 'train',
                           'args': sa_args(domain, seed, OUT / 'SA_seed_repair', 'repair', predecessor),
                           'marker': run_of(name, domain, seed) / 'test_metrics.json'}
                else:
                    yield {'label': f'{name}/{domain}/{seed}', 'model': name, 'domain': domain,
                           'seed': seed, 'script': 'train_faithful_sota' if 'faithful' in name else 'train_comparison_model',
                           'args': ['--model', name, '--domain', domain, '--seed', str(seed),
                                    '--output-root', str(OUT / 'comparisons'), '--num-workers', '0'],
                           'marker': run_of(name, domain, seed) / 'result.json'}


def marker_for(model, domain, seed):
    return run_of(model, domain, seed) / ('test_metrics.json' if model == 'sa_repair' else 'result.json')


def complete_seeds():
    return tuple(seed for seed in SEEDS if all(marker_for(m, d, seed).exists()
                 and (run_of(m, d, seed) / 'best.pt').exists() for m in MODELS for d in DOMAINS))


def preflight():
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; do not silently fall back to CPU')
    free = shutil.disk_usage(ROOT).free
    if free < 8 * 1024**3:
        raise RuntimeError('Need at least 8 GiB free before starting this campaign')
    cache_audit, sources = [], []
    for domain in DOMAINS:
        groups = []
        for split in ('train', 'val', 'test'):
            path = ROOT / 'cache' / domain / f'{domain}_{split}'
            h, y, ids = [np.load(path / f'{name}.npy', mmap_mode='r') for name in ('history', 'future', 'mmsi')]
            if h.shape[1:] != (90, 6) or y.shape[1:] != (180, 2) or not len(h) == len(y) == len(ids):
                raise RuntimeError(f'Invalid data dimensions: {path}')
            groups.append(set(map(int, np.unique(ids))))
            cache_audit.append({'domain': domain, 'split': split, 'windows': len(ids), 'MMSI_groups': len(groups[-1])})
        if any(groups[i] & groups[j] for i, j in ((0, 1), (0, 2), (1, 2))):
            raise RuntimeError(f'MMSI split overlap in {domain}')
        scaler = ROOT / 'cache' / domain / 'scaler.json'
        sources.append({'path': str(scaler), 'sha256': sha(scaler)})
        for seed in SEEDS:
            if seed in NEW and domain in BIG:
                continue
            for model in MODELS:
                checkpoint = run_of(model, domain, seed) / 'best.pt'
                if not checkpoint.exists() or not marker_for(model, domain, seed).exists():
                    raise RuntimeError(f'Missing reusable completed result: {checkpoint}')
                sources.append({'path': str(checkpoint), 'sha256': sha(checkpoint)})
    atomic_json(OUT / 'PREFLIGHT.json', {'complete': True, 'CUDA': torch.cuda.get_device_name(),
        'free_bytes': free, 'MMSI_disjoint': True, 'cache': cache_audit, 'sources': sources})
    code = [ROOT / name for name in ('run_revision_7h.py', 'revision_7h_results.py',
        'revision_training_job.py', 'revision_2h_results.py', 'train.py',
        'train_comparison_model.py', 'train_faithful_sota.py', 'amf/adaptive_moe.py')]
    atomic_json(OUT / 'code_manifest.json', {str(p.relative_to(ROOT)): sha(p) for p in code})
    log('preflight_complete', CUDA=torch.cuda.get_device_name(), free_GiB=round(free / 1024**3, 2))


def execute(item, deadline, smoke=False):
    if item['marker'].exists():
        log('task_resume_skip', label=item['label'])
        return True
    estimate = HISTORICAL_MINUTES[item['model']][BIG.index(item['domain'])] * 60
    # Leave 35 minutes for inference/statistics and 10% task-duration headroom.
    if not smoke and deadline - time.time() < 2100 + 1.1 * estimate:
        log('task_not_started_budget', label=item['label'], estimate_seconds=estimate)
        return False
    item['marker'].parent.mkdir(parents=True, exist_ok=True)
    args = list(item['args'])
    if (item['marker'].parent / 'last.pt').exists():
        args.append('--resume')
    command = [sys.executable, '-u', str(ROOT / 'revision_training_job.py'), '--script', item['script'], *args]
    log('task_started', label=item['label'], command=command,
        deadline=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(deadline)))
    started = time.time()
    for attempt in (1, 2):
        with (item['marker'].parent / 'terminal.log').open('a', encoding='utf-8') as stream:
            try:
                result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                        timeout=max(1, deadline - time.time() - (0 if smoke else 2100)))
            except subprocess.TimeoutExpired:
                log('task_budget_timeout', label=item['label'], checkpoint=str(item['marker'].parent / 'last.pt'))
                return False
        if result.returncode == 0 and item['marker'].exists():
            log('task_completed', label=item['label'], seconds=round(time.time() - started, 2), attempt=attempt)
            return True
        log('task_attempt_failed', label=item['label'], returncode=result.returncode, attempt=attempt)
        if deadline - time.time() < 2100 + estimate or attempt == 2:
            break
        if (item['marker'].parent / 'last.pt').exists() and '--resume' not in command:
            command.append('--resume')
    return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--budget-minutes', type=float, default=420,
                        help='Explicit continuation budget; completed training tasks are reused')
    args = parser.parse_args()
    if args.budget_minutes <= 0:
        parser.error('--budget-minutes must be positive')
    OUT.mkdir(parents=True, exist_ok=True)
    if args.smoke:
        preflight()
        item = next(tasks())
        item['args'] += ['--quick-smoke']
        set_arg(item['args'], '--output-root', OUT / 'smoke')
        item['marker'] = OUT / 'smoke/runs/direct_lstm/dma/seed_72/result.json'
        if not execute(item, time.time() + 240, smoke=True):
            raise RuntimeError('Smoke training failed')
        atomic_json(OUT / 'SMOKE_COMPLETE.json', {'complete': True, 'model': 'direct_lstm', 'domain': 'dma'})
        return
    started = time.time()
    deadline = started + args.budget_minutes * 60
    if (OUT / 'PROTOCOL.json').exists():
        snapshot = OUT / 'history' / time.strftime('%Y%m%d_%H%M%S')
        snapshot.mkdir(parents=True, exist_ok=False)
        for path in OUT.iterdir():
            if path.is_file() and path.suffix in ('.json', '.csv', '.md'):
                shutil.copy2(path, snapshot / path.name)
        fusion = OUT / 'fusion_5seed_refit'
        if fusion.exists():
            shutil.copytree(fusion, snapshot / 'previous_fusion_checkpoints')
        log('previous_summary_preserved', directory=str(snapshot))
    atomic_json(OUT / 'PROTOCOL.json', {'started_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'deadline_unix': deadline, 'budget_seconds': args.budget_minutes * 60, 'domains': DOMAINS, 'target_seeds': SEEDS,
        'new_backbone_replications': 28, 'new_training_subtasks': 32,
        'SA_repair_max_training_seconds': 600, 'source_seed_order': NEW,
        'std_ddof': 1, 'historical_test_previously_observed': True,
        'original_checkpoint_files_preserved': True, 'CPU_threads_new_jobs': 4, 'workers_new_jobs': 0,
        'fusion_protocol': 'same as revision_2h; shared validation short-specialist choice',
        'test_used_for_new_model_selection': False, 'deadline_resets_on_explicit_restart': True})
    failures, stop_reason = [], None
    if os.name == 'nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        preflight()
        log('campaign_started', tasks=32,
            deadline=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(deadline)))
        for item in tasks():
            if not execute(item, deadline):
                stop_reason = item['label']
                break
        chosen = complete_seeds()
        atomic_json(OUT / 'TRAINING_PHASE.json', {'complete': chosen == SEEDS,
             'complete_four_domain_seeds': chosen, 'stopped_at_task': stop_reason})
        log('summary_started', complete_seeds=chosen)
        command = [sys.executable, '-u', str(ROOT / 'revision_7h_results.py'),
                   '--deadline', str(deadline), '--seeds', *map(str, chosen)]
        with (OUT / 'summary.log').open('a', encoding='utf-8') as stream:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=max(1, deadline - time.time()))
        if result.returncode != 0:
            failures.append('summary_nonzero_exit')
    except Exception as exc:
        failures.append(str(exc))
        traceback.print_exc()
        log('campaign_error', detail=str(exc))
    finally:
        chosen = complete_seeds()
        missing = [i['label'] for i in tasks() if not i['marker'].exists()]
        statistics = OUT / 'STATISTICS_COMPLETE.json'
        stats_payload = json.loads(statistics.read_text()) if statistics.exists() else {}
        stats_done = bool(stats_payload.get('complete')) and tuple(stats_payload.get('seeds', ())) == chosen
        payload = {'finished_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'failures': failures,
            'complete_four_domain_seeds': chosen, 'missing_training_tasks': missing,
            'full_four_domain_five_seed_complete': chosen == SEEDS,
            'statistics_complete': stats_done, 'complete': not failures and not missing and stats_done}
        atomic_json(OUT / 'CAMPAIGN_RESULT.json', payload)
        log('campaign_finished', **payload)
        if os.name == 'nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


if __name__ == '__main__':
    main()
