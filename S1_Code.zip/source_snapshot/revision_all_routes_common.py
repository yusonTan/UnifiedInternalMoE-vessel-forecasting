"""Isolated all-routing campaign. Original experiments are read-only."""
from __future__ import annotations
import csv
import gc
import itertools
import json
import os
import time
from pathlib import Path
import numpy as np
import torch
from amf.data import RobustTrajectoryScaler
from amf.metrics import displacement_metrics
from evaluate_compact_committee import group_folds, project_simplex
from revision_5h_analysis import jscore, route_blend, paired_uncertainty
from revision_10seed_results import collect as collect_main
from run_revision_10seed import run_of, sha, FileLock
from run_plos_rigor_suite import atomic_json, expand_route

ROOT = Path(__file__).resolve().parent
OUT = Path('E:/OE_all_routes_20261013')
MAIN = Path('E:/OE_revision10seed_20261012')
DOMAINS = ('dma', 'noaa', 'norway', 'piraeus')
SEEDS = (42, 52, 62, 72, 82, 92, 102, 112, 122, 132)
FIVE = SEEDS[:5]
EXPERTS = ('sa_repair', 'transformer_cv', 'itransformer_fa_faithful', 'mstformer_faithful', 'direct_gru')
RIDGES = (0., .001, .01, .05, .2, 1.)
ANCHORS = ((60,), (10, 60), (5, 10, 60), (5, 20, 60), (5, 30, 60),
           (10, 30, 60), (5, 10, 30, 60), (5, 10, 20, 30, 45, 60))
STATIC = ('best_single', 'uniform_all', 'global_simplex', 'three_anchor')
HEADS = ('mlp', 'gru', 'gru_disagreement')
METRICS = tuple(f'{a}@{h}' for h in (5, 10, 20, 30, 45, 60) for a in ('ADE', 'FDE'))

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def emit(event, **kw):
    OUT.mkdir(parents=True, exist_ok=True)
    row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, **kw}
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
    atomic_json(OUT / 'STATUS.json', row)
    print(json.dumps(row, ensure_ascii=False), flush=True)

def table(name, rows):
    if not rows:
        raise ValueError('Empty final table is not a completed result')
    fields = list(dict.fromkeys(k for r in rows for k in r))
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.csv.tmp')
    with temp.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    os.replace(temp, path)

def archive(path, **arrays):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp.npz')
    np.savez_compressed(tmp, **arrays)
    os.replace(tmp, path)

def errors(p, y):
    d = np.linalg.norm(p.astype(np.float64) - y.astype(np.float64), axis=-1)
    return {k: d[:, :3*int(k.split('@')[1])].mean(1) if k.startswith('ADE')
            else d[:, 3*int(k.split('@')[1])-1] for k in METRICS}

def load_data(domain, seed, split='val'):
    pp, y, ids, index = [], None, None, None
    for name in EXPERTS:
        with collect_main(name, domain, seed) as z:
            yy, ii, jj = z[split+'_target'], z[split+'_MMSI'], z[split+'_window_index']
            if y is None:
                y, ids, index = yy.copy(), ii.copy(), jj.copy()
            elif not np.array_equal(ids, ii) or not np.array_equal(index, jj) or np.max(np.abs(y-yy)) > .05:
                raise RuntimeError('Candidate target/MMSI/window alignment failed')
            pp.append(z[split+'_prediction'].copy())
    return np.stack(pp, axis=1), y, ids, index

def history(domain, split='val'):
    x = np.load(ROOT / 'cache' / domain / f'{domain}_{split}' / 'history.npy', mmap_mode='r')
    scaler = RobustTrajectoryScaler.load(ROOT / 'cache' / domain / 'scaler.json')
    return scaler.transform_history(np.asarray(x)).astype(np.float32)

def active_mask(domain, seed):
    payload = torch.load(MAIN / 'fusion_10seed_refit' / domain / f'seed_{seed}' / 'best.pt',
                         map_location='cpu', weights_only=False)
    mask = payload['model']['internal_active_mask'].numpy().astype(bool)
    if mask.shape != (5,) or not mask.any():
        raise RuntimeError('Invalid formal expert mask')
    return mask

def scales_for(p, y, domain, mode):
    if mode == 'original': return (20., 50., 600.)
    if mode == 'CV15_validation':
        from amf.adaptive_moe import AdaptivePhysicsExperts
        x = np.load(ROOT/'cache'/domain/f'{domain}_val'/'history.npy', mmap_mode='r')
        cv = AdaptivePhysicsExperts._cv(torch.from_numpy(np.asarray(x[..., :2]).copy()), 15,
                 torch.arange(1,181).view(1,-1,1)).numpy()
        return tuple(max(j,1e-6) for j in (displacement_metrics(cv,y)[f'ADE@{h}'] for h in (5,10,60)))
    v = np.asarray([[displacement_metrics(p[:,k],y)[f'ADE@{h}'] for h in (5,10,60)] for k in range(5)])
    out = v.min(0) if mode == 'best_expert_validation' else np.median(v,axis=0)
    return tuple(np.maximum(out,1e-6))

class Fitter:
    """Same simplex least-squares anchor surrogate; cached Gram, not test-trained."""
    def __init__(self,p,y):
        self.p,self.y = p,y
        self.cache = {}
    def gram(self,s):
        if s not in self.cache:
            e = (self.p[:,:,:s].astype(np.float64)-self.y[:,None,:s]).transpose(1,0,2,3).reshape(5,-1)
            self.cache[s] = e @ e.T / e.shape[1]
        return self.cache[s]
    def fit(self, keep, ridge, minutes=(5,10,60), kind='three_anchor'):
        keep = tuple(keep)
        if not keep: raise ValueError('No active experts')
        if kind == 'uniform_all':
            w=np.zeros((1,5));w[0,list(keep)]=1/len(keep)
            return {'steps':[180],'weights':w}
        result=[]
        for minute in minutes:
            g=self.gram(3*minute)[np.ix_(keep,keep)]
            a=np.zeros(len(keep));a[0]=1
            scale=max(float(np.trace(g)/len(g)),1e-12)
            penalized=g+ridge*scale*np.eye(len(g))
            lips=max(2*float(np.linalg.eigvalsh(penalized).max()),1e-12)
            w=a.copy()
            for _ in range(500):
                update=project_simplex(w-(2*g@w+2*ridge*scale*(w-a))/lips)
                if np.max(np.abs(update-w))<1e-10:
                    w=update;break
                w=update
            whole=np.zeros(5);whole[list(keep)]=w;result.append(whole)
        return {'steps':[3*m for m in minutes],'weights':np.stack(result)}

def score(p,y,scales=(20.,50.,600.),weights=(1.,1.,2.)):
    return jscore(p,y,scales,weights)

def select_route(p,y,ids,seed,keep=None,minutes=(5,10,60),kind='three_anchor',
                 scales=(20.,50.,600.),hweights=(1.,1.,2.),subsets=False,ridges=RIDGES):
    keep=tuple(range(5)) if keep is None else tuple(keep)
    if kind=='best_single': candidates=[(i,) for i in keep]
    elif subsets:
        # Original compact family: SA plus at most two other experts.
        candidates=[(0,)] + [(0,)+c for size in (1,2) for c in itertools.combinations(keep[1:],size)]
    else: candidates=[keep]
    choices=(0.,) if kind in ('uniform_all','best_single') else ridges
    if kind in ('uniform_all','best_single','global_simplex'): minutes=(60,)
    folds=group_folds(ids,seed)
    if any(not h.any() or not (~h).any() for h in folds): raise ValueError('Empty MMSI fold')
    fitters=[Fitter(p[~h],y[~h]) for h in folds]
    ranking=[]
    for subset in candidates:
        for ridge in choices:
            values=[]
            for h,fit in zip(folds,fitters):
                pp=route_blend(p[h],fit.fit(subset,ridge,minutes,kind))
                value=score(pp,y[h],scales,hweights)
                if subsets:
                    value/=max(score(p[h,0],y[h],scales,hweights),1e-12)
                values.append(value)
            objective=float(np.mean(values)+.25*np.std(values)+(.002*(len(subset)-1) if subsets else 0.))
            ranking.append({'keep':list(subset),'ridge':ridge,'fold_scores':values,'CV_objective':objective})
    ranking.sort(key=lambda r:(r['CV_objective'],len(r['keep']),r['ridge'],r['keep']))
    chosen=ranking[0]
    if subsets and chosen['CV_objective']>=.998:
        chosen=next(r for r in ranking if r['keep']==[0])
    route=Fitter(p,y).fit(chosen['keep'],chosen['ridge'],minutes,kind)
    return route,chosen,ranking

class ObjectiveRouteBank:
    """Fit each unchanged proxy candidate once; rescore validation objectives.

    This cache is valid only because scales/horizon weights affect selection,
    not the existing per-anchor least-squares surrogate. No test data enter it.
    """
    def __init__(self,p,y,ids,seed):
        self.fitter=Fitter(p,y);self.candidates=[]
        folds=group_folds(ids,seed)
        if any(not h.any() or not (~h).any() for h in folds):raise ValueError('Empty MMSI fold')
        fits=[Fitter(p[~h],y[~h]) for h in folds]
        self.reference=np.array([[errors(p[h,0],y[h])[f'ADE@{t}'].mean() for t in (5,10,60)] for h in folds])
        subsets=[(0,)]+[(0,)+combo for n in (1,2) for combo in itertools.combinations(range(1,5),n)]
        for subset in subsets:
            for ridge in RIDGES:
                metrics=[]
                for h,fit in zip(folds,fits):
                    ee=errors(route_blend(p[h],fit.fit(subset,ridge)),y[h])
                    metrics.append([ee[f'ADE@{t}'].mean() for t in (5,10,60)])
                self.candidates.append((subset,ridge,np.asarray(metrics)))
    def select(self,scales,hweights):
        coefficient=np.asarray(hweights)/np.asarray(scales)/sum(hweights)
        reference=self.reference@coefficient
        ranking=[]
        for subset,ridge,metrics in self.candidates:
            values=(metrics@coefficient)/np.maximum(reference,1e-12)
            ranking.append({'keep':list(subset),'ridge':ridge,'fold_scores':values.tolist(),
                'CV_objective':float(values.mean()+.25*values.std()+.002*(len(subset)-1))})
        ranking.sort(key=lambda r:(r['CV_objective'],len(r['keep']),r['ridge'],r['keep']))
        chosen=ranking[0]
        if chosen['CV_objective']>=.998:chosen=next(r for r in ranking if r['keep']==[0])
        return self.fitter.fit(chosen['keep'],chosen['ridge']),chosen,ranking

def mean_std(rows, keys=('domain','model','protocol'), expected=SEEDS):
    result=[]
    for group in sorted({tuple(r[k] for k in keys) for r in rows}):
        values=[r for r in rows if tuple(r[k] for k in keys)==group]
        if len(values)!=len(expected) or {r['seed'] for r in values}!=set(expected):
            raise RuntimeError(f'Incomplete seed table {group}')
        row=dict(zip(keys,group));row['n_seeds']=len(values)
        for m in ('validation_J','test_J',*METRICS):
            if m in values[0]:
                a=np.asarray([r[m] for r in values],dtype=float)
                if not np.isfinite(a).all():raise RuntimeError('Nonfinite metrics')
                row[m+'_mean']=float(a.mean());row[m+'_std']=float(a.std(ddof=1))
        result.append(row)
    return result

def holm(rows,key='Holm_p'):
    order=sorted(range(len(rows)),key=lambda i:rows[i]['wild_cluster_t_p']);running=0.
    for rank,i in enumerate(order):
        running=max(running,min(1.,(len(rows)-rank)*rows[i]['wild_cluster_t_p']))
        rows[i][key]=running

def save_evaluation(directory,domain,seed,protocol,p,y,ids,index,routes,validation_scores):
    rows=[];ee={}
    for name,pp in routes.items():
        rows.append({'domain':domain,'seed':seed,'model':name,'protocol':protocol,
            'validation_J':float(validation_scores[name]),'test_J':score(pp,y),**displacement_metrics(pp,y)})
        for m,v in errors(pp,y).items(): ee[name+'__'+m]=v
    archive(directory/'test_errors.npz',mmsi=ids,window_index=index,**ee)
    atomic_json(directory/'RESULT.json',{'complete':True,'rows':rows})
    return rows

def sa_pair(variant,domain,seed):
    """Return one audited predecessor/repair pair, never mix source pairs."""
    fresh=OUT/'SA_matched'/variant
    a=fresh/'pretraining'/domain/f'seed_{seed}';b=fresh/'repair'/domain/f'seed_{seed}'
    if all((r/'test_metrics.json').exists() for r in (a,b)): return a,b
    lock=OUT/'PROTOCOL.json'
    if lock.exists():
        for row in read(lock)['SA_reuse']:
            if (row['variant'],row['domain'],row['seed'])==(variant,domain,seed):
                return Path(row['pretraining']),Path(row['repair'])
    return a,b

def configure_sa():
    import revision_followup16_common as c
    import run_revision_followup16 as runner
    c.RUN_STORAGE=OUT
    def selected(item,stage):return sa_pair(item['variant'],item['domain'],item['seed'])[0 if stage=='pretraining' else 1]
    c.selected_run=selected;runner.selected_run=selected;runner.OUT=OUT
    return c,runner

def collect_sa(variant,domain,seed):
    import revision_2h_results as old
    old.OUT=OUT
    old.DEVICE=torch.device('cuda')
    run=sa_pair(variant,domain,seed)[1]
    with old.collect('sa_repair',run,domain,seed,tag='SA_matched_'+variant) as z:
        return {k:z[k].copy() for k in z.files}
