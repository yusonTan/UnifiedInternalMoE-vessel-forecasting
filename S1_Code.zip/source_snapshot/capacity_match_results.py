"""Complete-cohort comparison, paired uncertainty and scientific figures."""
from __future__ import annotations
import argparse
import gc
import numpy as np
import capacity_match_common as c
from revision_5h_analysis import paired_uncertainty
from revision_10seed_results import aggregate, holm


def load(model, domain, seed, split):
    if model == 'Wide-GRU':
        path = c.run(domain,seed)/(split+'_predictions.npz')
    elif model == 'UnifiedInternalMoE':
        path = c.MAIN/'fusion_10seed_refit'/domain/f'seed_{seed}'/(split+'_predictions.npz')
    else:
        path = c.baseline_archive(domain,seed)
    with np.load(path) as z:
        if model == 'Direct-GRU':
            result = {'prediction':z[split+'_prediction'].copy(), 'target':z[split+'_target'].copy(),
                      'mmsi':z[split+'_MMSI'].copy(), 'window_index':z[split+'_window_index'].copy()}
        else: result = {k:z[k].copy() for k in ('prediction','target','mmsi','window_index')}
    if not np.isfinite(result['prediction']).all(): raise RuntimeError('Nonfinite stored predictions')
    return result


def main():
    c.check_frozen(); rows, sources, curves = [], [], []
    for domain in c.DOMAINS:
        for seed in c.SEEDS:
            run = c.run(domain,seed)
            if not c.completed(run, deep=True): raise RuntimeError('Incomplete model cohort')
            result = c.read(run/'result.json')
            sources.append({'domain':domain,'seed':seed,'model':'Wide-GRU','run':str(run),
                'checkpoint_sha256':c.sha(run/'best.pt'), 'training_seconds':result['training_seconds'],
                'completed_epochs':result['completed_epochs'],'selected_epoch':result['selected_epoch'],
                'hit_epoch_limit':result['hit_epoch_limit'],'last_epoch_improved':result['last_epoch_improved'],
                'tail_training_loss_slope_per_epoch':result['tail_training_loss_slope_per_epoch']})
            curves.extend({'domain':domain,'seed':seed,**r} for r in c.read(run/'TRAINING_CURVE.json'))
            for model in c.MODELS:
                row = {'domain':domain,'seed':seed,'model':model,'protocol':'fixed_10seed_capacity_comparison'}
                for split in ('val','test'):
                    z = load(model,domain,seed,split); ref = load('UnifiedInternalMoE',domain,seed,split)
                    c.aligned(z,ref)
                    cacheids = np.load(c.ROOT/'cache'/domain/f'{domain}_{split}'/'mmsi.npy',mmap_mode='r')
                    if not np.array_equal(cacheids,z['mmsi']) or not np.array_equal(np.arange(len(cacheids)),z['window_index']):
                        raise RuntimeError('Prediction ordering differs from canonical split')
                    ee = c.errors(z['prediction'],z['target']); metrics = {k:float(v.mean()) for k,v in ee.items()}
                    row['validation_J' if split=='val' else 'test_J'] = c.score_metrics(metrics)
                    if split=='test':
                        row.update(metrics)
                        c.archive(c.OUT/'errors'/domain/model/f'seed_{seed}.npz',mmsi=z['mmsi'],window_index=z['window_index'],**ee)
                    del z,ref
                rows.append(row)
            c.emit('comparison_predictions_verified',domain=domain,seed=seed)
    means = aggregate(rows)
    c.table('capacity_per_seed.csv',rows); c.table('capacity_mean_std.csv',means)
    c.table('wide_training_provenance.csv',sources); c.table('wide_training_curves.csv',curves)
    macros = []
    for model in c.MODELS:
        js = [np.mean([r['test_J'] for r in rows if r['model']==model and r['seed']==s]) for s in c.SEEDS]
        vs = [np.mean([r['validation_J'] for r in rows if r['model']==model and r['seed']==s]) for s in c.SEEDS]
        macros.append({'model':model,'n_seeds':10,'four_region_equal_macro_J':float(np.mean(js)),
            'macro_J_seed_std':float(np.std(js,ddof=1)),'macro_validation_J':float(np.mean(vs))})
    c.table('capacity_macro.csv',macros)
    pairings = (('UnifiedInternalMoE','Wide-GRU'),('Direct-GRU','Wide-GRU'))
    evidence, pairs = [], []
    for reference, comparator in pairings:
        for domain in c.DOMAINS:
            differences = {m:[] for m in c.METRICS}; canonical = None
            for seed in c.SEEDS:
                with np.load(c.OUT/'errors'/domain/reference/f'seed_{seed}.npz') as a, np.load(c.OUT/'errors'/domain/comparator/f'seed_{seed}.npz') as b:
                    if not np.array_equal(a['mmsi'],b['mmsi']) or not np.array_equal(a['window_index'],b['window_index']):
                        raise RuntimeError('Paired errors have different window IDs')
                    if canonical is not None and not np.array_equal(canonical,a['mmsi']):raise RuntimeError('Seed ordering differs')
                    canonical=a['mmsi'].copy()
                    for metric in c.METRICS:
                        delta=b[metric]-a[metric]; differences[metric].append(delta)
                        pairs.append({'reference':reference,'comparator':comparator,'domain':domain,'seed':seed,
                            'metric':metric,'difference_m_comparator_minus_reference':float(delta.mean())})
            for metric in c.METRICS:
                evidence.append({'reference':reference,'comparator':comparator,'domain':domain,'metric':metric,
                    'n_seeds':10,'positive_favors_reference':True,
                    'fusion_shared_validation_selection':reference=='UnifiedInternalMoE',
                    **paired_uncertainty(np.stack(differences[metric]),canonical,np.random.default_rng(51000+len(evidence)),draws=10000)})
            c.emit('capacity_statistics_domain_complete',reference=reference,domain=domain)
        chosen=[r for r in evidence if r['reference']==reference]
        holm([r for r in chosen if r['metric'] in ('ADE@5','ADE@10','ADE@60')],'primary_ADE_12cell_Holm_p')
        holm([r for r in chosen if r['metric'] in ('FDE@5','FDE@10','FDE@60')],'anchor_FDE_12cell_Holm_p')
        holm([r for r in chosen if r['metric'] not in ('ADE@5','ADE@10','ADE@60','FDE@5','FDE@10','FDE@60')],'secondary_24cell_Holm_p')
    c.table('capacity_paired_uncertainty.csv',evidence); c.table('capacity_seed_differences.csv',pairs)
    figures(means,curves)
    c.atomic_json(c.OUT/'STATISTICS_COMPLETE.json',{'complete':True,'metric_rows':120,'summary_rows':12,'paired_cells':96})


def figures(means,curves):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(11,7),constrained_layout=True)
    for ax,domain in zip(axes.flat,c.DOMAINS):
        a=[next(r for r in means if r['domain']==domain and r['model']==m) for m in c.MODELS]
        ax.bar(np.arange(3),[r['ADE@60_mean'] for r in a],yerr=[r['ADE@60_std'] for r in a],capsize=4)
        ax.set_xticks(range(3),c.MODELS,rotation=15);ax.set_ylabel('ADE@60 (m), mean +/- sample SD');ax.set_title(domain.upper())
    fig.savefig(c.OUT/'capacity_ADE60.png',dpi=220);fig.savefig(c.OUT/'capacity_ADE60.pdf');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(11,7),constrained_layout=True)
    for ax,domain in zip(axes.flat,c.DOMAINS):
        for seed in c.SEEDS:
            a=[r for r in curves if r['domain']==domain and r['seed']==seed]
            ax.plot([r['epoch'] for r in a],[r['validation_score'] for r in a],alpha=.7,label=str(seed))
        ax.set_title(domain.upper());ax.set_xlabel('Epoch');ax.set_ylabel('Validation ADE@60 + 2 ADE@10 (m)')
    axes.flat[0].legend(ncol=2,fontsize=7)
    fig.savefig(c.OUT/'wide_validation_curves.png',dpi=220);fig.savefig(c.OUT/'wide_validation_curves.pdf');plt.close(fig)


if __name__=='__main__': main()
