from __future__ import annotations

import argparse
import csv
import json
import os
import time
from pathlib import Path

import numpy as np
import torch

from amf.data import EnvShipDataset, RobustTrajectoryScaler, build_cache, resolve_split_file
from amf.metrics import displacement_metrics
from evaluate_compact_committee import (
    collect_validation,
    fit_simplex,
    group_folds,
    run_path,
)


ROOT = Path(__file__).resolve().parent
DATA_ROOT = ROOT.parent / "data"
DIAGNOSTIC = ROOT / "eight_hour_diagnostic"
OFFICIAL = ROOT / "terminal_unified_v2_3seed_4domain"
SOURCE = ROOT / "complete_3seed_4domain_study"
DOMAINS = ("dma", "noaa", "norway", "piraeus")
SEEDS = (42, 52, 62)
EXPERTS = (
    "sa_repair",
    "transformer_cv",
    "itransformer_fa_faithful",
    "mstformer_faithful",
    "direct_gru",
)
COMPARATORS = (
    "direct_lstm",
    "direct_gru",
    "tcn_cv",
    "transformer_cv",
    "itransformer_fa_faithful",
    "mstformer_faithful",
)
HORIZONS = (5, 10, 20, 30, 45, 60)
STEPS = {5: 15, 10: 30, 20: 60, 30: 90, 45: 135, 60: 180}
METRICS = tuple(x for h in HORIZONS for x in (f"ADE@{h}", f"FDE@{h}"))
RIDGES = (0.0, 0.001, 0.01, 0.05, 0.2, 1.0)
VARIANTS = (
    "best_single_val",
    "uniform_all",
    "uniform_top3_val",
    "global_simplex",
    "anchor_60",
    "anchors_10_60",
    "anchors_5_10_60",
    "anchors_5_20_60",
    "anchors_5_10_30_60",
    "anchors_5_10_20_30_45_60",
    "top2_anchors_5_10_60",
    "top3_anchors_5_10_60",
)


def atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(
        json.dumps(
            payload,
            indent=2,
            ensure_ascii=False,
            default=lambda value: value.tolist() if isinstance(value, np.ndarray) else (
                value.item() if isinstance(value, np.generic) else str(value)
            ),
        ),
        encoding="utf-8",
    )
    os.replace(temp, path)


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def status(output: Path, phase: str, detail: str, complete: bool = False) -> None:
    payload = {
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "phase": phase,
        "detail": detail,
        "complete": complete,
    }
    atomic_json(output / "STATUS.json", payload)
    print(json.dumps(payload, ensure_ascii=False), flush=True)


def objective(prediction: np.ndarray, target: np.ndarray) -> float:
    m = displacement_metrics(prediction, target)
    return float((m["ADE@5"] / 20 + m["ADE@10"] / 50 + 2 * m["ADE@60"] / 600) / 4)


def variant_spec(name: str) -> tuple[list[int], int | None, str]:
    if name == "global_simplex" or name == "anchor_60":
        return [180], None, "simplex"
    if name == "anchors_10_60":
        return [30, 180], None, "simplex"
    if name == "anchors_5_20_60":
        return [15, 60, 180], None, "simplex"
    if name == "anchors_5_10_30_60":
        return [15, 30, 90, 180], None, "simplex"
    if name == "anchors_5_10_20_30_45_60":
        return [15, 30, 60, 90, 135, 180], None, "simplex"
    if name == "top2_anchors_5_10_60":
        return [15, 30, 180], 2, "simplex"
    if name == "top3_anchors_5_10_60":
        return [15, 30, 180], 3, "simplex"
    return [15, 30, 180], None, "simplex"


def individual_scores(predictions: np.ndarray, target: np.ndarray) -> np.ndarray:
    return np.asarray([objective(p, target) for p in predictions], dtype=np.float64)


def fit_route(
    predictions: np.ndarray,
    target: np.ndarray,
    name: str,
    ridge: float,
) -> dict:
    n = len(predictions)
    if name == "best_single_val":
        index = int(np.argmin(individual_scores(predictions, target)))
        weights = np.zeros((1, n), dtype=np.float64)
        weights[0, index] = 1.0
        return {"steps": [180], "weights": weights, "selected": [index]}
    if name == "uniform_all":
        return {"steps": [180], "weights": np.full((1, n), 1 / n), "selected": list(range(n))}
    if name == "uniform_top3_val":
        selected = np.argsort(individual_scores(predictions, target))[: min(3, n)]
        weights = np.zeros((1, n), dtype=np.float64)
        weights[0, selected] = 1 / len(selected)
        return {"steps": [180], "weights": weights, "selected": selected.tolist()}
    steps, topk, _ = variant_spec(name)
    selected = np.arange(n)
    if topk is not None:
        selected = np.argsort(individual_scores(predictions, target))[:topk]
    weights = []
    for step in steps:
        errors = predictions[selected, :, :step] - target[None, :, :step]
        local = fit_simplex(errors, ridge)
        full = np.zeros(n, dtype=np.float64)
        full[selected] = local
        weights.append(full)
    return {"steps": steps, "weights": np.stack(weights), "selected": selected.tolist()}


def expand_route(route: dict, length: int = 180) -> np.ndarray:
    steps = np.asarray(route["steps"], dtype=int)
    weights = np.asarray(route["weights"], dtype=np.float64)
    result = np.empty((length, weights.shape[1]), dtype=np.float64)
    if len(steps) == 1:
        result[:] = weights[0]
        return result
    result[: steps[0]] = weights[0]
    for left in range(len(steps) - 1):
        a, b = int(steps[left]), int(steps[left + 1])
        for index in range(a, b):
            alpha = (index - a + 1) / float(b - a)
            result[index] = (1 - alpha) * weights[left] + alpha * weights[left + 1]
    result[steps[-1] :] = weights[-1]
    result /= np.maximum(result.sum(axis=1, keepdims=True), 1e-12)
    return result


def blend(predictions: np.ndarray, route: dict) -> np.ndarray:
    return np.einsum("knte,tk->nte", predictions, expand_route(route)).astype(np.float32)


def choose_ridge(predictions: np.ndarray, target: np.ndarray, mmsi: np.ndarray, seed: int, name: str) -> tuple[float, list[dict]]:
    if name in {"best_single_val", "uniform_all", "uniform_top3_val"}:
        ridges = (0.0,)
    else:
        ridges = RIDGES
    rows = []
    folds = group_folds(mmsi, seed)
    for ridge in ridges:
        scores = []
        for held in folds:
            route = fit_route(predictions[:, ~held], target[~held], name, ridge)
            scores.append(objective(blend(predictions[:, held], route), target[held]))
        rows.append({
            "ridge": ridge,
            "fold_scores": scores,
            "mean": float(np.mean(scores)),
            "std": float(np.std(scores, ddof=0)),
            "selection_score": float(np.mean(scores) + 0.25 * np.std(scores, ddof=0)),
        })
    rows.sort(key=lambda r: (r["selection_score"], r["ridge"]))
    return float(rows[0]["ridge"]), rows


def load_validation(domain: str, seed: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    loaded = []
    for expert in EXPERTS:
        path = DIAGNOSTIC / "committee" / "prediction_cache" / expert / domain / f"seed_{seed}.npz"
        z = np.load(path)
        loaded.append(z)
    target = loaded[0]["target"].astype(np.float64)
    mmsi = loaded[0]["mmsi"].astype(np.int64)
    for z in loaded[1:]:
        if not np.allclose(z["target"], target, atol=1e-3):
            raise RuntimeError(f"validation alignment mismatch {domain}/{seed}")
    return np.stack([z["prediction"].astype(np.float64) for z in loaded]), target, mmsi


def expert_test(domain: str, seed: int) -> tuple[np.ndarray, np.ndarray]:
    predictions, target = [], None
    for expert in EXPERTS:
        path = run_path(DIAGNOSTIC, "router_sharp150_cov_0p0", expert, domain, seed) / "test_predictions.npz"
        z = np.load(path)
        key = "raw_prediction" if expert == "sa_repair" and "raw_prediction" in z else "prediction"
        predictions.append(z[key].astype(np.float64))
        if target is None:
            target = z["target"].astype(np.float64)
        elif not np.allclose(z["target"], target, atol=1e-3):
            raise RuntimeError(f"test expert alignment mismatch {domain}/{seed}")
    return np.stack(predictions), target


def comparator_test(model: str, domain: str, seed: int) -> tuple[np.ndarray, np.ndarray]:
    path = run_path(DIAGNOSTIC, "router_sharp150_cov_0p0", model, domain, seed) / "test_predictions.npz"
    z = np.load(path)
    return z["prediction"].astype(np.float64), z["target"].astype(np.float64)


def official_test(domain: str, seed: int) -> tuple[np.ndarray, np.ndarray]:
    z = np.load(OFFICIAL / domain / f"seed_{seed}" / "test_predictions.npz")
    return z["prediction"].astype(np.float64), z["target"].astype(np.float64)


def sample_metric(prediction: np.ndarray, target: np.ndarray, metric: str) -> np.ndarray:
    kind, horizon = metric.split("@")
    step = STEPS[int(horizon)]
    distance = np.linalg.norm(prediction - target, axis=-1)
    return distance[:, :step].mean(axis=1) if kind == "ADE" else distance[:, step - 1]


def cluster_bootstrap(diff: np.ndarray, mmsi: np.ndarray, draws: int, seed: int) -> dict:
    unique, inverse = np.unique(mmsi, return_inverse=True)
    sums = np.bincount(inverse, weights=diff, minlength=len(unique)).astype(np.float64)
    counts = np.bincount(inverse, minlength=len(unique)).astype(np.float64)
    rng = np.random.default_rng(seed)
    values = np.empty(draws, dtype=np.float64)
    chunk = 500
    for start in range(0, draws, chunk):
        size = min(chunk, draws - start)
        indices = rng.integers(0, len(unique), size=(size, len(unique)))
        values[start:start + size] = sums[indices].sum(axis=1) / counts[indices].sum(axis=1)
    p = min(1.0, 2 * min(float(np.mean(values <= 0)), float(np.mean(values >= 0))))
    return {
        "difference_mean": float(diff.mean()),
        "ci95_low": float(np.quantile(values, 0.025)),
        "ci95_high": float(np.quantile(values, 0.975)),
        "probability_ours_better": float(np.mean(values > 0)),
        "p_bootstrap_two_sided": p,
        "mmsi_clusters": int(len(unique)),
        "windows": int(len(diff)),
    }


def holm_adjust(rows: list[dict], key: str, output_key: str) -> None:
    order = sorted(range(len(rows)), key=lambda i: float(rows[i][key]))
    running = 0.0
    total = len(rows)
    for rank, index in enumerate(order):
        adjusted = min(1.0, (total - rank) * float(rows[index][key]))
        running = max(running, adjusted)
        rows[index][output_key] = running


def aggregate(rows: list[dict], names: tuple[str, ...]) -> list[dict]:
    output = []
    for domain in sorted({r["domain"] for r in rows}):
        for name in names:
            selected = [r for r in rows if r["domain"] == domain and r["variant"] == name]
            if not selected:
                continue
            row = {"domain": domain, "variant": name, "n_seeds": len(selected)}
            for metric in METRICS:
                values = np.asarray([r[metric] for r in selected])
                row[f"{metric}_mean"] = float(values.mean())
                row[f"{metric}_std"] = float(values.std(ddof=0))
            output.append(row)
    return output


def ensure_direct_lstm_validation(domains: tuple[str, ...], seeds: tuple[int, ...], workers: int) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    for domain in domains:
        scaler = RobustTrajectoryScaler.load(ROOT / "cache" / domain / "scaler.json")
        source = resolve_split_file(DATA_ROOT, domain, "val")
        cache = build_cache(source, ROOT / "cache" / domain, force=False)
        dataset = EnvShipDataset(cache, scaler)
        for seed in seeds:
            collect_validation(DIAGNOSTIC, "router_sharp150_cov_0p0", "direct_lstm", domain, seed, dataset, scaler, device, workers)


def make_figures(output: Path, aggregate_rows: list[dict], sensitivity: list[dict], bootstrap: list[dict], ensembles: list[dict]) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    figures = output / "figures"
    figures.mkdir(exist_ok=True)
    focus = ["best_single_val", "uniform_all", "global_simplex", "anchors_5_10_60", "anchors_5_10_20_30_45_60"]
    active_domains = tuple(d for d in DOMAINS if any(r["domain"] == d for r in aggregate_rows))
    fig, axes = plt.subplots(2, 2, figsize=(13, 8), constrained_layout=True)
    for ax, domain in zip(axes.flat, active_domains):
        subset = {r["variant"]: r for r in aggregate_rows if r["domain"] == domain}
        vals = [subset[x]["ADE@60_mean"] for x in focus if x in subset]
        labels = [x.replace("anchors_", "").replace("_simplex", "") for x in focus if x in subset]
        ax.bar(range(len(vals)), vals, color="#2a9d8f")
        ax.set_xticks(range(len(vals)), labels, rotation=25, ha="right", fontsize=8)
        ax.set_title(domain.upper()); ax.set_ylabel("ADE@60 (m)")
    fig.savefig(figures / "routing_ablation_ade60.png", dpi=220); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5), constrained_layout=True)
    selected = [r for r in sensitivity if r["fraction"] != "ridge_grid"]
    for domain in active_domains:
        for fraction in (0.25, 0.5, 0.75):
            vals = [r["heldout_objective"] for r in selected if r["domain"] == domain and float(r["fraction"]) == fraction]
            if vals:
                ax.scatter([fraction] * len(vals), vals, alpha=.28, s=12, label=f"{domain}-{fraction}" if len(vals) else None)
    ax.set_xlabel("Fraction of validation MMSIs used to fit router")
    ax.set_ylabel("Held-out validation objective J")
    ax.set_title("Router stability under MMSI-level validation subsampling")
    fig.savefig(figures / "validation_subsample_stability.png", dpi=220); plt.close(fig)

    primary = [r for r in bootstrap if r["metric"].startswith("ADE@") and r["comparator"] == r["validation_selected_comparator"]]
    fig, ax = plt.subplots(figsize=(11, 6), constrained_layout=True)
    labels = [f"{r['domain']} {r['metric']}" for r in primary]
    means = [r["difference_mean"] for r in primary]
    lower = [r["difference_mean"] - r["ci95_low"] for r in primary]
    upper = [r["ci95_high"] - r["difference_mean"] for r in primary]
    ax.errorbar(range(len(primary)), means, yerr=[lower, upper], fmt="o", capsize=3)
    ax.axhline(0, color="black", lw=1)
    ax.set_xticks(range(len(primary)), labels, rotation=45, ha="right", fontsize=8)
    ax.set_ylabel("Comparator error - ours (m)")
    ax.set_title("MMSI-cluster bootstrap differences against validation-selected comparator")
    fig.savefig(figures / "primary_ade_bootstrap_ci.png", dpi=220); plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5), constrained_layout=True)
    names = sorted({r["model"] for r in ensembles})
    x = np.arange(len(active_domains)); width = .8 / max(len(names), 1)
    for i, name in enumerate(names):
        vals = [next(r["ADE@60"] for r in ensembles if r["domain"] == d and r["model"] == name) for d in active_domains]
        ax.bar(x + (i - (len(names)-1)/2)*width, vals, width, label=name)
    ax.set_xticks(x, [d.upper() for d in active_domains]); ax.set_ylabel("ADE@60 (m)"); ax.legend(fontsize=7)
    ax.set_title("Three-seed homogeneous ensemble controls")
    fig.savefig(figures / "homogeneous_seed_ensemble_controls.png", dpi=220); plt.close(fig)


def main() -> int:
    parser = argparse.ArgumentParser(description="PLOS ONE rigor and routing evidence suite")
    parser.add_argument("--output", type=Path, default=ROOT / "plos_rigor_suite")
    parser.add_argument("--bootstrap", type=int, default=20000)
    parser.add_argument("--subsample-repeats", type=int, default=50)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve(); output.mkdir(parents=True, exist_ok=True)
    domains = DOMAINS[:1] if args.smoke else DOMAINS
    seeds = SEEDS[:1] if args.smoke else SEEDS
    if args.smoke:
        args.bootstrap = min(args.bootstrap, 200)
        args.subsample_repeats = min(args.subsample_repeats, 2)
    started = time.time()
    protocol = {
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "purpose": "PLOS ONE technical-rigor evidence; no model choice may use test labels",
        "domains": domains,
        "seeds": seeds,
        "experts": EXPERTS,
        "comparators": COMPARATORS,
        "routing_variants_predeclared": VARIANTS,
        "ridges_predeclared": RIDGES,
        "metrics_predeclared": METRICS,
        "bootstrap_draws": args.bootstrap,
        "test_read_before_protocol_lock": False,
    }
    atomic_json(output / "PROTOCOL_PRELOCK.json", protocol)

    status(output, "validation_cache", "Generating only missing validation predictions")
    ensure_direct_lstm_validation(domains, seeds, args.num_workers)

    status(output, "validation_selection", "Cross-validating every predeclared routing variant")
    fitted: dict[tuple[str, int, str], dict] = {}
    validation_rows, sensitivity_rows, selected_comparators = [], [], {}
    for domain in domains:
        for seed in seeds:
            predictions, target, mmsi = load_validation(domain, seed)
            for name in VARIANTS:
                ridge, ranking = choose_ridge(predictions, target, mmsi, seed, name)
                route = fit_route(predictions, target, name, ridge)
                fitted[(domain, seed, name)] = route
                validation_rows.append({
                    "domain": domain, "seed": seed, "variant": name, "ridge": ridge,
                    "cv_objective": ranking[0]["mean"], "cv_std": ranking[0]["std"],
                    "selected_experts": "+".join(EXPERTS[i] for i in route["selected"]),
                })
                if name == "anchors_5_10_60":
                    for item in ranking:
                        sensitivity_rows.append({
                            "domain": domain, "seed": seed, "fraction": "ridge_grid", "repeat": -1,
                            "ridge": item["ridge"], "heldout_objective": item["mean"],
                            "weight_l1_from_full": 0.0,
                        })
            final_route = fitted[(domain, seed, "anchors_5_10_60")]
            final_ridge = next(r["ridge"] for r in validation_rows if r["domain"] == domain and r["seed"] == seed and r["variant"] == "anchors_5_10_60")
            unique = np.unique(mmsi)
            rng = np.random.default_rng(1000 + seed)
            for fraction in (0.25, 0.5, 0.75):
                for repeat in range(args.subsample_repeats):
                    chosen = rng.choice(unique, size=max(2, int(round(len(unique) * fraction))), replace=False)
                    fit_mask = np.isin(mmsi, chosen); held = ~fit_mask
                    route = fit_route(predictions[:, fit_mask], target[fit_mask], "anchors_5_10_60", float(final_ridge))
                    sensitivity_rows.append({
                        "domain": domain, "seed": seed, "fraction": fraction, "repeat": repeat,
                        "ridge": final_ridge, "heldout_objective": objective(blend(predictions[:, held], route), target[held]),
                        "weight_l1_from_full": float(np.abs(route["weights"] - final_route["weights"]).mean()),
                    })

            # Comparator selection is validation-only and metric-specific.
            candidate_metrics = {}
            for model in COMPARATORS:
                path = DIAGNOSTIC / "committee" / "prediction_cache" / model / domain / f"seed_{seed}.npz"
                z = np.load(path)
                candidate_metrics[model] = displacement_metrics(z["prediction"], z["target"])
            for metric in METRICS:
                selected_comparators[(domain, seed, metric)] = min(COMPARATORS, key=lambda m: candidate_metrics[m][metric])

    write_csv(output / "validation_routing_selection.csv", validation_rows)
    write_csv(output / "validation_sensitivity.csv", sensitivity_rows)
    protocol["validation_completed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    protocol["validation_selected_comparators"] = {
        f"{d}/seed_{s}/{m}": c for (d, s, m), c in selected_comparators.items()
    }
    protocol["test_locked_after_validation"] = True
    atomic_json(output / "LOCKED_PROTOCOL_BEFORE_TEST.json", protocol)

    status(output, "test_once", "Evaluating all locked routing variants on the untouched test arrays")
    test_rows = []
    route_details = []
    for domain in domains:
        for seed in seeds:
            predictions, target = expert_test(domain, seed)
            for name in VARIANTS:
                prediction = blend(predictions, fitted[(domain, seed, name)])
                test_rows.append({"domain": domain, "seed": seed, "variant": name, **displacement_metrics(prediction, target)})
                route_details.append({"domain": domain, "seed": seed, "variant": name, **fitted[(domain, seed, name)]})
            official_prediction, official_target = official_test(domain, seed)
            test_rows.append({"domain": domain, "seed": seed, "variant": "official_v2", **displacement_metrics(official_prediction, official_target)})
            print(f"[test] {domain} seed={seed}", flush=True)
    write_csv(output / "routing_ablation_per_seed.csv", test_rows)
    aggregate_rows = aggregate(test_rows, VARIANTS + ("official_v2",))
    write_csv(output / "routing_ablation_mean_std.csv", aggregate_rows)
    atomic_json(output / "routing_weights_and_selections.json", route_details)

    status(output, "bootstrap", "MMSI-cluster paired bootstrap against all six learned comparators")
    bootstrap_rows = []
    for domain in domains:
        mmsi = np.load(ROOT / "cache" / domain / f"{domain}_test" / "mmsi.npy").astype(np.int64)
        ours_by_seed = []; target_reference = None
        comparator_by_model = {m: [] for m in COMPARATORS}
        for seed in seeds:
            ours, target = official_test(domain, seed); ours_by_seed.append(ours)
            target_reference = target if target_reference is None else target_reference
            for model in COMPARATORS:
                pred, other_target = comparator_test(model, domain, seed)
                if not np.allclose(other_target, target_reference, atol=1e-3):
                    raise RuntimeError(f"comparator target mismatch {model}/{domain}/{seed}")
                comparator_by_model[model].append(pred)
        for metric in METRICS:
            ours_error = np.mean([sample_metric(p, target_reference, metric) for p in ours_by_seed], axis=0)
            votes = [selected_comparators[(domain, seed, metric)] for seed in seeds]
            val_selected = max(COMPARATORS, key=lambda m: (votes.count(m), -COMPARATORS.index(m)))
            for model in COMPARATORS:
                comp_error = np.mean([sample_metric(p, target_reference, metric) for p in comparator_by_model[model]], axis=0)
                row = {
                    "domain": domain, "metric": metric, "comparator": model,
                    "validation_selected_comparator": val_selected,
                    **cluster_bootstrap(comp_error - ours_error, mmsi, args.bootstrap, 9000 + len(bootstrap_rows)),
                }
                bootstrap_rows.append(row)
    holm_adjust(bootstrap_rows, "p_bootstrap_two_sided", "p_holm_all_comparisons")
    write_csv(output / "mmsi_cluster_bootstrap_all_comparators.csv", bootstrap_rows)

    status(output, "ensemble_controls", "Building homogeneous three-seed compute controls")
    ensemble_rows = []
    ensemble_models = ("direct_gru", "transformer_cv", "itransformer_fa_faithful", "mstformer_faithful")
    for domain in domains:
        targets = None
        for model in ensemble_models:
            predictions = []
            for seed in seeds:
                pred, target = comparator_test(model, domain, seed)
                predictions.append(pred); targets = target
            ensemble_rows.append({"domain": domain, "model": f"3seed_{model}", **displacement_metrics(np.mean(predictions, axis=0), targets)})
        ours_predictions = [official_test(domain, seed)[0] for seed in seeds]
        ensemble_rows.append({"domain": domain, "model": "3seed_official_v2", **displacement_metrics(np.mean(ours_predictions, axis=0), targets)})
    write_csv(output / "homogeneous_seed_ensemble_controls.csv", ensemble_rows)

    status(output, "figures_report", "Rendering figures and writing manuscript-ready report")
    make_figures(output, aggregate_rows, sensitivity_rows, bootstrap_rows, ensemble_rows)
    primary = [r for r in bootstrap_rows if r["metric"] in {"ADE@5", "ADE@10", "ADE@60"} and r["comparator"] == r["validation_selected_comparator"]]
    positive = sum(r["ci95_low"] > 0 for r in primary)
    route_wins = 0; route_total = 0
    for domain in domains:
        rows = {r["variant"]: r for r in aggregate_rows if r["domain"] == domain}
        for metric in METRICS:
            route_total += 1
            if rows["anchors_5_10_60"][f"{metric}_mean"] <= min(rows["uniform_all"][f"{metric}_mean"], rows["global_simplex"][f"{metric}_mean"]):
                route_wins += 1
    report = f"""# PLOS ONE rigor suite report

## Locked protocol

- All routing variants and metrics were declared before test arrays were opened.
- Expert parameters remained frozen. Router fitting and comparator selection used validation data only.
- Test arrays were replayed once for every predeclared variant; no result was used to alter the model.

## Experiments completed

1. Twelve routing/fusion controls across {len(domains)} domains and {len(seeds)} seeds.
2. Six-value ridge grid and 25/50/75% MMSI-level validation subsampling ({args.subsample_repeats} repeats).
3. {args.bootstrap:,}-draw MMSI-cluster paired bootstrap against all six learned comparators.
4. Homogeneous three-seed ensembles, including an iTransformer control with parameter count close to the five-expert predictor.

## Headline diagnostics

- Three-anchor routing is no worse than both uniform and one-vector global simplex fusion in {route_wins}/{route_total} domain-metric cells.
- Against the validation-selected learned comparator, {positive}/{len(primary)} primary ADE cells have a strictly positive 95% MMSI-cluster bootstrap interval.
- These counts are descriptive technical checks, not permission to redesign the model after viewing test results.

See the CSV files for every seed, metric, confidence interval, route weight, and sensitivity replicate.
"""
    (output / "REPORT.md").write_text(report, encoding="utf-8")
    complete = {
        "complete": True,
        "started_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started)),
        "completed_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_seconds": time.time() - started,
        "route_wins_vs_uniform_and_global": route_wins,
        "route_cells": route_total,
        "primary_bootstrap_ci_strictly_positive": positive,
        "primary_bootstrap_cells": len(primary),
        "test_used_for_selection": False,
    }
    atomic_json(output / "COMPLETE.json", complete)
    status(output, "complete", "All tables, figures, and reports written", complete=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
