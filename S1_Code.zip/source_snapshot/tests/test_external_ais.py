import hashlib
import unittest
import numpy as np
from external_ais_prepare import make_window,project,split_of
from external_ais_common import SEEDS,BACKBONES,DOMAINS
from external_ais_train import spec

class ExternalAISTests(unittest.TestCase):
    def sample(self):
        t=1618800000.+np.arange(1200)*10
        a=np.zeros((len(t),6));a[:,0]=t;a[:,1]=230000001;a[:,2]=24.+np.arange(len(t))*.0001;a[:,3]=60.;a[:,4]=5.;a[:,5]=90.
        return a
    def test_projection_and_anchor(self):
        xy=project(np.array([24.,24.001]),np.array([60.,60.]),24.,60.)
        np.testing.assert_allclose(xy[0],0.);self.assertGreater(xy[1,0],55.);self.assertLess(xy[1,0],56.)
    def test_shapes_and_units(self):
        h,y,info=make_window(self.sample(),200);self.assertEqual(h.shape,(90,6));self.assertEqual(y.shape,(180,2))
        np.testing.assert_allclose(h[-1,:2],0.,atol=1e-6);np.testing.assert_allclose(h[:,3],5.);self.assertTrue(info['anchor_raw_observation'])
    def test_history_does_not_read_future(self):
        a=self.sample();h,y,_=make_window(a,200);a[201:,2:4]+=1
        changed,_,_=make_window(a,200);np.testing.assert_array_equal(h,changed)
    def test_no_stationary_windows(self):
        a=self.sample();a[:,2]=24.;self.assertIsNone(make_window(a,200))
    def test_no_extrapolated_future(self):self.assertIsNone(make_window(self.sample(),1100))
    def test_MMSI_split_is_stable(self):
        for m in range(230000001,230001001):
            b=int(hashlib.md5(str(m).encode()).hexdigest(),16)%10
            self.assertEqual(split_of(m),'val' if b==0 else 'test' if b==1 else 'train')
    def test_five_seed_protocol(self):
        self.assertEqual(len(SEEDS),5);self.assertEqual(len(BACKBONES),7);self.assertEqual(len(DOMAINS)*len(SEEDS)*8,160)
        self.assertEqual(spec('mstformer_faithful')['epochs'],20);self.assertEqual(spec('sa_repair','repair')['repair_seconds'],600)
    def test_angle_wrap_continuity(self):
        a=self.sample();a[:200,5]=359.;a[200:,5]=1.;h,_,_=make_window(a,200)
        self.assertTrue((h[:,5]>.99).all())

if __name__=='__main__':unittest.main()
