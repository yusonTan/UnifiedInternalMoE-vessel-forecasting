"""One isolated process per model/device, with explicit timing scope."""
from __future__ import annotations
import argparse
import time
import numpy as np
import torch
from torch import nn
import capacity_match_common as c
from comparison_models import DirectRNN
from faithful_sota_models import build_faithful_model
from amf.unified_predictor import UnifiedInternalMoE
from amf.data import RobustTrajectoryScaler


class Homogeneous(nn.Module):
    def __init__(self):
        super().__init__();self.models=nn.ModuleList([build_faithful_model('itransformer_fa_faithful') for _ in range(3)])
    def forward(self,x):
        return torch.stack([m(x) for m in self.models]).mean(0)


def build(kind,smoke=False):
    paths=[]
    if kind=='fusion':
        model=UnifiedInternalMoE();paths=[c.MAIN/'fusion_10seed_refit'/'dma'/'seed_42'/'best.pt']
    elif kind=='original_gru':
        model=DirectRNN('gru');paths=[c.run_of('direct_gru','dma',42)/'best.pt']
    elif kind=='wide_gru':
        model=DirectRNN('gru',hidden=c.HIDDEN);paths=[c.run('dma',42)/'best.pt']
    else:
        model=Homogeneous();paths=[c.run_of('itransformer_fa_faithful','dma',s)/'best.pt' for s in (42,52,62)]
    if not smoke:
        for module,path in zip(model.models if kind=='homogeneous_itransformer' else [model],paths):
            module.load_state_dict(torch.load(path,map_location='cpu',weights_only=False)['model'],strict=True)
    return model,paths


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--kind',choices=('fusion','original_gru','wide_gru','homogeneous_itransformer'),required=True)
    parser.add_argument('--device',choices=('cpu','cuda'),required=True);parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
    torch.set_num_threads(4);torch.set_num_interop_threads(2);c.check_frozen()
    device=torch.device(args.device)
    if args.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA cost test cannot silently fall back')
    if args.device=='cuda':torch.cuda.init();torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
    started=time.perf_counter(); model,paths=build(args.kind,args.smoke);model.to(device).eval()
    if args.device=='cuda':torch.cuda.synchronize()
    cold=time.perf_counter()-started
    scaler=RobustTrajectoryScaler.load(c.ROOT/'cache'/'dma'/'scaler.json')
    raw=np.load(c.ROOT/'cache'/'dma'/'dma_test'/'history.npy',mmap_mode='r')
    sync=lambda:torch.cuda.synchronize() if args.device=='cuda' else None
    warm,iterations,repeats=(1,2,1) if args.smoke else (50,200,3)
    rows=[]
    with torch.inference_mode():
        for batch in ((1,32) if args.device=='cuda' else (1,)):
            h=np.asarray(raw[:batch]).copy();x=torch.from_numpy(scaler.transform_history(h).copy()).to(device)
            for _ in range(warm):model(x)
            sync()
            for scope in ('model_only','cached_window_to_metric_prediction'):
                times=[];repeat_rows=[]
                for repeat in range(repeats):
                    current=[]
                    for _ in range(iterations):
                        sync();start=time.perf_counter()
                        if scope=='model_only':pred=model(x)
                        else:
                            xx=torch.from_numpy(scaler.transform_history(h).copy()).to(device)
                            pred=model(xx);restored=scaler.inverse_positions(pred.cpu().numpy())
                        sync();current.append((time.perf_counter()-start)*1000)
                    times.extend(current);repeat_rows.append({'repeat':repeat,'p50_ms':float(np.median(current)),'p95_ms':float(np.quantile(current,.95))})
                rows.append({'model':args.kind,'device':args.device,'batch':batch,'scope':scope,
                    'parameters':sum(p.numel() for p in model.parameters()),'p50_ms':float(np.median(times)),
                    'p95_ms':float(np.quantile(times,.95)),'throughput_samples_per_second':batch*1000/float(np.mean(times)),
                    'warmup_iterations':warm,'iterations_per_repeat':iterations,'repeats':repeats,'precision':'FP32',
                    'CPU_threads':4,'representative_domain':'dma','representative_seed':42,
                    'cold_model_build_load_to_device_seconds':cold,'source_checkpoint_bytes':sum(p.stat().st_size for p in paths) if not args.smoke else None,
                    'isolated_peak_GPU_allocated_MiB':torch.cuda.max_memory_allocated()/2**20 if args.device=='cuda' else None,
                    'not_raw_AIS_decode_or_network_latency':True,'repeat_measurements':repeat_rows})
    folder=c.OUT/('smoke/cost' if args.smoke else 'cost')
    c.atomic_json(folder/f'{args.kind}_{args.device}.json',{'complete':True,'rows':rows})
    print('Cost benchmark completed',flush=True)


if __name__=='__main__':main()
