"""Freeze all external routes, then evaluate sealed independent test once."""
from __future__ import annotations
import argparse
import csv
import gc
import os
from pathlib import Path
import numpy as np
import torch
import external_ais_common as c
from external_ais_train import build,run_dir
from amf.data import RobustTrajectoryScaler
from amf.unified_predictor import UnifiedInternalMoE
from evaluate_compact_committee import build_model
from revision_cv_transfer import scaler_for
from run_revision_10seed import run_of
from revision_5h_analysis import paired_uncertainty
from run_plos_rigor_suite import expand_route

def table(name,rows):
    if not rows:raise ValueError('Empty scientific result')
    p=c.OUT/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.csv.tmp')
    fields=list(dict.fromkeys(k for r in rows for k in r))
    with tmp.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    os.replace(tmp,p)

def errors(p,y):
    d=np.linalg.norm(p.astype(np.float64)-y.astype(np.float64),axis=-1)
    return {m:d[:,:3*int(m.split('@')[1])].mean(1) if m.startswith('ADE') else d[:,3*int(m.split('@')[1])-1] for m in c.METRICS}

def J(e):return (e['ADE@5'].mean()/20+e['ADE@10'].mean()/50+2*e['ADE@60'].mean()/600)/4

def blend(p,w):return np.einsum('nktd,tk->ntd',p,expand_route({'steps':[15,30,180],'weights':w})).astype(np.float32)

def best_run(name,seed):return run_dir(name,seed,'repair' if name=='sa_repair' else 'train')

def lock_comparators():
    from revision_extension_common import cv15
    val_truth=np.load(c.OUT/'cache/val/future.npy',mmap_mode='r');val_history=np.load(c.OUT/'cache/val/history.npy',mmap_mode='r')
    val_errors={'CV15':errors(cv15(val_history),val_truth)}
    for name in c.BACKBONES:
        values=[]
        for seed in c.SEEDS:
            with np.load(best_run(name,seed)/'validation_predictions.npz') as z:values.append(errors(z['prediction'],z['target']))
        val_errors[name]={m:float(np.mean([v[m].mean() for v in values])) for m in c.METRICS}
    selected={m:min(val_errors,key=lambda n:float(np.mean(val_errors[n][m]))) for m in c.METRICS}
    c.atomic_json(c.OUT/'fusion/COMPARATORS_LOCK.json',{'selected':selected,'selection_data':'external validation only','test_not_opened':True})

def fit_external_routes():
    import evaluate_compact_committee as compact
    directory=c.OUT/'fusion';directory.mkdir(parents=True,exist_ok=True)
    if (directory/'ROUTES_LOCK.json').exists():
        if not (directory/'COMPARATORS_LOCK.json').exists():lock_comparators()
        return
    options={};weights={};selections={};original=compact.CANDIDATES;compact.CANDIDATES=c.EXPERTS
    try:
        for seed in c.SEEDS:
            predictions={};truth=ids=None
            for name in c.EXPERTS:
                with np.load(best_run(name,seed)/'validation_predictions.npz') as z:
                    if truth is None:truth=z['target'].copy();ids=z['mmsi'].copy()
                    elif not np.array_equal(ids,z['mmsi']) or np.max(np.abs(truth-z['target']))>.05:raise RuntimeError('External validation candidate mismatch')
                    predictions[name]=z['prediction'].copy()
            chosen,local,_,ranking=compact.choose_committee(predictions,truth,ids,seed)
            w=np.zeros((3,5))
            for k,name in enumerate(chosen['candidates']):w[:,c.EXPERTS.index(name)]=local[:,k]
            weights[seed]=w;p=np.stack([predictions[n] for n in c.EXPERTS],axis=1)
            scores={}
            for name in (None,*c.EXPERTS):
                ww=w.copy()
                if name is not None:ww[:2]=0;ww[:2,c.EXPERTS.index(name)]=1
                scores['keep_committee' if name is None else name]=4*J(errors(blend(p,ww),truth))
            options[seed]=scores;selections[seed]={'chosen':chosen,'ranking':ranking,'validation_options':scores}
    finally:compact.CANDIDATES=original
    shared={name:float(np.mean([options[s][name] for s in c.SEEDS])) for name in options[c.SEEDS[0]]}
    specialist=min(c.EXPERTS,key=lambda n:shared[n])
    if shared[specialist]>=shared['keep_committee']-1e-5:specialist=None
    for seed in c.SEEDS:
        if specialist is not None:weights[seed][:2]=0;weights[seed][:2,c.EXPERTS.index(specialist)]=1
        model=UnifiedInternalMoE()
        for name,module in zip(c.EXPERTS,model.expert_modules):
            module.load_state_dict(torch.load(best_run(name,seed)/'best.pt',map_location='cpu',weights_only=False)['model'],strict=True)
        with torch.no_grad():model.global_route_logits.copy_(torch.log(torch.as_tensor(weights[seed].T,dtype=torch.float32).clamp_min(1e-12)))
        folder=directory/f'seed_{seed}';folder.mkdir(parents=True,exist_ok=True)
        torch.save({'model':model.state_dict(),'epoch':0,'scaler':c.read(c.OUT/'cache/scaler.json'),'protocol':'independent_Finnish_train_validation_only_shared_five_seed_route'},folder/'best.pt')
        c.atomic_json(folder/'config.json',{'model':'UnifiedInternalMoE','scaler':c.read(c.OUT/'cache/scaler.json'),
            'knot_weights':weights[seed],'shared_specialist':specialist,'test_used_for_selection':False,'shared_validation_seeds':c.SEEDS})
        del model
    c.atomic_json(directory/'ROUTES_LOCK.json',{'complete':True,'test_not_opened':True,'shared_validation_seeds':c.SEEDS,
        'weights':weights,'shared_short_specialist':specialist,'validation_scores':shared,'per_seed':selections,
        'route_rule':'same compact SA+at most2 family and shared short specialist as formal model'})
    lock_comparators()
    c.emit('all_external_routes_locked_before_test')

@torch.inference_mode()
def infer(model,scaler,history):
    model.cuda().eval();p=[]
    for first in range(0,len(history),32):
        x=torch.from_numpy(scaler.transform_history(np.asarray(history[first:first+32])).copy()).cuda()
        p.append(scaler.inverse_positions(model(x).float().cpu().numpy()).astype(np.float32))
    return np.concatenate(p)

def model_eval(mode,source,seed,name):
    folder=c.OUT/'evaluation'/mode/source/f'seed_{seed}';folder.mkdir(parents=True,exist_ok=True);path=folder/(name+'.npz');receipt=folder/(name+'.json')
    if receipt.exists():
        r=c.read(receipt)
        if c.sha(path)!=r['prediction_sha256']:raise RuntimeError('Completed independent prediction changed')
        return r['row']
    if mode=='source_only':
        run,scaler=scaler_for(name,source,seed)
        model=UnifiedInternalMoE() if name=='UnifiedInternalMoE' else build_model(name,run)
    else:
        run=c.OUT/'fusion'/f'seed_{seed}' if name=='UnifiedInternalMoE' else best_run(name,seed)
        scaler=RobustTrajectoryScaler.load(c.OUT/'cache/scaler.json')
        model=UnifiedInternalMoE() if name=='UnifiedInternalMoE' else build(name,'repair' if name=='sa_repair' else 'train')
    model.load_state_dict(torch.load(run/'best.pt',map_location='cpu',weights_only=False)['model'],strict=True)
    history=np.load(c.OUT/'cache/test/history.npy',mmap_mode='r');truth=np.load(c.OUT/'cache/test/future.npy',mmap_mode='r');ids=np.load(c.OUT/'cache/test/mmsi.npy',mmap_mode='r')
    p=infer(model,scaler,history)
    if not np.isfinite(p).all():raise RuntimeError('Nonfinite independent prediction')
    e=errors(p,truth)
    c.archive(path,prediction=p,target=np.asarray(truth),mmsi=np.asarray(ids),window_index=np.arange(len(ids)),**{k:v.astype(np.float32) for k,v in e.items()})
    row={'mode':mode,'source':source,'model':name,'seed':seed,'test_J':J(e),**{k:float(v.mean()) for k,v in e.items()},
        'checkpoint_sha256':c.sha(run/'best.pt'),'target_train_validation_used':mode=='independently_trained'}
    c.atomic_json(receipt,{'row':row,'source_checkpoint':str(run/'best.pt'),'scaler':scaler.__dict__,'prediction_sha256':c.sha(path)})
    del model;torch.cuda.empty_cache();gc.collect();c.emit('independent_test_model_complete',mode=mode,source=source,seed=seed,model=name)
    return row

def mean_std(rows,keys):
    out=[]
    for group in sorted({tuple(r[k] for k in keys) for r in rows}):
        rr=[r for r in rows if tuple(r[k] for k in keys)==group]
        if len(rr)!=5 or {r['seed'] for r in rr}!=set(c.SEEDS):raise RuntimeError('Incomplete external five-seed cohort')
        r=dict(zip(keys,group));r['n_seeds']=5
        for m in ('test_J',*c.METRICS):
            v=np.asarray([x[m] for x in rr]);r[m+'_mean']=float(v.mean());r[m+'_std']=float(v.std(ddof=1))
        out.append(r)
    return out

def evaluate_all():
    if not (c.OUT/'ALL_SELECTIONS_LOCK.json').exists():raise RuntimeError('All training and routes must freeze before independent test')
    rows=[]
    for seed in c.SEEDS:
        for name in (*c.BACKBONES,'UnifiedInternalMoE'):
            rows.append(model_eval('independently_trained','finland',seed,name))
    for source in c.DOMAINS:
        for seed in c.SEEDS:
            for name in (*c.BACKBONES,'UnifiedInternalMoE'):rows.append(model_eval('source_only',source,seed,name))
    if len(rows)!=200:raise RuntimeError('Expected 200 independent-test model rows')
    table('independent_per_seed.csv',rows);means=mean_std(rows,('mode','source','model'));table('independent_mean_std.csv',means)
    from revision_extension_common import cv15
    truth=np.load(c.OUT/'cache/test/future.npy',mmap_mode='r');history=np.load(c.OUT/'cache/test/history.npy',mmap_mode='r');ids=np.load(c.OUT/'cache/test/mmsi.npy')
    p=cv15(history);e=errors(p,truth);c.archive(c.OUT/'evaluation/CV15.npz',prediction=p,target=truth,mmsi=ids,window_index=np.arange(len(ids)),**e)
    table('independent_CV15_reference.csv',[{'model':'CV15','n_training_seeds':0,'deterministic':True,'test_J':J(e),**{k:float(v.mean()) for k,v in e.items()}}])
    # Choose the comparator by external VALIDATION predictions, never test rank.
    selected=c.read(c.OUT/'fusion/COMPARATORS_LOCK.json')['selected']
    evidence=[]
    for m in c.METRICS:
        diffs=[];comparator=selected[m]
        for s in c.SEEDS:
            base=c.OUT/'evaluation/independently_trained/finland'/f'seed_{s}'
            with np.load(base/'UnifiedInternalMoE.npz') as z:ours=z[m].astype(np.float64)
            if comparator=='CV15':other=e[m]
            else:
                with np.load(base/(comparator+'.npz')) as z:other=z[m].astype(np.float64)
            diffs.append(other-ours)
        result=paired_uncertainty(np.stack(diffs),ids,np.random.default_rng(16102026+len(evidence)),draws=10000)
        evidence.append({'metric':m,'validation_selected_comparator':comparator,'shared_route_intervals_conditional':True,**result})
    for tag,mm in (('primary_ADE_3cell_Holm_p',('ADE@5','ADE@10','ADE@60')),('anchor_FDE_3cell_Holm_p',('FDE@5','FDE@10','FDE@60')),('secondary_6cell_Holm_p',tuple(m for m in c.METRICS if m.split('@')[1] not in ('5','10','60')))):
        subset=sorted([r for r in evidence if r['metric'] in mm],key=lambda r:r['wild_cluster_t_p']);running=0.
        for i,r in enumerate(subset):running=max(running,min(1.,(len(subset)-i)*r['wild_cluster_t_p']));r[tag]=running
    table('independent_paired_uncertainty.csv',evidence)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    r=[x for x in means if x['mode']=='independently_trained'];fig,ax=plt.subplots(figsize=(11,5),layout='constrained')
    ax.bar(range(len(r)),[x['ADE@60_mean'] for x in r],yerr=[x['ADE@60_std'] for x in r],capsize=3)
    ax.set_xticks(range(len(r)),[x['model'] for x in r],rotation=35,ha='right');ax.set_ylabel('Independent Finnish ADE@60 (m), mean +/- sample SD')
    fig.savefig(c.OUT/'independent_ADE60.png',dpi=220);fig.savefig(c.OUT/'independent_ADE60.pdf');plt.close(fig)
    (c.OUT/'REPORT.md').write_text('# Independent Finnish AIS validation\n\n'
        'Source: Zenodo 10.5281/zenodo.8112336, CC BY 4.0. Earliest available consecutive week, moving-vessel QC subset; not the full Finnish archive. '
        'All EnvShip MMSIs excluded; external train/validation/test are MMSI disjoint. History construction is causal. '
        'Set A uses frozen source-only models and source scalers; set B independently trains the same seven backbones and packs five experts in one checkpoint. '
        'Five seeds, no source/model/variant selected using this external test. All training and routes locked before testing. '
        'Report all negative results. Shared five-seed validation routing makes intervals conditional; vessel-cluster inference is approximate. '
        'Individual archive members have CRC and download SHA verification; no claim of verifying the full 43.6 GB ZIP MD5.\n',encoding='utf-8')
    c.emit('independent_evaluation_complete',per_seed_rows=200,summary_rows=40)

def main():
    a=argparse.ArgumentParser();a.add_argument('phase',choices=('fit','test'));args=a.parse_args();torch.set_num_threads(4)
    if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
    if args.phase=='fit':fit_external_routes()
    else:evaluate_all()

if __name__=='__main__':main()
