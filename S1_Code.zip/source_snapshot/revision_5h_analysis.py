"""Frozen-expert revision controls; all new selection is validation-only."""
from __future__ import annotations

import math
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from amf.adaptive_moe import AdaptivePhysicsExperts
from amf.metrics import displacement_metrics
from evaluate_compact_committee import fit_simplex, group_folds
from run_plos_rigor_suite import atomic_json, write_csv, expand_route
from run_revision_5h import (ROOT, OUT, DOMAINS, SEEDS, EXPERTS, DEVICE, canonical,
                             arrays, source_config, load_final, forward_final, archive, log,
                             RobustTrajectoryScaler)

HORIZONS = (5, 10, 20, 30, 45, 60)
STEPS = (15, 30, 60, 90, 135, 180)
HEADS = ("learned_global", "mlp", "gru", "gru_disagreement")
STATIC = ("best_single", "uniform_all", "global_simplex", "three_anchor")
RIDGES = (0., .01, .2)


def check_time(deadline, reserve=0):
    if time.time() + reserve >= deadline:
        raise TimeoutError("Predeclared phase budget exhausted; finished runs remain on disk")


def jscore(p, y, scales=(20., 50., 600.), horizon_weights=(1., 1., 2.)):
    distance = np.linalg.norm(p.astype(np.float64) - y.astype(np.float64), axis=-1)
    return float(sum(w * distance[:, :s].mean() / scale for s, scale, w in zip((15, 30, 180), scales, horizon_weights)) / sum(horizon_weights))


def route_fit(p, y, kind="three_anchor", ridge=.01, steps=None):
    if kind == "best_single":
        scores = [jscore(x, y) for x in p.transpose(1, 0, 2, 3)]
        w = np.zeros((1, p.shape[1]))
        w[0, np.argmin(scores)] = 1
        return {"steps": [180], "weights": w}
    if kind == "uniform_all":
        return {"steps": [180], "weights": np.full((1, p.shape[1]), 1 / p.shape[1])}
    steps = steps or ([180] if kind == "global_simplex" else [15, 30, 180])
    weights = [fit_simplex((p[:, :, :s] - y[:, None, :s]).transpose(1, 0, 2, 3), ridge) for s in steps]
    return {"steps": steps, "weights": np.stack(weights)}


def route_blend(p, route):
    return np.einsum("nktd,tk->ntd", p, expand_route(route)).astype(np.float32)


def pick_ridge(p, y, mmsi, seed, kind="three_anchor", steps=None, scales=(20., 50., 600.)):
    choices = (0.,) if kind in ("best_single", "uniform_all") else RIDGES
    rows = []
    for ridge in choices:
        scores = []
        for held in group_folds(mmsi, seed):
            fitted = route_fit(p[~held], y[~held], kind, ridge, steps)
            scores.append(jscore(route_blend(p[held], fitted), y[held], scales=scales))
        rows.append((float(np.mean(scores) + .25 * np.std(scores)), ridge))
    return min(rows)[1]


def get_data(domain, seed, split):
    z = np.load(canonical(domain, seed, split))
    scaler = RobustTrajectoryScaler(**source_config(domain, seed)["scaler"])
    history = scaler.transform_history(np.asarray(arrays(domain, split)[0])).astype(np.float32)
    return z, history


class SampleGate(nn.Module):
    def __init__(self, kind, weights):
        super().__init__()
        self.kind = kind
        self.base = nn.Parameter(torch.log(torch.as_tensor(weights, dtype=torch.float32).clamp_min(1e-4)))
        if kind in ("gru", "gru_disagreement"):
            self.encoder = nn.GRU(6, 32, batch_first=True)
            width = 32 + (12 if kind == "gru_disagreement" else 0)
        else:
            width = 20
        if kind != "learned_global":
            self.head = nn.Sequential(nn.Linear(width, 32), nn.GELU(), nn.Linear(32, 15))
            nn.init.zeros_(self.head[-1].weight)
            nn.init.zeros_(self.head[-1].bias)
        basis = expand_route({"steps": [15, 30, 180], "weights": np.eye(3)})
        self.register_buffer("basis", torch.as_tensor(basis, dtype=torch.float32))

    def forward(self, history, candidates):
        if self.kind == "learned_global":
            logits = self.base[None].expand(len(history), -1, -1)
        else:
            if self.kind.startswith("gru"):
                encoded, _ = self.encoder(history)
                features = encoded[:, -1]
                if self.kind == "gru_disagreement":
                    diff = torch.linalg.vector_norm(candidates[:, 1:, [14, 29, 179]] - candidates[:, :1, [14, 29, 179]], dim=-1)
                    features = torch.cat((features, torch.log1p(diff).flatten(1)), dim=1)
            else:
                features = torch.cat((history[:, -1], history.mean(1), history.std(1), (history[:, -1, :2] - history[:, 0, :2]) / 90), dim=1)
            logits = self.base[None] + 3 * torch.tanh(self.head(features).reshape(-1, 3, 5))
        weights = torch.einsum("nak,ta->ntk", logits.softmax(-1), self.basis)
        return torch.einsum("ntk,nktd->ntd", weights, candidates)


def tensor_loss(p, y):
    d = torch.linalg.vector_norm(p - y, dim=-1)
    return (d[:, :15].mean() * 30 + d[:, :30].mean() * 12 + 2 * d.mean()) / 4


@torch.inference_mode()
def gate_predict(model, history, p):
    out = []
    for i in range(0, len(history), 256):
        x = torch.from_numpy(history[i:i + 256]).to(DEVICE)
        c = torch.from_numpy(p[i:i + 256] / 600).to(DEVICE)
        out.append((model(x, c) * 600).cpu().numpy())
    return np.concatenate(out).astype(np.float32)


def train_head(kind, history, p, y, mmsi, seed, epochs=None, ridge=.01, deadline=math.inf):
    # The inner fold determines the number of epochs. Outer fold labels are never read here.
    inner = group_folds(mmsi, seed + 400)[0] if epochs is None else np.zeros(len(mmsi), dtype=bool)
    train = ~inner
    initial = route_fit(p[train], y[train], ridge=ridge)
    torch.manual_seed(seed)
    model = SampleGate(kind, initial["weights"]).to(DEVICE)
    optimizer = torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001)
    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    best_epoch = 0
    best_score = jscore(gate_predict(model, history[inner], p[inner]), y[inner]) if epochs is None else None
    records = [{"epoch": 0, "inner_J": best_score}]
    rng = np.random.default_rng(seed)
    start = time.time()
    fit_deadline = min(deadline - 5, start + 90)
    completed_epochs, stale = 0, 0
    for epoch in range(1, (40 if epochs is None else epochs) + 1):
        if time.time() >= fit_deadline:
            break
        model.train()
        indices = rng.permutation(np.flatnonzero(train))
        for begin in range(0, len(indices), 256):
            ii = indices[begin:begin + 256]
            x = torch.from_numpy(history[ii]).to(DEVICE)
            c = torch.from_numpy(p[ii] / 600).to(DEVICE)
            target = torch.from_numpy(y[ii] / 600).to(DEVICE)
            optimizer.zero_grad(set_to_none=True)
            loss = tensor_loss(model(x, c), target)
            if not torch.isfinite(loss):
                raise RuntimeError("Nonfinite gate loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
            optimizer.step()
        completed_epochs = epoch
        model.eval()
        if epochs is not None:
            continue
        score = jscore(gate_predict(model, history[inner], p[inner]), y[inner])
        records.append({"epoch": epoch, "inner_J": score})
        if score < best_score - 1e-7:
            best_score, best_epoch, stale = score, epoch, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
        if stale >= 8:
            break
    if epochs is None:
        model.load_state_dict(best_state)
    model.eval()
    return model, {"selected_epochs": best_epoch if epochs is None else epochs, "completed_epochs": completed_epochs,
                   "actual_refit_epochs": completed_epochs if epochs is not None else None,
                   "seconds": time.time() - start, "curve": records,
                   "time_limited": time.time() >= fit_deadline}


def routing(deadline):
    results, outer_rows, histories = [], [], []
    for domain in DOMAINS:
        for seed in SEEDS:
            destination = OUT / "routing" / domain / f"seed_{seed}"
            marker = destination / "COMPLETE.json"
            if marker.exists():
                prior = __import__("json").loads(marker.read_text(encoding="utf-8"))
                results.extend(prior["results"]); outer_rows.extend(prior["outer"])
                continue
            check_time(deadline, 60)
            z, x = get_data(domain, seed, "val")
            p, y, ids = z["experts"], z["target"], z["mmsi"]
            folds = group_folds(ids, seed)
            oof = {name: np.empty_like(y) for name in (*STATIC, *HEADS)}
            local_outer, local_results = [], []
            for fold, held in enumerate(folds):
                check_time(deadline, 20)
                for name in STATIC:
                    ridge = pick_ridge(p[~held], y[~held], ids[~held], seed + fold, name)
                    route = route_fit(p[~held], y[~held], name, ridge)
                    oof[name][held] = route_blend(p[held], route)
                    local_outer.append({"domain": domain, "seed": seed, "fold": fold, "variant": name,
                                        "ridge": ridge, "J": jscore(oof[name][held], y[held])})
                ridge = pick_ridge(p[~held], y[~held], ids[~held], seed + fold)
                for name in HEADS:
                    check_time(deadline, 10)
                    model, selected = train_head(name, x[~held], p[~held], y[~held], ids[~held], seed + fold, ridge=ridge, deadline=deadline)
                    epoch = selected["selected_epochs"]
                    del model
                    model, refit = train_head(name, x[~held], p[~held], y[~held], ids[~held], seed + fold, epochs=epoch, ridge=ridge, deadline=deadline)
                    oof[name][held] = gate_predict(model, x[held], p[held])
                    local_outer.append({"domain": domain, "seed": seed, "fold": fold, "variant": name,
                                        "ridge": ridge, "J": jscore(oof[name][held], y[held])})
                    histories.append({"domain": domain, "seed": seed, "fold": fold, "head": name,
                                      "inner_selection": selected, "outer_train_refit": refit})
                    del model
                log("routing_outer_fold", domain=domain, seed=seed, fold=fold)
            # All decisions below use validation only. No new test-based checkpoint selection.
            final_ridge = pick_ridge(p, y, ids, seed)
            final_models, static_routes, choices = {}, {}, {}
            for name in STATIC:
                ridge = pick_ridge(p, y, ids, seed, name)
                static_routes[name] = route_fit(p, y, name, ridge)
            for name in HEADS:
                check_time(deadline, 10)
                model, choice = train_head(name, x, p, y, ids, seed, ridge=final_ridge, deadline=deadline)
                del model
                model, refit = train_head(name, x, p, y, ids, seed, epochs=choice["selected_epochs"], ridge=final_ridge, deadline=deadline)
                final_models[name] = model
                choices[name] = {"selection": choice, "refit": refit}
                destination.mkdir(parents=True, exist_ok=True)
                temp = destination / f"{name}.tmp.pt"
                torch.save({"model": model.state_dict(), "kind": name, "ridge": final_ridge, "choice": choices[name]}, temp)
                temp.replace(destination / f"{name}.pt")
            atomic_json(destination / "VALIDATION_SELECTION_LOCK.json", {"choices": choices, "static_routes": static_routes,
                        "test_used_for_new_selection": False, "historical_test_previously_observed": True})
            test, xt = get_data(domain, seed, "test")
            for name in (*STATIC, *HEADS):
                prediction = route_blend(test["experts"], static_routes[name]) if name in STATIC else gate_predict(final_models[name], xt, test["experts"])
                archive(destination / f"{name}_test.npz", prediction=prediction, target=test["target"], mmsi=test["mmsi"], window_index=test["window_index"])
                archive(destination / f"{name}_validation_oof.npz", prediction=oof[name], target=y, mmsi=ids)
                local_results.append({"domain": domain, "seed": seed, "variant": name,
                                      "outer_validation_J": jscore(oof[name], y), "test_J": jscore(prediction, test["target"]),
                                      **displacement_metrics(prediction, test["target"])})
            results.extend(local_results); outer_rows.extend(local_outer)
            write_csv(OUT / "routing_per_seed.csv", results)
            write_csv(OUT / "routing_outer_folds.csv", outer_rows)
            atomic_json(OUT / "routing_training_curves.json", histories)
            atomic_json(marker, {"complete": True, "results": local_results, "outer": local_outer})
            log("routing_run_complete", domain=domain, seed=seed)
    write_csv(OUT / "routing_mean_std.csv", aggregate(results, "variant"))
    screening = []
    for name in HEADS:
        regional = []
        for domain in DOMAINS:
            ref = np.mean([r["outer_validation_J"] for r in results if r["domain"] == domain and r["variant"] == "three_anchor"])
            val = np.mean([r["outer_validation_J"] for r in results if r["domain"] == domain and r["variant"] == name])
            regional.append((domain, ref, val, (ref - val) / ref))
        macro_gain = (np.mean([r[1] for r in regional]) - np.mean([r[2] for r in regional])) / np.mean([r[1] for r in regional])
        screening.append({"variant": name, "validation_macro_relative_gain": macro_gain,
                          "worst_region_relative_gain": min(r[3] for r in regional),
                          "passes_predeclared_validation_screen": macro_gain >= .01 and min(r[3] for r in regional) >= -.02})
    write_csv(OUT / "routing_validation_screen.csv", screening)
    atomic_json(OUT / "routing_COMPLETE.json", {"complete": True, "runs": 12, "screening": screening,
                    "new_backbone_seeds": 0, "nested_MMSI_validation": True})


def aggregate(rows, key):
    out = []
    for domain in sorted({r["domain"] for r in rows}):
        for method in sorted({r[key] for r in rows if r["domain"] == domain}):
            group = [r for r in rows if r["domain"] == domain and r[key] == method]
            row = {"domain": domain, key: method, "n_seeds": len(group)}
            for metric in (*[f"{a}@{h}" for h in HORIZONS for a in ("ADE", "FDE")], "outer_validation_J", "test_J"):
                if metric not in group[0]:
                    continue
                values = [r[metric] for r in group]
                row[metric + "_mean"] = float(np.mean(values))
                row[metric + "_std"] = float(np.std(values, ddof=1)) if len(values) > 1 else None
            out.append(row)
    return out


@torch.inference_mode()
def transfer(deadline):
    rows = []
    for source in DOMAINS:
        for seed in SEEDS:
            check_time(deadline, 30)
            model = load_final(source, seed)
            scaler = RobustTrajectoryScaler(**source_config(source, seed)["scaler"])
            for target in DOMAINS:
                if source == target:
                    continue
                check_time(deadline, 10)
                path = OUT / "transfer" / source / target / f"seed_{seed}.npz"
                history, truth, ids = arrays(target, "test")
                if path.exists():
                    loaded = np.load(path)
                else:
                    pred, expert = forward_final(model, history, scaler)
                    h = torch.from_numpy(np.asarray(history[..., :2]).copy())
                    cv15 = AdaptivePhysicsExperts._cv(h, 15, torch.arange(1, 181).view(1, -1, 1)).numpy()
                    archive(path, final=pred, sa_repair=expert[:, 0], mstformer=expert[:, 3], direct_gru=expert[:, 4],
                            cv15=cv15, target=np.asarray(truth), mmsi=np.asarray(ids), window_index=np.arange(len(ids)))
                    loaded = np.load(path)
                for name in ("final", "sa_repair", "mstformer", "direct_gru", "cv15"):
                    rows.append({"domain": target, "source": source, "seed": seed, "method": name,
                                 **displacement_metrics(loaded[name], loaded["target"])})
                write_csv(OUT / "cross_domain_per_seed.csv", rows)
                log("transfer_pair_complete", source=source, target=target, seed=seed)
            del model
            torch.cuda.empty_cache()
    summary = []
    for source in DOMAINS:
        group = [r for r in rows if r["source"] == source]
        summary.extend({"source": source, **r} for r in aggregate(group, "method"))
    write_csv(OUT / "cross_domain_mean_std.csv", summary)
    atomic_json(OUT / "transfer_COMPLETE.json", {"complete": True, "directions": 12, "seeds": 3,
                "target_train_or_validation_used": False, "scaler_and_router": "source-only frozen"})


def method_predictions(z, history):
    result = {"final": z["prediction"], **{name: z["experts"][:, i] for i, name in enumerate(EXPERTS)},
              "direct_lstm": z["direct_lstm"], "tcn_cv": z["tcn_cv"]}
    positions = torch.from_numpy(np.asarray(history[..., :2]).copy())
    result["cv15"] = AdaptivePhysicsExperts._cv(positions, 15, torch.arange(1, 181).view(1, -1, 1)).numpy()
    return result


def audit_reasons(deadline):
    """Verify, rather than assume, why the earlier committee differs."""
    import csv
    import json
    from evaluate_compact_committee import run_path
    with (OUT / "prediction_source_audit.csv").open(encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    details = []
    for row in rows:
        domain, seed = row["domain"], int(row["seed"])
        z = np.load(canonical(domain, seed, "test"))
        selection = json.loads((ROOT / "eight_hour_diagnostic" / "committee" / domain / f"seed_{seed}" / "selection.json").read_text(encoding="utf-8"))
        weights = np.zeros((3, 5))
        for index, name in enumerate(selection["selected"]["candidates"]):
            weights[:, EXPERTS.index(name)] = np.asarray(selection["knot_weights_5_10_60"])[:, index]
        cached = []
        for name in EXPERTS:
            old = np.load(run_path(ROOT / "eight_hour_diagnostic", "router_sharp150_cov_0p0", name, domain, seed) / "test_predictions.npz")
            key = "raw_prediction" if name == "sa_repair" and "raw_prediction" in old else "prediction"
            cached.append(old[key])
        old_committee_rebuilt = route_blend(np.stack(cached, axis=1), {"steps": [15, 30, 180], "weights": weights})
        old_committee = np.load(ROOT / "eight_hour_diagnostic" / "committee" / domain / f"seed_{seed}" / "test_predictions.npz")["prediction"]
        frozen_rebuilt = route_blend(z["experts"], {"steps": [15, 30, 180], "weights": z["knot_weights"]})
        changed = float(np.abs(weights - z["knot_weights"]).max())
        reason = "validation-only short-specialist override changes first two anchors" if changed > 1e-6 else "same routing; numerical implementation/batching differences"
        committee_residual = float(np.abs(old_committee_rebuilt - old_committee).max())
        final_residual = float(np.abs(frozen_rebuilt - z["prediction"]).max())
        row["committee_difference_reason"] = reason
        row["committee_reconstruction_residual_m"] = committee_residual
        row["formal_fusion_reconstruction_residual_m"] = final_residual
        row["maximum_anchor_weight_change"] = changed
        details.append({"domain": domain, "seed": seed, "reason": reason, "committee_original_weights": weights,
                        "formal_weights": z["knot_weights"], "committee_residual_m": committee_residual,
                        "formal_residual_m": final_residual})
        if committee_residual > .05 or final_residual > .05:
            raise RuntimeError(f"Unexplained reconstruction difference in {domain}/{seed}")
    write_csv(OUT / "prediction_source_audit.csv", rows)
    atomic_json(OUT / "committee_difference_explanation.json", {"verified": True, "details": details})
    log("committee_difference_verified", runs=len(rows))


def sample_error(p, y, metric):
    kind, horizon = metric.split("@")
    step = int(horizon) * 3
    distance = np.linalg.norm(p.astype(np.float64) - y.astype(np.float64), axis=-1)
    return distance[:, :step].mean(1) if kind == "ADE" else distance[:, step - 1]


def paired_uncertainty(diff, mmsi, rng, draws=10000):
    # diff: aligned backbone seeds x windows. Shared routing choices make the
    # crossed interval descriptive/conditional, not proof of independent fits.
    groups, inverse = np.unique(mmsi, return_inverse=True)
    count = np.bincount(inverse).astype(float)
    sums = np.stack([np.bincount(inverse, weights=d, minlength=len(groups)) for d in diff])
    averaged = sums.mean(0)
    point = float(diff.mean())
    residual = averaged - count * point
    g = len(groups)
    se = math.sqrt(g / max(g - 1, 1) * np.sum(residual**2)) / count.sum()
    vessel_only, crossed, seed_only, wild_t = [], [], [], []
    for first in range(0, draws, 256):
        size = min(256, draws - first)
        vessel_weights = rng.multinomial(g, np.full(g, 1 / g), size=size)
        denominators = vessel_weights @ count
        vessel_only.extend((vessel_weights @ averaged / denominators).tolist())
        seed_weights = rng.multinomial(len(diff), np.full(len(diff), 1 / len(diff)), size=size) / len(diff)
        sampled = seed_weights @ sums
        crossed.extend(((sampled * vessel_weights).sum(1) / denominators).tolist())
        seed_only.extend((sampled.sum(1) / count.sum()).tolist())
        wild = rng.choice((-1., 1.), size=(size, g)) * residual
        null_delta = wild.sum(1) / count.sum()
        null_se = np.sqrt(g / max(g - 1, 1) * ((wild - null_delta[:, None] * count)**2).sum(1)) / count.sum()
        wild_t.extend((null_delta / np.maximum(null_se, 1e-12)).tolist())
    intervals = {}
    for name, values in (("MMSI", vessel_only), ("seed", seed_only), ("crossed", crossed)):
        intervals[name + "_CI_low"], intervals[name + "_CI_high"] = map(float, np.quantile(values, [.025, .975]))
    observed = point / max(se, 1e-12)
    intervals["wild_cluster_t_p"] = float((1 + np.sum(np.abs(wild_t) >= abs(observed))) / (draws + 1))
    return {"difference_m_comparator_minus_final": point, "MMSI_groups": g,
            "cluster_weight_concentration_effective_count": float(count.sum()**2 / np.sum(count**2)),
            "descriptive_crossed_interval_shared_router_dependence": True, **intervals}


def statistics(deadline):
    rows, influence, resampling = [], [], []
    for domain in DOMAINS:
        val, test = [], []
        for seed in SEEDS:
            zv = np.load(canonical(domain, seed, "val"))
            zt = np.load(canonical(domain, seed, "test"))
            val.append((zv, method_predictions(zv, arrays(domain, "val")[0])))
            test.append((zt, method_predictions(zt, arrays(domain, "test")[0])))
        ids = test[0][0]["mmsi"]
        for metric in [f"{kind}@{h}" for h in HORIZONS for kind in ("ADE", "FDE")]:
            check_time(deadline, 5)
            comparators = [n for n in val[0][1] if n != "final"]
            selected = min(comparators, key=lambda n: np.mean([sample_error(v[n], z["target"], metric).mean() for z, v in val]))
            ours = np.stack([sample_error(v["final"], z["target"], metric) for z, v in test])
            for comparator in comparators:
                comp = np.stack([sample_error(v[comparator], z["target"], metric) for z, v in test])
                uncertainty = paired_uncertainty(comp - ours, ids, np.random.default_rng(6000 + len(rows)))
                row = {"domain": domain, "metric": metric, "comparator": comparator,
                       "validation_selected_comparator": selected, "final_mean_m": float(ours.mean()),
                       "comparator_mean_m": float(comp.mean()), "relative_gain_percent": float(100 * (comp.mean() - ours.mean()) / max(comp.mean(), 1e-12)),
                       "numerical_tie_at_display_precision_0p001m": abs(comp.mean() - ours.mean()) < .0005,
                       **uncertainty}
                rows.append(row)
                if domain == "piraeus" and comparator == selected:
                    delta = (comp - ours).mean(0)
                    for identifier in np.unique(ids):
                        mask = ids == identifier
                        influence.append({"metric": metric, "MMSI": int(identifier), "windows": int(mask.sum()),
                                          "full_difference_m": float(delta.mean()),
                                          "leave_one_MMSI_out_difference_m": float(delta[~mask].mean()),
                                          "removed_MMSI_mean_difference_m": float(delta[mask].mean())})
            write_csv(OUT / "paired_uncertainty.csv", rows)
            log("uncertainty_cell_complete", domain=domain, metric=metric, selected_by_validation=selected)
    primary = [r for r in rows if r["metric"] in ("ADE@5", "ADE@10", "ADE@60") and r["comparator"] == r["validation_selected_comparator"]]
    ordered = sorted(primary, key=lambda r: r["wild_cluster_t_p"])
    adjusted = 0.
    for rank, row in enumerate(ordered):
        adjusted = max(adjusted, min(1., (len(ordered) - rank) * row["wild_cluster_t_p"]))
        row["primary_Holm_p"] = adjusted
    for row in rows:
        row.setdefault("primary_Holm_p", None)
    write_csv(OUT / "paired_uncertainty.csv", rows)
    write_csv(OUT / "piraeus_leave_one_MMSI_out.csv", influence)
    for seed in SEEDS:
        z = np.load(canonical("piraeus", seed, "val"))
        p, y, ids = z["experts"], z["target"], z["mmsi"]
        ridge = pick_ridge(p, y, ids, seed)
        full = route_fit(p, y, ridge=ridge)
        rng = np.random.default_rng(seed)
        groups = np.unique(ids)
        for fraction in (.25, .5, .75):
            for repeat in range(50):
                check_time(deadline, 2)
                selected = rng.choice(groups, max(3, round(len(groups) * fraction)), replace=False)
                included = np.isin(ids, selected)
                fit = route_fit(p[included], y[included], ridge=ridge)
                resampling.append({"domain": "piraeus", "seed": seed, "fraction": fraction, "repeat": repeat,
                                   "ridge_selected_on_full_validation": ridge,
                                   "mean_anchor_weight_absolute_change": float(np.abs(fit["weights"] - full["weights"]).mean()),
                                   "held_out_validation_J": jscore(route_blend(p[~included], fit), y[~included])})
        write_csv(OUT / "piraeus_validation_size_sensitivity.csv", resampling)
    atomic_json(OUT / "statistics_COMPLETE.json", {"complete": True, "bootstrap_draws": 10000,
                "inference": "paired MMSI wild-cluster bootstrap-t; approximate small-cluster inference",
                "crossed_seed_intervals": "descriptive, conditional on three fits and shared routing selection"})


def sensitivity(deadline):
    anchors = ((60,), (10, 60), (5, 10, 60), (5, 20, 60), (5, 30, 60),
               (10, 30, 60), (5, 10, 30, 60), (5, 10, 20, 30, 45, 60))
    rows, objective_rows, norway = [], [], []
    for domain in DOMAINS:
        for seed in SEEDS:
            check_time(deadline, 10)
            val = np.load(canonical(domain, seed, "val"))
            test = np.load(canonical(domain, seed, "test"))
            p, y, ids = val["experts"], val["target"], val["mmsi"]
            for anchor in anchors:
                steps = [3 * a for a in anchor]
                ridge = pick_ridge(p, y, ids, seed, steps=steps)
                route = route_fit(p, y, ridge=ridge, steps=steps)
                scores = []
                for held in group_folds(ids, seed):
                    scores.append(jscore(route_blend(p[held], route_fit(p[~held], y[~held], ridge=ridge, steps=steps)), y[held]))
                # This grid is descriptive sensitivity, not an unbiased nested estimate.
                pp = route_blend(test["experts"], route)
                rows.append({"domain": domain, "seed": seed, "anchors_min": "+".join(map(str, anchor)), "ridge": ridge,
                             "validation_CV_J_descriptive": float(np.mean(scores)), "test_J": jscore(pp, test["target"]),
                             **displacement_metrics(pp, test["target"])})
            val_methods = method_predictions(val, arrays(domain, "val")[0])
            tested = method_predictions(test, arrays(domain, "test")[0])
            variants = {"full_refit_three_anchor": route_blend(test["experts"], route_fit(p, y, ridge=pick_ridge(p, y, ids, seed)))}
            for index, name in enumerate(EXPERTS):
                keep = [i for i in range(5) if i != index]
                fit = route_fit(p[:, keep], y, ridge=pick_ridge(p[:, keep], y, ids, seed))
                variants["without_" + name] = route_blend(test["experts"][:, keep], fit)
            scales = {"original": (20., 50., 600.),
                      "CV15_validation": tuple(max(sample_error(val_methods["cv15"], y, f"ADE@{h}").mean(), 1e-6) for h in (5, 10, 60)),
                      "best_expert_validation": tuple(max(min(sample_error(val_methods[n], y, f"ADE@{h}").mean() for n in EXPERTS), 1e-6) for h in (5, 10, 60)),
                      "median_expert_validation": tuple(max(np.median([sample_error(val_methods[n], y, f"ADE@{h}").mean() for n in EXPERTS]), 1e-6) for h in (5, 10, 60))}
            for variant, pp in variants.items():
                for scale_name, scale in scales.items():
                    for weights in ((1., 1., 2.), (1., 1., 1.), (1., 1., 4.)):
                        objective_rows.append({"domain": domain, "seed": seed, "variant": variant, "scale": scale_name,
                            "horizon_weights": "+".join(map(str, weights)), "J": jscore(pp, test["target"], scale, weights),
                            "test_windows": len(test["mmsi"]), "test_MMSI": len(np.unique(test["mmsi"])),
                            "scope": "frozen experts, validation refitted leave-one-expert-out routing; alternate J is rescore only"})
            if domain == "norway":
                for name in ("final", "sa_repair", "cv15", "mstformer_faithful"):
                    for horizon in (45, 60):
                        for kind in ("ADE", "FDE"):
                            metric = f"{kind}@{horizon}"
                            errors = sample_error(tested[name], test["target"], metric)
                            norway.append({"seed": seed, "method": name, "metric": metric, "mean_m": float(errors.mean()),
                                           "p90_m": float(np.quantile(errors, .9)), "p95_m": float(np.quantile(errors, .95)),
                                           "sa_final_anchor_weight": float(test["knot_weights"][2, 0]),
                                           "cv15_relation": "physical expert is internal to SA; not a separately routed external branch"})
            write_csv(OUT / "anchor_sensitivity.csv", rows)
            write_csv(OUT / "objective_sensitivity_per_seed.csv", objective_rows)
            write_csv(OUT / "norway_long_horizon_analysis.csv", norway)
            log("sensitivity_run_complete", domain=domain, seed=seed)
    macros = []
    for scale in {r["scale"] for r in objective_rows}:
        for weights in {r["horizon_weights"] for r in objective_rows}:
            for variant in variants:
                subset = [r for r in objective_rows if r["scale"] == scale and r["horizon_weights"] == weights and r["variant"] == variant]
                for region_rule in ("equal", "test_windows", "test_MMSI", "without_piraeus"):
                    values, ww = [], []
                    for r in subset:
                        if region_rule == "without_piraeus" and r["domain"] == "piraeus":
                            continue
                        values.append(r["J"])
                        ww.append(r[region_rule] if region_rule in ("test_windows", "test_MMSI") else 1.)
                    macros.append({"scale": scale, "horizon_weights": weights, "variant": variant,
                                   "region_weighting": region_rule, "macro_J": float(np.average(values, weights=ww))})
    for row in macros:
        reference = next(r["macro_J"] for r in macros if r["scale"] == row["scale"] and r["horizon_weights"] == row["horizon_weights"] and r["region_weighting"] == row["region_weighting"] and r["variant"] == "full_refit_three_anchor")
        row["relative_change_percent"] = 100 * (row["macro_J"] - reference) / reference
    write_csv(OUT / "objective_macro_sensitivity.csv", macros)
    atomic_json(OUT / "sensitivity_COMPLETE.json", {"complete": True, "anchor_sets": len(anchors),
                "limitations": "No SA internal components retrained; Norway analysis is diagnostic, not a causal intervention; alternate J router re-selection deferred"})


def marine_metrics(p, y, history):
    p, y, history = p.astype(np.float64), y.astype(np.float64), history.astype(np.float64)
    truth_path = np.concatenate((history[:, -1:, :2], y), axis=1)
    truth_delta = np.diff(truth_path, axis=1)
    speed = np.linalg.norm(truth_delta, axis=-1)
    valid = speed >= 1. # 1 metre / 20 seconds = 0.05 m/s direction threshold.
    tangent = truth_delta / np.maximum(speed[..., None], 1e-12)
    error = p - y
    along = np.abs((error * tangent).sum(-1))
    cross = np.abs(error[..., 0] * tangent[..., 1] - error[..., 1] * tangent[..., 0])
    pred_delta = np.diff(np.concatenate((history[:, -1:, :2], p), axis=1), axis=1)
    pred_speed = np.linalg.norm(pred_delta, axis=-1)
    heading_valid = valid & (pred_speed >= 1.)
    dot = (truth_delta * pred_delta).sum(-1) / np.maximum(speed * pred_speed, 1e-12)
    dot[np.abs(dot - 1.) < 1e-12] = 1.
    heading = np.degrees(np.arccos(np.clip(dot, -1, 1)))
    rows = []
    for h in (30, 45, 60):
        s = h * 3
        mask = valid[:, :s]
        hm = heading_valid[:, :s]
        row = {"horizon_min": h, "direction_valid_fraction": float(mask.mean()), "heading_valid_fraction": float(hm.mean()),
               "speed_MAE_mps": float(np.abs(pred_speed[:, :s] - speed[:, :s]).mean() / 20),
               "heading_MAE_deg": float(heading[:, :s][hm].mean()) if hm.any() else None}
        for name, values in (("along", along[:, :s][mask]), ("cross", cross[:, :s][mask])):
            row[name + "_mean_m"] = float(values.mean()) if len(values) else None
            row[name + "_p95_m"] = float(np.quantile(values, .95)) if len(values) else None
        rows.append(row)
    return rows


@torch.inference_mode()
def engineering(deadline):
    rows, latency, missing = [], [], []
    for domain in DOMAINS:
        history = np.asarray(arrays(domain, "test")[0])
        for seed in SEEDS:
            z = np.load(canonical(domain, seed, "test"))
            for name, p in method_predictions(z, history).items():
                rows.extend({"domain": domain, "seed": seed, "method": name, **r} for r in marine_metrics(p, z["target"], history))
    write_csv(OUT / "maritime_error_metrics.csv", rows)
    # Cost benchmark on two regions. Cached-window normalization is timed separately,
    # not misrepresented as raw AIS ingestion or actual network communication.
    for domain in ("dma", "piraeus"):
        check_time(deadline, 120)
        started = time.perf_counter()
        model = load_final(domain, 42)
        if DEVICE.type == "cuda":
            torch.cuda.synchronize()
        load_seconds = time.perf_counter() - started
        scaler = RobustTrajectoryScaler(**source_config(domain, 42)["scaler"])
        history = np.asarray(arrays(domain, "test")[0][:32])
        normal_start = time.perf_counter()
        normalized = scaler.transform_history(history)
        normalization_ms = (time.perf_counter() - normal_start) * 1000
        for name, module in (("final", model), *zip(EXPERTS, model.expert_modules)):
            for batch in (1, 32):
                x = torch.from_numpy(normalized[:batch].copy()).to(DEVICE)
                for _ in range(50):
                    module(x)
                if DEVICE.type == "cuda":
                    torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats()
                times = []
                for repeat in range(3):
                    check_time(deadline, 5)
                    for _ in range(200):
                        if DEVICE.type == "cuda":
                            torch.cuda.synchronize()
                        t = time.perf_counter()
                        module(x)
                        if DEVICE.type == "cuda":
                            torch.cuda.synchronize()
                        times.append((time.perf_counter() - t) * 1000)
                latency.append({"domain": domain, "seed": 42, "method": name, "batch": batch,
                                "parameters": sum(p.numel() for p in module.parameters()),
                                "median_ms": float(np.median(times)), "p95_ms": float(np.quantile(times, .95)),
                                "throughput_samples_per_second": batch * 1000 / float(np.mean(times)),
                                "peak_process_GPU_allocated_MB": torch.cuda.max_memory_allocated() / 2**20 if DEVICE.type == "cuda" else None,
                                "scope": "FP32 model-only latency; all experts resident; not standalone VRAM",
                                "whole_model_cold_load_seconds": load_seconds,
                                "cached_32_window_normalization_ms": normalization_ms})
                write_csv(OUT / "compute_latency.csv", latency)
        del model
        torch.cuda.empty_cache()
    # Synthetic missing-observation stress: same masks across models and seeds.
    for domain in DOMAINS:
        history, target, ids = arrays(domain, "test")
        history = np.asarray(history)
        conditions = [("random", f) for f in (.1, .2, .3)] + [("gap_minutes", m) for m in (1, 3, 5)]
        for seed in SEEDS:
            check_time(deadline, 30)
            model = load_final(domain, seed)
            scaler = RobustTrajectoryScaler(**source_config(domain, seed)["scaler"])
            for kind, value in conditions:
                check_time(deadline, 5)
                rng = np.random.default_rng(7300 + DOMAINS.index(domain) * 10 + conditions.index((kind, value)))
                mask = rng.random((len(history), 90)) < value if kind == "random" else np.zeros((len(history), 90), dtype=bool)
                if kind == "gap_minutes":
                    width = int(value * 3)
                    starts = rng.integers(0, 91 - width, size=len(history))
                    for i, a in enumerate(starts):
                        mask[i, a:a + width] = True
                corrupted = history.copy()
                for i in range(len(history)):
                    observed = np.flatnonzero(~mask[i])
                    if not len(observed):
                        raise RuntimeError("All history missing; undefined imputation")
                    previous = int(observed[0])
                    for t in range(90):
                        if mask[i, t]:
                            corrupted[i, t] = history[i, previous]
                        else:
                            previous = t
                pp, ee = forward_final(model, corrupted, scaler)
                for name, prediction in (("final", pp), *[(name, ee[:, i]) for i, name in enumerate(EXPERTS)]):
                    missing.append({"domain": domain, "seed": seed, "method": name, "missing_type": kind,
                                    "missing_value": value, "scope": "synthetic row removal with history-only forward-fill; leading rows use first observed row",
                                    **displacement_metrics(prediction, target)})
                write_csv(OUT / "synthetic_missing_observations.csv", missing)
                log("missing_observation_run", domain=domain, seed=seed, condition=kind, value=value)
            del model
            torch.cuda.empty_cache()
    atomic_json(OUT / "engineering_COMPLETE.json", {"complete": True,
                "limitations": "No raw AIS/network throughput or chart/collision metric; missing stress covers final plus its five experts, not LSTM/TCN; no new capacity-matched retraining"})


def report():
    lines = ["# Five-hour revision evidence", "", "Original checkpoints were not overwritten. No new backbone seeds were trained.",
             "This batch does not complete the full revision checklist.", "", "## Phase status", ""]
    import json
    for phase in ("audit", "routing", "transfer", "statistics", "sensitivity", "engineering"):
        path = OUT / f"{phase}_COMPLETE.json"
        lines.append(f"- {phase}: " + ("complete" if path.exists() else "incomplete / see events and stderr"))
        if path.exists():
            content = json.loads(path.read_text(encoding="utf-8"))
            for field in ("limitations", "inference", "crossed_seed_intervals"):
                if field in content:
                    lines.append(f"  - {content[field]}")
    screening = OUT / "routing_validation_screen.csv"
    if screening.exists():
        lines += ["", "New head retention is based on grouped validation only; see routing_validation_screen.csv."]
    lines += ["", "## Still required", "", "Additional independent backbone seeds, retrained SA internal ablations, an independent AIS source, and a verified probabilistic comparator remain outside this five-hour batch.",
              "Historical test data have been observed; this batch is not an untouched external holdout."]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    from run_revision_5h import digest
    atomic_json(OUT / "code_manifest.json", {str(path.relative_to(ROOT)): digest(path) for path in
                (ROOT / "run_revision_5h.py", ROOT / "revision_5h_analysis.py", ROOT / "tests" / "test_revision_5h.py")})
