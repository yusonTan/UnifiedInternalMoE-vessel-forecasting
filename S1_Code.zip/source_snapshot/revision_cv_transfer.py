"""Nested CV15 controls and source-only ten-seed transfer; frozen test rules."""
from __future__ import annotations
import argparse
import gc
import time
import numpy as np
import torch
import revision_extension_common as c
from amf.data import RobustTrajectoryScaler
from amf.unified_predictor import UnifiedInternalMoE
from evaluate_compact_committee import build_model

def protection(domain,seed,smoke=False):
    folder=c.OUT/('smoke/protection' if smoke else 'protection')/domain/f'seed_{seed}'
    if c.complete(folder,deep=True):return
    folder.mkdir(parents=True,exist_ok=True);began=time.monotonic()
    p,y,ids,index=c.load_candidates(domain,seed,'val');history=c.data(domain,'val')[0]
    if smoke:
        ii=np.concatenate([np.flatnonzero(ids==g)[:3] for g in np.unique(ids)[:18]])
        p,y,ids,index,history=p[ii],y[ii],ids[ii],index[ii],history[ii]
    six=np.concatenate((p,c.cv15(history)[:,None]),axis=1)
    by_beta,selected,ranking=c.choose_candidates(six,y,ids,seed)
    five_choices,five_selected,_=c.choose_candidates(p,y,ids,seed)
    fit6=c.FloorFitter(six,y);fit5=c.FloorFitter(p,y)
    routes={f'CV15_floor_{b:g}':fit6.fit(r['ridge'],b) for b,r in by_beta.items()}
    routes['five_expert_refit']=fit5.fit(five_selected['ridge'],0.)
    routes['validation_selected_beta']=routes[f"CV15_floor_{selected['beta']:g}"]
    # True nested validation: each outer held-out MMSI group is absent from all
    # beta/ridge selection and weight fitting inside that outer repetition.
    outer=[];oof={name:np.empty_like(y) for name in routes}
    for fold,h in enumerate(c.group_folds(ids,seed)):
        ix=np.flatnonzero(~h)
        bb,choice,_=c.choose_candidates(six,y,ids,seed+100+fold,ix)
        _,fchoice,_=c.choose_candidates(p,y,ids,seed+100+fold,ix)
        f6=c.FloorFitter(six,y,ix);f5=c.FloorFitter(p,y,ix)
        rr={f'CV15_floor_{b:g}':f6.fit(r['ridge'],b) for b,r in bb.items()}
        rr['five_expert_refit']=f5.fit(fchoice['ridge'],0.)
        rr['validation_selected_beta']=rr[f"CV15_floor_{choice['beta']:g}"]
        for name,r in rr.items():oof[name][h]=c.blend((p if name=='five_expert_refit' else six)[h],r)
        outer.append({'fold':fold,'held_MMSI':np.unique(ids[h]).tolist(),'selected_beta':choice['beta'],
            'selected_ridge':choice['ridge'],'train_windows':int((~h).sum()),'held_windows':int(h.sum())})
    validation={name:c.J(c.errors(v,y)) for name,v in oof.items()}
    validation['CV15']=c.J(c.errors(six[:,-1],y))
    lock={'domain':domain,'seed':seed,'routes':routes,'chosen_beta':selected,'ranking':ranking,
        'five_selected':five_selected,'outer':outer,'outer_validation_J':validation,'test_used_for_selection':False,
        'floor_applies_to':'all three anchor vectors and therefore every interpolated horizon',
        'fixed_expert_sets':['all five original experts','all five plus raw CV15'],
        'fit_surrogate':'prefix mean squared position error with ridge toward SA, not direct ADE optimization',
        'short_specialist_override':False,'not_a_replacement_for_original_model':True}
    # Freeze all selection before loading the test predictions.
    c.atomic_json(folder/'VALIDATION_SELECTION_LOCK.json',lock)
    del six,oof,p,y,history;gc.collect()
    pt,yt,it,jt=c.load_candidates(domain,seed,'test');ht=c.data(domain,'test')[0]
    if smoke:pt,yt,it,jt,ht=pt[:16],yt[:16],it[:16],jt[:16],ht[:16]
    cv=c.cv15(ht);six=np.concatenate((pt,cv[:,None]),axis=1)
    predictions={name:c.blend(pt if name=='five_expert_refit' else six,r) for name,r in routes.items()}
    predictions['CV15']=cv
    formal=c.MAIN/'fusion_10seed_refit'/domain/f'seed_{seed}'
    with np.load(formal/'test_predictions.npz') as z:
        n=len(it)
        if not np.array_equal(z['mmsi'][:n],it) or not np.array_equal(z['window_index'][:n],jt) or np.max(np.abs(z['target'][:n]-yt))>.05:
            raise RuntimeError('Formal comparator alignment failure')
        predictions['original_fusion']=z['prediction'][:n].copy()
    with np.load(formal/'val_predictions.npz') as z:validation['original_fusion']=c.J(c.errors(z['prediction'],z['target']))
    rows=[];arrays={'mmsi':it,'window_index':jt};sample=np.arange(min(8,len(it)))
    for name,pp in predictions.items():
        ee=c.errors(pp,yt)
        rows.append({'domain':domain,'seed':seed,'model':name,'protocol':'nested_validation_CV15_protection',
            'validation_J':validation[name],'test_J':c.J(ee),'selected_beta':selected['beta'] if name=='validation_selected_beta' else None,
            **{k:float(v.mean()) for k,v in ee.items()}})
        arrays.update({name+'__'+k:v.astype(np.float32) for k,v in ee.items()})
        arrays[name+'__sample_prediction']=pp[sample]
    arrays.update(sample_window_index=jt[sample],sample_target=yt[sample])
    c.archive(folder/'test_errors.npz',**arrays)
    c.atomic_json(folder/'RESULT.json',{'rows':rows,'seconds':time.monotonic()-began,'prediction_storage':'all-window errors plus first-eight-window trajectories; full predictions reproducible from frozen caches and routes'})
    c.accept(folder,('VALIDATION_SELECTION_LOCK.json','RESULT.json','test_errors.npz'))
    c.emit('protection_unit_complete',domain=domain,seed=seed,seconds=time.monotonic()-began,smoke=smoke)

def scaler_for(model,source,seed):
    if model=='UnifiedInternalMoE':folder=c.MAIN/'fusion_10seed_refit'/source/f'seed_{seed}'
    else:folder=c.run_of(model,source,seed)
    config=c.read(folder/'config.json')
    scaler=RobustTrajectoryScaler(**config['scaler']) if 'scaler' in config else RobustTrajectoryScaler.load(c.ROOT/'cache'/source/'scaler.json')
    return folder,scaler

@torch.inference_mode()
def transfer(source,seed,smoke=False):
    folder=c.OUT/('smoke/transfer' if smoke else 'transfer')/source/f'seed_{seed}'
    if c.complete(folder,deep=True):return
    folder.mkdir(parents=True,exist_ok=True);began=time.monotonic();rows=[];files=[]
    for name in c.MODELS:
        marker=folder/(name+'.json')
        if marker.exists():
            old=c.read(marker)
            if all((folder/n).exists() and c.sha(folder/n)==s for n,s in old['files'].items()):rows.extend(old['rows']);files.extend(old['files']);files.append(marker.name);continue
            raise RuntimeError('Partial transfer marker or files changed')
        run,scaler=scaler_for(name,source,seed);checkpoint=run/'best.pt'
        model=UnifiedInternalMoE() if name=='UnifiedInternalMoE' else build_model(name,run)
        model.load_state_dict(torch.load(checkpoint,map_location='cpu',weights_only=False)['model'],strict=True)
        model.cuda().eval();subrows=[];subfiles=[]
        # Replay the source checkpoint against its audited in-domain output
        # before measuring any transfer. This never changes the model or route.
        source_h=c.data(source,'test')[0][:16]
        xx=torch.from_numpy(scaler.transform_history(np.asarray(source_h)).copy()).cuda()
        replay=scaler.inverse_positions(model(xx).cpu().numpy())
        if name=='UnifiedInternalMoE':
            with np.load(run/'test_predictions.npz') as z:expected=z['prediction'][:16].copy()
        else:
            cache=c.read(c.OUT/'PROTOCOL.json')['prediction_caches'][f'{name}/{source}/{seed}']
            with np.load(cache) as z:expected=z['test_prediction'][:16].copy()
        replay_difference=float(np.max(np.abs(replay-expected)))
        if replay_difference>.05:raise RuntimeError(f'Source replay mismatch {source}/{seed}/{name}: {replay_difference}')
        for target in c.DOMAINS:
            if target==source:continue
            hx,truth,ids=c.data(target,'test');n=min(32,len(ids)) if smoke else len(ids)
            ee={k:np.empty(n,np.float32) for k in c.METRICS};samples=[]
            for start in range(0,n,32):
                end=min(start+32,n)
                x=torch.from_numpy(scaler.transform_history(np.asarray(hx[start:end])).copy()).cuda()
                pp=scaler.inverse_positions(model(x).cpu().numpy()).astype(np.float32)
                if pp.shape!=(end-start,180,2) or not np.isfinite(pp).all():raise RuntimeError('Invalid source-only prediction')
                e=c.errors(pp,np.asarray(truth[start:end]))
                for k in ee:ee[k][start:end]=e[k]
                if start==0:samples=pp[:8].copy()
            path=folder/(name+'__'+target+'.npz')
            c.archive(path,mmsi=np.asarray(ids[:n]),window_index=np.arange(n),sample_window_index=np.arange(min(8,n)),
                sample_prediction=samples,sample_target=np.asarray(truth[:min(8,n)]),**ee)
            subfiles.append(path.name)
            subrows.append({'source':source,'target':target,'domain':target,'seed':seed,'model':name,
                'protocol':'source_only_zero_target_fitting','windows':n,'MMSI':len(np.unique(ids[:n])),
                'source_checkpoint_sha256':c.sha(checkpoint),'target_scaler_fitted':False,'target_route_fitted':False,
                'test_J':c.J(ee),**{k:float(v.mean()) for k,v in ee.items()}})
        c.atomic_json(marker,{'rows':subrows,'files':{n:c.sha(folder/n) for n in subfiles},
            'source_scaler':scaler.__dict__,'source_checkpoint':str(checkpoint),'source_replay_max_abs_m':replay_difference,
            'target_data_used_for_training_or_selection':False})
        rows.extend(subrows);files.extend(subfiles);files.append(marker.name)
        del model;torch.cuda.empty_cache();gc.collect()
        c.emit('transfer_model_complete',source=source,seed=seed,model=name,smoke=smoke)
    c.atomic_json(folder/'RESULT.json',{'rows':rows,'seconds':time.monotonic()-began,'directions':3,
        'prediction_storage':'all-window error vectors and first eight sample trajectories; full inference replay supported'})
    c.accept(folder,('RESULT.json',*files))
    c.emit('transfer_unit_complete',source=source,seed=seed,seconds=time.monotonic()-began,smoke=smoke)

def summary():
    from revision_5h_analysis import paired_uncertainty
    protection_rows=[];transfer_rows=[];choices=[]
    for d in c.DOMAINS:
        for s in c.SEEDS:
            a=c.OUT/'protection'/d/f'seed_{s}';b=c.OUT/'transfer'/d/f'seed_{s}'
            if not c.complete(a,True) or not c.complete(b,True):raise RuntimeError('Incomplete experiment cohort')
            protection_rows.extend(c.read(a/'RESULT.json')['rows']);transfer_rows.extend(c.read(b/'RESULT.json')['rows'])
            r=c.read(a/'VALIDATION_SELECTION_LOCK.json')
            choices.append({'domain':d,'seed':s,'selected_beta':r['chosen_beta']['beta'],'ridge':r['chosen_beta']['ridge'],
                'outer_validation_J':r['outer_validation_J']['validation_selected_beta'],'test_used_for_selection':False})
    if len(protection_rows)!=320 or len(transfer_rows)!=960:raise RuntimeError('Unexpected row count')
    c.table('CV15_protection_per_seed.csv',protection_rows)
    means=c.summarize(protection_rows,('domain','model'));c.table('CV15_protection_mean_std.csv',means)
    c.table('CV15_validation_selections.csv',choices)
    c.table('transfer_10seed_per_seed.csv',transfer_rows)
    c.table('transfer_10seed_mean_std.csv',c.summarize(transfer_rows,('source','target','model')))
    import csv
    with (c.MAIN/'four_domain_10seed_per_seed.csv').open(encoding='utf-8-sig',newline='') as f:
        original=list(csv.DictReader(f))
    reference={(r['domain'],int(r['seed']),'UnifiedInternalMoE' if r['model']=='UnifiedInternalMoE_10seed_refit' else r['model']):r for r in original}
    context=[]
    for r in transfer_rows:
        own=reference[(r['source'],r['seed'],r['model'])];target_fit=reference[(r['target'],r['seed'],r['model'])]
        context.append({'source':r['source'],'target':r['target'],'seed':r['seed'],'model':r['model'],
            'transfer_ADE60_m':r['ADE@60'],'source_in_domain_ADE60_m':float(own['ADE@60']),
            'target_independently_trained_ADE60_m':float(target_fit['ADE@60']),
            'change_from_source_in_domain_percent':100*(r['ADE@60']/float(own['ADE@60'])-1),
            'gap_to_target_trained_percent':100*(r['ADE@60']/float(target_fit['ADE@60'])-1),
            'target_reference_is_context_not_transfer_calibration':True})
    c.table('transfer_in_domain_context.csv',context)
    cvrows=[]
    for target in c.DOMAINS:
        hx,truth,ids=c.data(target,'test');ee=c.errors(c.cv15(hx),truth)
        cvrows.append({'target':target,'model':'CV15','deterministic_not_ten_independent_runs':True,
            'test_J':c.J(ee),**{k:float(v.mean()) for k,v in ee.items()}})
    c.table('transfer_CV15_deterministic_reference.csv',cvrows)
    macro=[]
    for model in sorted({r['model'] for r in protection_rows}):
        js=[np.mean([r['test_J'] for r in protection_rows if r['model']==model and r['seed']==s]) for s in c.SEEDS]
        macro.append({'model':model,'four_region_equal_macro_J':float(np.mean(js)),
            'macro_J_seed_std':0. if model=='CV15' else float(np.std(js,ddof=1)),
            'deterministic':model=='CV15','n_training_seeds':0 if model=='CV15' else 10})
    c.table('CV15_protection_macro.csv',macro)
    paired=[]
    # Two predeclared comparisons; report separate 12-cell ADE/FDE families.
    for reference in ('original_fusion','five_expert_refit'):
        for domain in c.DOMAINS:
            diffs={m:[] for m in c.METRICS};ids=None
            for s in c.SEEDS:
                with np.load(c.OUT/'protection'/domain/f'seed_{s}'/'test_errors.npz') as z:
                    if ids is None:ids=z['mmsi'].copy()
                    elif not np.array_equal(ids,z['mmsi']):raise RuntimeError('Paired vessel ordering mismatch')
                    for m in c.METRICS:diffs[m].append(z['validation_selected_beta__'+m].astype(np.float64)-z[reference+'__'+m])
            for m in c.METRICS:
                evidence=paired_uncertainty(np.stack(diffs[m]),ids,np.random.default_rng(162600+len(paired)),draws=10000)
                paired.append({'reference':reference,'comparator':'validation_selected_beta','domain':domain,'metric':m,
                    'positive_difference_favors_reference':True,'shared_route_selection_reference':reference=='original_fusion',**evidence})
    for ref in ('original_fusion','five_expert_refit'):
        for tag,metrics in (('primary_ADE_12cell_Holm_p',('ADE@5','ADE@10','ADE@60')),
                            ('anchor_FDE_12cell_Holm_p',('FDE@5','FDE@10','FDE@60')),
                            ('secondary_24cell_Holm_p',tuple(m for m in c.METRICS if m.split('@')[1] not in ('5','10','60')))):
            rr=sorted([r for r in paired if r['reference']==ref and r['metric'] in metrics],key=lambda r:r['wild_cluster_t_p']);running=0.
            for i,r in enumerate(rr):running=max(running,min(1.,(len(rr)-i)*r['wild_cluster_t_p']));r[tag]=running
    c.table('CV15_protection_paired_uncertainty.csv',paired)
    # Per-source/target matrices; never choose a source using target test scores.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,4,figsize=(17,8),layout='constrained')
    tm=c.summarize(transfer_rows,('source','target','model'))
    for ax,model in zip(axes.flat,c.MODELS):
        matrix=np.full((4,4),np.nan)
        for r in tm:
            if r['model']==model:matrix[c.DOMAINS.index(r['source']),c.DOMAINS.index(r['target'])]=r['ADE@60_mean']
        im=ax.imshow(matrix,cmap='viridis_r');ax.set_title(model);ax.set_xticks(range(4),c.DOMAINS,rotation=35);ax.set_yticks(range(4),c.DOMAINS)
        ax.set_xlabel('Target');ax.set_ylabel('Source');fig.colorbar(im,ax=ax,label='ADE@60 (m), lower is better')
    fig.savefig(c.OUT/'transfer_ADE60_matrices.png',dpi=180);fig.savefig(c.OUT/'transfer_ADE60_matrices.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,4,figsize=(16,4),layout='constrained')
    for ax,domain in zip(axes,c.DOMAINS):
        rr=[r for r in means if r['domain']==domain];ax.bar(range(len(rr)),[r['ADE@60_mean'] for r in rr],yerr=[r['ADE@60_std'] for r in rr],capsize=2)
        ax.set_xticks(range(len(rr)),[r['model'] for r in rr],rotation=75,ha='right');ax.set_title(domain);ax.set_ylabel('ADE@60 (m), mean +/- sample SD')
    fig.savefig(c.OUT/'CV15_protection_ADE60.png',dpi=180);fig.savefig(c.OUT/'CV15_protection_ADE60.pdf');plt.close(fig)
    c.atomic_json(c.OUT/'STATISTICS_COMPLETE.json',{'complete':True,'protection_rows':320,'transfer_rows':960,
        'paired_cells':96,'bootstrap_draws':10000,'transfer_directions':12,'transfer_models':8,'seeds':10,
        'external_validation_completed':False,'small_cluster_tests_are_approximate':True})
    c.emit('statistics_complete',protection_rows=320,transfer_rows=960)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=('protection','transfer','summary'))
    parser.add_argument('--domain',choices=c.DOMAINS);parser.add_argument('--seed',type=int,choices=c.SEEDS)
    parser.add_argument('--smoke',action='store_true');a=parser.parse_args()
    torch.set_num_threads(4);c.check_frozen()
    if a.phase!='summary' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; no silent CPU fallback')
    if a.phase=='protection':protection(a.domain,a.seed,a.smoke)
    elif a.phase=='transfer':transfer(a.domain,a.seed,a.smoke)
    else:summary()

if __name__=='__main__':main()
