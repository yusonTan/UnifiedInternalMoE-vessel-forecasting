from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


HISTORY_STEPS = 90
FUTURE_STEPS = 180


def cv_prediction(history: torch.Tensor, window: int = 3) -> torch.Tensor:
    positions = history[..., :2]
    velocity = (positions[:, -1] - positions[:, -1 - window]) / float(window)
    steps = torch.arange(1, FUTURE_STEPS + 1, device=history.device, dtype=history.dtype)
    return positions[:, -1, None] + steps[None, :, None] * velocity[:, None]


def _motion_channels(history: torch.Tensor) -> torch.Tensor:
    """Paper-compatible motion variables in the common local-coordinate frame."""
    xy = history[..., :2]
    delta = torch.diff(xy, dim=1, prepend=xy[:, :1])
    speed = torch.linalg.vector_norm(delta, dim=-1, keepdim=True)
    acceleration = torch.diff(speed, dim=1, prepend=speed[:, :1])
    heading = torch.atan2(delta[..., 1:2], delta[..., 0:1])
    turn = torch.atan2(
        torch.sin(torch.diff(heading, dim=1, prepend=heading[:, :1])),
        torch.cos(torch.diff(heading, dim=1, prepend=heading[:, :1])),
    )
    return torch.cat(
        (
            history,
            delta,
            speed,
            acceleration,
            torch.sin(heading),
            torch.cos(heading),
            torch.sin(turn),
            torch.cos(turn),
        ),
        dim=-1,
    )


class DynamicAwareEncoderLayer(nn.Module):
    """First MSTFormer layer: update the c*ln(L) motion-important queries."""

    def __init__(self, d_model: int = 512, heads: int = 8, d_ff: int = 2048, factor: int = 3, dropout: float = 0.05):
        super().__init__()
        self.factor = factor
        self.attention = nn.MultiheadAttention(d_model, heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.ffn = nn.Sequential(nn.Linear(d_model, d_ff), nn.GELU(), nn.Dropout(dropout), nn.Linear(d_ff, d_model))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, importance: torch.Tensor) -> torch.Tensor:
        attended, _ = self.attention(x, x, x, need_weights=False)
        top_k = min(x.shape[1], max(1, int(self.factor * math.ceil(math.log(x.shape[1])))))
        selected = importance.topk(top_k, dim=1).indices
        mask = torch.zeros_like(importance).scatter_(1, selected, 1.0).unsqueeze(-1)
        x = self.norm1(x + self.dropout(attended) * mask)
        return self.norm2(x + self.dropout(self.ffn(x)))


class AugmentedTrajectoryEncoder(nn.Module):
    """Differentiable compact ATM encoder following Algorithm 1 and the 1/4 sampling rule."""

    def __init__(self, d_model: int = 512, grid_size: int = 17):
        super().__init__()
        self.grid_size = grid_size
        self.cnn = nn.Sequential(
            nn.Conv3d(1, 8, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool3d((1, 2, 2)),
            nn.Conv3d(8, 16, kernel_size=3, padding=1), nn.ReLU(), nn.MaxPool3d((1, 2, 2)),
        )
        self.projection = nn.Linear(16 * (grid_size // 4) * (grid_size // 4), d_model)

    def _maps(self, history: torch.Tensor) -> torch.Tensor:
        xy = history[..., :2]
        delta = torch.diff(xy, dim=1)
        scale = torch.quantile(delta.abs().flatten(1), 0.90, dim=1).clamp_min(1e-4)
        normalized = (delta / scale[:, None, None]).clamp(-3.5, 3.5)
        indices = torch.arange(0, normalized.shape[1], 4, device=history.device)
        normalized = normalized.index_select(1, indices)
        batch, length, _ = normalized.shape
        grid = self.grid_size
        axis = torch.linspace(-4.0, 4.0, grid, device=history.device, dtype=history.dtype)
        yy, xx = torch.meshgrid(axis, axis, indexing="ij")
        center_x = normalized[..., 0, None, None]
        center_y = normalized[..., 1, None, None]
        gaussian = torch.exp(-0.5 * ((xx - center_x) ** 2 + (yy - center_y) ** 2) / 0.7**2)
        center = torch.exp(-0.5 * (xx**2 + yy**2) / 0.35**2)[None, None]
        direction = normalized / torch.linalg.vector_norm(normalized, dim=-1, keepdim=True).clamp_min(1e-5)
        heading_x = direction[..., 0, None, None]
        heading_y = direction[..., 1, None, None]
        heading = torch.exp(-0.5 * ((xx - heading_x) ** 2 + (yy - heading_y) ** 2) / 0.45**2)
        speed = torch.linalg.vector_norm(normalized, dim=-1, keepdim=True)[..., None]
        return (0.8 * center + gaussian + 0.2 * heading + 0.02 * speed * heading).view(batch, length, grid, grid)

    def forward(self, history: torch.Tensor) -> torch.Tensor:
        maps = self._maps(history).unsqueeze(1)
        features = self.cnn(maps).permute(0, 2, 1, 3, 4).flatten(2)
        features = self.projection(features)
        return F.interpolate(features.transpose(1, 2), size=HISTORY_STEPS, mode="linear", align_corners=False).transpose(1, 2)


class MSTFormerFaithful(nn.Module):
    """Paper-faithful MSTFormer under the shared 90x6 -> 180x2 protocol.

    Retained components: 1/4 ATM augmentation and 3-D CNN, motion-ranked
    first-layer queries, two-layer Transformer encoder, one-layer generative
    decoder, d_model=512, eight heads, d_ff=2048, factor=3 and dropout=0.05.
    """

    def __init__(self):
        super().__init__()
        d_model = 512
        self.token = nn.Conv1d(6, d_model, kernel_size=3, padding=1)
        self.position = nn.Parameter(torch.zeros(1, HISTORY_STEPS, d_model))
        self.atm = AugmentedTrajectoryEncoder(d_model)
        self.dynamic_layer = DynamicAwareEncoderLayer(d_model, 8, 2048, 3, 0.05)
        standard = nn.TransformerEncoderLayer(d_model, 8, 2048, 0.05, "gelu", batch_first=True, norm_first=True)
        self.second_encoder = nn.TransformerEncoder(standard, 1, norm=nn.LayerNorm(d_model))
        self.future_queries = nn.Parameter(torch.zeros(1, FUTURE_STEPS, d_model))
        decoder = nn.TransformerDecoderLayer(d_model, 8, 2048, 0.05, "gelu", batch_first=True, norm_first=True)
        self.decoder = nn.TransformerDecoder(decoder, 1, norm=nn.LayerNorm(d_model))
        self.motion_head = nn.Linear(d_model, 2)
        nn.init.normal_(self.position, std=0.02)
        nn.init.normal_(self.future_queries, std=0.02)
        nn.init.zeros_(self.motion_head.weight)
        nn.init.zeros_(self.motion_head.bias)

    def forward(self, history: torch.Tensor) -> torch.Tensor:
        embedded = self.token(history.transpose(1, 2)).transpose(1, 2) + self.position
        motion = _motion_channels(history)
        delta_speed = motion[..., 9].abs()
        turn = torch.atan2(motion[..., 12], motion[..., 13]).abs()
        recency = 1.0 / torch.log(torch.arange(3, HISTORY_STEPS + 3, device=history.device, dtype=history.dtype)).flip(0)
        importance = recency[None] + delta_speed + turn
        encoded = self.dynamic_layer(embedded + self.atm(history), importance)
        encoded = self.second_encoder(encoded)
        decoded = self.decoder(self.future_queries.expand(history.shape[0], -1, -1), encoded)
        correction_velocity = self.motion_head(decoded)
        base_velocity = (history[:, -1, :2] - history[:, -4, :2]) / 3.0
        velocity = base_velocity[:, None] + 0.02 * torch.tanh(correction_velocity)
        return history[:, -1:, :2] + torch.cumsum(velocity, dim=1)


class FeatureAugmentation(nn.Module):
    def forward(self, history: torch.Tensor) -> torch.Tensor:
        return _motion_channels(history)


class ITransformerFAFaithful(nn.Module):
    """Paper-faithful feature-augmented inverted Transformer.

    Each augmented variable is a token; self-attention is therefore computed
    across variables, not timestamps. An MLP maps encoded variables directly
    to the complete prediction horizon as described in the IJNAOE paper.
    """

    augmented_variables = 14

    def __init__(self, d_model: int = 256, heads: int = 8, layers: int = 3, d_ff: int = 512):
        super().__init__()
        self.augmentation = FeatureAugmentation()
        self.temporal_projection = nn.Sequential(nn.LayerNorm(HISTORY_STEPS), nn.Linear(HISTORY_STEPS, d_model))
        self.variable_embedding = nn.Parameter(torch.zeros(1, self.augmented_variables, d_model))
        layer = nn.TransformerEncoderLayer(d_model, heads, d_ff, 0.1, "gelu", batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, layers, norm=nn.LayerNorm(d_model))
        self.decoder = nn.Sequential(
            nn.Linear(self.augmented_variables * d_model, 1024), nn.GELU(), nn.Dropout(0.1),
            nn.Linear(1024, FUTURE_STEPS * 2),
        )
        nn.init.normal_(self.variable_embedding, std=0.02)
        nn.init.zeros_(self.decoder[-1].weight)
        nn.init.zeros_(self.decoder[-1].bias)

    def forward(self, history: torch.Tensor) -> torch.Tensor:
        augmented = self.augmentation(history)
        tokens = self.temporal_projection(augmented.transpose(1, 2)) + self.variable_embedding
        encoded = self.encoder(tokens).flatten(1)
        residual = self.decoder(encoded).view(-1, FUTURE_STEPS, 2)
        return cv_prediction(history, 3) + residual


FAITHFUL_SPECS = {
    "mstformer_faithful": {
        "factory": MSTFormerFaithful,
        "lr": 5e-6,
        "batch_size": 16,
        "accumulation": 3,
        "epochs": 20,
        "patience": 5,
        "optimizer": "Adam",
        "paper": "Qiang et al., EAAI 148 (2025) 110391",
    },
    "itransformer_fa_faithful": {
        "factory": ITransformerFAFaithful,
        "lr": 1e-4,
        "batch_size": 128,
        "accumulation": 1,
        "epochs": 80,
        "patience": 20,
        "optimizer": "AdamW",
        "paper": "Lee et al., IJNAOE 18 (2026) 100744",
    },
}


def build_faithful_model(name: str) -> nn.Module:
    return FAITHFUL_SPECS[name]["factory"]()
