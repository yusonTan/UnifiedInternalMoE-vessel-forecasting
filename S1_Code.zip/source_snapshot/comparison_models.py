from __future__ import annotations

import math

import torch
from torch import nn


HISTORY_STEPS = 90
FUTURE_STEPS = 180


def cv_prediction(history: torch.Tensor, window: int = 3) -> torch.Tensor:
    position = history[..., :2]
    velocity = (position[:, -1] - position[:, -1 - window]) / float(window)
    steps = torch.arange(1, FUTURE_STEPS + 1, device=history.device, dtype=history.dtype)
    return position[:, -1, None] + steps[None, :, None] * velocity[:, None]


class DirectRNN(nn.Module):
    def __init__(self, kind: str = "lstm", hidden: int = 128):
        super().__init__()
        recurrent = nn.LSTM if kind == "lstm" else nn.GRU
        self.encoder = recurrent(6, hidden, num_layers=2, batch_first=True, dropout=0.1)
        self.head = nn.Sequential(nn.Linear(hidden, 256), nn.GELU(), nn.Linear(256, FUTURE_STEPS * 2))

    def forward(self, history):
        sequence, _ = self.encoder(history)
        return self.head(sequence[:, -1]).view(-1, FUTURE_STEPS, 2)


class CausalBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, dilation: int):
        super().__init__()
        padding = 2 * dilation
        self.padding = padding
        self.conv = nn.Conv1d(in_channels, out_channels, 3, dilation=dilation, padding=padding)
        self.norm = nn.GroupNorm(8, out_channels)
        self.dropout = nn.Dropout(0.1)
        self.residual = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        y = self.conv(x)
        if self.padding:
            y = y[..., :-self.padding]
        return torch.nn.functional.gelu(self.norm(y)) + self.residual(x)


class TCNCV(nn.Module):
    def __init__(self, channels: int = 128):
        super().__init__()
        blocks = []
        incoming = 6
        for dilation in (1, 2, 4, 8, 16, 32):
            blocks.append(CausalBlock(incoming, channels, dilation))
            incoming = channels
        self.network = nn.Sequential(*blocks)
        self.head = nn.Sequential(nn.Linear(channels, 256), nn.GELU(), nn.Linear(256, FUTURE_STEPS * 2))

    def forward(self, history):
        encoded = self.network(history.transpose(1, 2))[..., -1]
        residual = self.head(encoded).view(-1, FUTURE_STEPS, 2)
        return cv_prediction(history, 3) + residual


class TransformerCV(nn.Module):
    def __init__(self, layers: int = 3, d_model: int = 128, heads: int = 4):
        super().__init__()
        self.input_projection = nn.Linear(6, d_model)
        self.position = nn.Parameter(torch.zeros(1, HISTORY_STEPS, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model, heads, dim_feedforward=256, dropout=0.1,
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, layers, norm=nn.LayerNorm(d_model))
        self.head = nn.Sequential(nn.Linear(d_model * 2, 256), nn.GELU(), nn.Linear(256, FUTURE_STEPS * 2))
        nn.init.normal_(self.position, std=0.02)

    def encode(self, history):
        return self.encoder(self.input_projection(history) + self.position[:, : history.shape[1]])

    def forward(self, history):
        sequence = self.encode(history)
        representation = torch.cat((sequence[:, -1], sequence.mean(dim=1)), dim=-1)
        residual = self.head(representation).view(-1, FUTURE_STEPS, 2)
        return cv_prediction(history, 3) + residual


class MSTFormerAdapted(nn.Module):
    """Protocol adaptation of the multi-scale convolution/Transformer idea."""

    def __init__(self, d_model: int = 128):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Conv1d(6, 48, kernel, padding=kernel // 2) for kernel in (3, 5, 7)
        ])
        self.merge = nn.Linear(144, d_model)
        self.position = nn.Parameter(torch.zeros(1, HISTORY_STEPS, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model, 4, dim_feedforward=384, dropout=0.1,
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, 2, norm=nn.LayerNorm(d_model))
        self.pool = nn.Linear(d_model, 1)
        self.head = nn.Sequential(nn.Linear(d_model, 256), nn.GELU(), nn.Linear(256, FUTURE_STEPS * 2))
        nn.init.normal_(self.position, std=0.02)

    def forward(self, history):
        x = history.transpose(1, 2)
        multi_scale = torch.cat([torch.nn.functional.gelu(branch(x)) for branch in self.branches], dim=1)
        sequence = self.merge(multi_scale.transpose(1, 2)) + self.position
        sequence = self.encoder(sequence)
        weights = torch.softmax(self.pool(sequence).squeeze(-1), dim=-1)
        pooled = (weights[..., None] * sequence).sum(dim=1)
        residual = self.head(pooled).view(-1, FUTURE_STEPS, 2)
        return cv_prediction(history, 3) + residual


class ITransformerFAAdapted(nn.Module):
    """Protocol adaptation of inverted-attention long-horizon forecasting."""

    def __init__(self, d_model: int = 128):
        super().__init__()
        self.temporal_projection = nn.Linear(HISTORY_STEPS, d_model)
        self.variable_embedding = nn.Parameter(torch.zeros(1, 6, d_model))
        layer = nn.TransformerEncoderLayer(
            d_model, 4, dim_feedforward=384, dropout=0.1,
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, 3, norm=nn.LayerNorm(d_model))
        self.head = nn.Sequential(nn.Linear(6 * d_model, 256), nn.GELU(), nn.Linear(256, FUTURE_STEPS * 2))
        nn.init.normal_(self.variable_embedding, std=0.02)

    def forward(self, history):
        tokens = self.temporal_projection(history.transpose(1, 2)) + self.variable_embedding
        encoded = self.encoder(tokens).flatten(1)
        residual = self.head(encoded).view(-1, FUTURE_STEPS, 2)
        return cv_prediction(history, 3) + residual


MODEL_SPECS = {
    "direct_lstm": {"factory": lambda: DirectRNN("lstm"), "lr": 5e-4, "batch_size": 256, "category": "baseline"},
    "direct_gru": {"factory": lambda: DirectRNN("gru"), "lr": 5e-4, "batch_size": 256, "category": "baseline"},
    "tcn_cv": {"factory": TCNCV, "lr": 3e-4, "batch_size": 256, "category": "paper_baseline"},
    "transformer_cv": {"factory": TransformerCV, "lr": 3e-4, "batch_size": 128, "category": "paper_baseline"},
    "mstformer_adapted": {"factory": MSTFormerAdapted, "lr": 2e-4, "batch_size": 128, "category": "recent_sota_adapted"},
    "itransformer_fa_adapted": {"factory": ITransformerFAAdapted, "lr": 2e-4, "batch_size": 128, "category": "recent_sota_adapted"},
}


def build_comparison_model(name: str) -> nn.Module:
    return MODEL_SPECS[name]["factory"]()

