"""Streaming ten-seed inference, frozen validation routes and paired evidence."""
from __future__ import annotations
import csv
import gc
import json
import os
import subprocess
import time
from pathlib import Path
import numpy as np
import torch
import revision_2h_results as reusable
from run_revision_10seed import ROOT, OUT, DOMAINS, MODELS, SEEDS, NEW, REUSED, run_of, sha, log
from run_plos_rigor_suite import atomic_json
from run_revision_5h import archive, forward_final
from revision_5h_analysis import jscore, route_blend, paired_uncertainty
from amf.unified_predictor import UnifiedInternalMoE
from amf.data import RobustTrajectoryScaler
from amf.adaptive_moe import AdaptivePhysicsExperts

EXPERTS = UnifiedInternalMoE.expert_order
METRICS = tuple(f'{kind}@{h}' for h in (5, 10, 20, 30, 45, 60) for kind in ('ADE', 'FDE'))
MAIN = 'UnifiedInternalMoE_10seed_refit'
SENS = 'UnifiedInternalMoE_independent_route'


def table(path, rows):
    if not rows:
        raise ValueError('Do not overwrite a result table with empty data')
    fields = list(dict.fromkeys(k for r in rows for k in r))
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.csv.tmp')
    with tmp.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(tmp, path)


def aggregate(rows):
    result = []
    for domain, model in sorted({(r['domain'], r['model']) for r in rows}):
        group = [r for r in rows if r['domain'] == domain and r['model'] == model]
        if len(group) != len(SEEDS) or {r['seed'] for r in group} != set(SEEDS):
            raise RuntimeError(f'Incomplete or duplicate seed cohort: {domain}/{model}')
        r = {'domain': domain, 'model': model, 'protocol': group[0]['protocol'], 'n_seeds': len(group),
             'seeds': ';'.join(map(str, SEEDS)), 'all_expected_seeds_complete': True}
        for key in ('validation_J', 'test_J', *METRICS):
            values = np.asarray([x[key] for x in group], dtype=float)
            if not np.isfinite(values).all():
                raise RuntimeError(f'Nonfinite metric: {key}')
            r[key + '_mean'] = float(values.mean())
            r[key + '_std'] = float(values.std(ddof=1))
        result.append(r)
    return result


def collect(name, domain, seed):
    run = run_of(name, domain, seed)
    checkpoint_hash = sha(run / 'best.pt')
    sources = [OUT / 'predictions' / name / domain / f'seed_{seed}.npz']
    if seed in REUSED:
        sources += [ROOT / folder / 'predictions' / name / domain / f'seed_{seed}.npz'
                    for folder in ('revision_7h_20261009', 'revision_2h_20261009')]
    for source in sources:
        if source.exists():
            z = np.load(source)
            if str(z['checkpoint_sha256'].item()) == checkpoint_hash:
                return z
            z.close()
            if source == sources[0]:
                raise RuntimeError(f'Stale new-output prediction cache: {source}')
    return reusable.collect(name, run, domain, seed)


def validation_candidates(domain, seed):
    predictions, target, ids = [], None, None
    for name in EXPERTS:
        with collect(name, domain, seed) as z:
            current_ids, current_target = z['val_MMSI'], z['val_target']
            if ids is None:
                ids, target = current_ids, current_target
            elif not np.array_equal(current_ids, ids) or np.abs(current_target - target).max() > .05:
                raise RuntimeError('Validation alignment failed')
            predictions.append(z['val_prediction'])
    return np.stack(predictions, axis=1), target, ids


def choose_specialist(scores):
    specialist = min(EXPERTS, key=lambda n: scores[n])
    return specialist if scores[specialist] < scores['keep_committee'] - 1e-5 else None


def with_specialist(weights, specialist):
    w = weights.copy()
    if specialist is not None:
        w[:2] = 0
        w[:2, EXPERTS.index(specialist)] = 1
    return w


def fit_routes(domain):
    base, independent, options, selections = {}, {}, {}, {}
    compact = reusable.compact
    old_candidates = compact.CANDIDATES
    compact.CANDIDATES = EXPERTS
    try:
        for seed in SEEDS:
            p, y, ids = validation_candidates(domain, seed)
            predictions = {n: p[:, k] for k, n in enumerate(EXPERTS)}
            chosen, local, _, ranking = compact.choose_committee(predictions, y, ids, seed)
            weights = np.zeros((3, len(EXPERTS)))
            for k, name in enumerate(chosen['candidates']):
                weights[:, EXPERTS.index(name)] = local[:, k]
            base[seed] = weights
            scores = {'keep_committee' if opt is None else opt:
                      4 * jscore(route_blend(p, {'steps': [15, 30, 180],
                                                'weights': with_specialist(weights, opt)}), y)
                      for opt in (None, *EXPERTS)}
            options[seed] = scores
            specialist = choose_specialist(scores)
            independent[seed] = with_specialist(weights, specialist)
            selections[seed] = {'selected': chosen, 'ranking': ranking,
                                'independent_short_specialist': specialist,
                                'individual_validation_scores': scores}
            del p, y, ids, predictions
            gc.collect()
            log('validation_route_fitted', domain=domain, seed=seed)
    finally:
        compact.CANDIDATES = old_candidates
    shared_scores = {opt: float(np.mean([options[s][opt] for s in SEEDS])) for opt in options[SEEDS[0]]}
    shared = choose_specialist(shared_scores)
    fitted = {s: with_specialist(base[s], shared) for s in SEEDS}
    lock = {'domain': domain, 'shared_validation_seeds': SEEDS, 'selected_short_specialist': shared,
            'mean_validation_goal': shared_scores, 'per_seed_compact_selection': selections,
            'candidate_pool': EXPERTS, 'test_used_for_selection': False,
            'main_route_selection_not_independent_across_seeds': True,
            'independent_route_uses_only_own_seed_validation': True,
            'main_weights': fitted, 'independent_weights': independent}
    atomic_json(OUT / 'fusion_10seed_refit' / domain / 'VALIDATION_SELECTION_LOCK.json', lock)
    return fitted, independent, lock


def errors(prediction, target):
    distance = np.linalg.norm(prediction.astype(np.float64) - target.astype(np.float64), axis=-1)
    return {key: distance[:, :int(key.split('@')[1]) * 3].mean(1) if key.startswith('ADE')
            else distance[:, int(key.split('@')[1]) * 3 - 1] for key in METRICS}


def record_errors(store, model, seed, split, prediction, target):
    for metric, values in errors(prediction, target).items():
        store.setdefault(model, {}).setdefault(split, {}).setdefault(metric, {})[seed] = values


def pack_and_evaluate(domain, seed, weights, independent, selection, store):
    run = OUT / 'fusion_10seed_refit' / domain / f'seed_{seed}'
    model = UnifiedInternalMoE()
    for name, module in zip(EXPERTS, model.expert_modules):
        module.load_state_dict(torch.load(run_of(name, domain, seed) / 'best.pt', map_location='cpu', weights_only=False)['model'], strict=True)
    with torch.no_grad():
        model.global_route_logits.copy_(torch.log(torch.as_tensor(weights.T, dtype=torch.float32).clamp_min(1e-12)))
    model.to(reusable.DEVICE).eval()
    scaler = RobustTrajectoryScaler.load(ROOT / 'cache' / domain / 'scaler.json')
    config = {'model': 'unified_internal_moe', 'domain': domain, 'seed': seed, 'scaler': scaler.__dict__,
              'protocol': 'ten_seed_shared_validation_route_selection', 'knot_weights': weights,
              'short_specialist': selection['selected_short_specialist'],
              'route_choice_shared_across_ten_seeds': True,
              'not_original_submission_route_version': True,
              'expert_checkpoints': {n: str(run_of(n, domain, seed) / 'best.pt') for n in EXPERTS}}
    atomic_json(run / 'config.json', config)
    tmp = run / 'best.pt.tmp'
    torch.save({'model': model.state_dict(), 'epoch': 0, 'scaler': scaler.__dict__, 'protocol': config['protocol']}, tmp)
    os.replace(tmp, run / 'best.pt')
    pp, sens_pp, truth = {}, {}, {}
    for split in ('val', 'test'):
        history, _, ids = reusable.data(domain, split)
        candidates, target = [], None
        for name in EXPERTS:
            with collect(name, domain, seed) as z:
                if not np.array_equal(z[split + '_MMSI'], ids):
                    raise RuntimeError('Fusion replay MMSI mismatch')
                y = z[split + '_target']
                if target is None:
                    target = y
                elif np.abs(target - y).max() > .05:
                    raise RuntimeError('Fusion replay target mismatch')
                candidates.append(z[split + '_prediction'])
        p = np.stack(candidates, axis=1)
        prediction, _ = forward_final(model, history, scaler, capture=False)
        reconstructed = route_blend(p, {'steps': [15, 30, 180], 'weights': weights})
        difference = float(np.abs(prediction - reconstructed).max())
        if difference > .05:
            raise RuntimeError(f'Packed replay mismatch: {domain}/{seed}/{split}/{difference}')
        sensitivity = route_blend(p, {'steps': [15, 30, 180], 'weights': independent}).astype(np.float32)
        archive(run / f'{split}_predictions.npz', prediction=prediction, target=target,
                mmsi=np.asarray(ids), window_index=np.arange(len(ids)), replay_max_abs_m=np.asarray(difference))
        archive(OUT / 'independent_route_sensitivity' / domain / f'seed_{seed}' / f'{split}_predictions.npz',
                prediction=sensitivity, target=target, mmsi=np.asarray(ids), window_index=np.arange(len(ids)),
                weights=independent)
        record_errors(store, MAIN, seed, split, prediction, target)
        record_errors(store, SENS, seed, split, sensitivity, target)
        pp[split], sens_pp[split], truth[split] = prediction, sensitivity, target
        del candidates, p, reconstructed
    main_row = reusable.metric_row(domain, seed, MAIN, config['protocol'], pp['test'], truth['test'], pp['val'], truth['val'], 0)
    sens_row = reusable.metric_row(domain, seed, SENS, 'own_seed_validation_selection_sensitivity_only',
                                   sens_pp['test'], truth['test'], sens_pp['val'], truth['val'], 0)
    del model
    torch.cuda.empty_cache()
    gc.collect()
    return main_row, sens_row


def holm(rows, field):
    adjusted = 0.
    for rank, row in enumerate(sorted(rows, key=lambda r: r['wild_cluster_t_p'])):
        adjusted = max(adjusted, min(1., (len(rows) - rank) * row['wild_cluster_t_p']))
        row[field] = adjusted


def compare_domain(domain, store, ids, rows, changes, sensitivity):
    for metric in METRICS:
        comparator = min((*MODELS, 'CV15'), key=lambda n: np.mean([store[n]['val'][metric][s].mean() for s in SEEDS]))
        ours = np.stack([store[MAIN]['test'][metric][s] for s in SEEDS])
        other = np.stack([store[comparator]['test'][metric][s] for s in SEEDS])
        evidence = paired_uncertainty(other - ours, ids, np.random.default_rng(9000 + len(rows)), draws=10000)
        row = {'domain': domain, 'metric': metric, 'n_seeds': 10,
               'validation_selected_comparator': comparator, 'final_mean_m': float(ours.mean()),
               'comparator_mean_m': float(other.mean()), 'relative_gain_percent': float(100 * (other.mean() - ours.mean()) / max(other.mean(), 1e-12)),
               'validation_only_reference_choice': True, 'bootstrap_draws': 10000,
               'tie_at_display_precision_0p001m': abs(other.mean() - ours.mean()) < .0005, **evidence}
        rows.append(row)
        for k, seed in enumerate(SEEDS):
            changes.append({'domain': domain, 'metric': metric, 'seed': seed, 'comparator': comparator,
                            'final_m': float(ours[k].mean()), 'comparator_m': float(other[k].mean()),
                            'difference_m_comparator_minus_final': float((other[k] - ours[k]).mean())})
        independent = np.stack([store[SENS]['test'][metric][s] for s in SEEDS])
        extra = paired_uncertainty(ours - independent, ids, np.random.default_rng(12000 + len(sensitivity)), draws=10000)
        # The function's legacy interval label is retained conservatively, not
        # relabelled as unconditional inference for this small-cluster study.
        sensitivity.append({'domain': domain, 'metric': metric, 'n_seeds': 10,
                            'shared_route_mean_m': float(ours.mean()), 'own_seed_route_mean_m': float(independent.mean()),
                            'difference_m_shared_minus_own_seed': float((ours - independent).mean()), **extra})
        log('statistics_cell_complete', domain=domain, metric=metric, comparator=comparator)


def verify_numbers(rows, means):
    if len(rows) != 320 or len(means) != 32:
        raise RuntimeError('Expected 320 main rows and 32 model-region summaries')
    for r in means:
        selected = [x for x in rows if x['domain'] == r['domain'] and x['model'] == r['model']]
        for metric in METRICS:
            vals = np.asarray([x[metric] for x in selected], dtype=np.float64)
            expected_std = float(np.sqrt(np.sum((vals - vals.mean())**2) / 9))
            if not np.isclose(expected_std, r[metric + '_std'], rtol=1e-12, atol=1e-10):
                raise RuntimeError('Independent sample-standard-deviation verification failed')


def main():
    torch.set_num_threads(4)
    reusable.OUT = OUT
    rows, sensitivity_metrics, cvs, provenance = [], [], [], []
    paired, seed_changes, route_paired = [], [], []
    for domain in DOMAINS:
        store = {}
        weights, independent, selection = fit_routes(domain)
        reference_ids = None
        for seed in SEEDS:
            for name in MODELS:
                run = run_of(name, domain, seed)
                with collect(name, domain, seed) as z:
                    if reference_ids is None:
                        reference_ids = z['test_MMSI']
                    elif not np.array_equal(z['test_MMSI'], reference_ids):
                        raise RuntimeError('Comparator MMSI ordering mismatch')
                    for split in ('val', 'test'):
                        expected_ids = np.asarray(reusable.data(domain, split)[2])
                        if not np.array_equal(z[split + '_MMSI'], expected_ids) or not np.array_equal(z[split + '_window_index'], np.arange(len(expected_ids))):
                            raise RuntimeError('Comparator window alignment mismatch')
                        record_errors(store, name, seed, split, z[split + '_prediction'], z[split + '_target'])
                    state = torch.load(run / 'best.pt', map_location='cpu', weights_only=False)
                    rows.append(reusable.metric_row(domain, seed, name, 'original_architecture_model_specific_training',
                        z['test_prediction'], z['test_target'], z['val_prediction'], z['val_target'], int(state['epoch'])))
                    del state
                provenance.append({'domain': domain, 'seed': seed, 'model': name, 'source': str(run),
                                   'checkpoint_sha256': sha(run / 'best.pt'), 'new_independent_training': seed in NEW,
                                   'reuse_from_audited_five_seed_cohort': seed in REUSED})
            main_row, sens_row = pack_and_evaluate(domain, seed, weights[seed], independent[seed], selection, store)
            rows.append(main_row)
            sensitivity_metrics.append(sens_row)
            log('seed_evaluation_complete', domain=domain, seed=seed)
        cv_predictions, truths = {}, {}
        for split in ('val', 'test'):
            history, _, _ = reusable.data(domain, split)
            positions = torch.from_numpy(np.asarray(history[..., :2]).copy())
            cv_predictions[split] = AdaptivePhysicsExperts._cv(positions, 15, torch.arange(1, 181).view(1, -1, 1)).numpy()
            with collect('sa_repair', domain, SEEDS[0]) as z:
                truths[split] = z[split + '_target']
            for seed in SEEDS:
                record_errors(store, 'CV15', seed, split, cv_predictions[split], truths[split])
        cvs.append(reusable.metric_row(domain, 0, 'CV15', 'deterministic_reference_not_random_seed',
                    cv_predictions['test'], truths['test'], cv_predictions['val'], truths['val']))
        compare_domain(domain, store, reference_ids, paired, seed_changes, route_paired)
        table(OUT / 'four_domain_10seed_per_seed.csv', rows)
        table(OUT / 'independent_route_per_seed.csv', sensitivity_metrics)
        table(OUT / 'training_provenance.csv', provenance)
        del store, cv_predictions, truths
        gc.collect()
    means = aggregate(rows)
    verify_numbers(rows, means)
    table(OUT / 'four_domain_10seed_mean_std.csv', means)
    table(OUT / 'independent_route_mean_std.csv', aggregate(sensitivity_metrics))
    table(OUT / 'CV15_deterministic_reference.csv', cvs)
    primary = [r for r in paired if r['metric'] in ('ADE@5', 'ADE@10', 'ADE@60')]
    fde = [r for r in paired if r['metric'] in ('FDE@5', 'FDE@10', 'FDE@60')]
    secondary = [r for r in paired if r not in primary and r not in fde]
    holm(primary, 'primary_ADE_12cell_Holm_p')
    holm(fde, 'FDE_12cell_Holm_p')
    holm(secondary, 'secondary_24cell_Holm_p')
    holm([r for r in route_paired if r['metric'] in ('ADE@5', 'ADE@10', 'ADE@60')], 'route_sensitivity_ADE_12cell_Holm_p')
    table(OUT / 'primary_ADE_paired_uncertainty.csv', primary)
    table(OUT / 'all_horizons_paired_uncertainty.csv', paired)
    table(OUT / 'seed_paired_differences.csv', seed_changes)
    table(OUT / 'independent_route_paired_uncertainty.csv', route_paired)
    for family in ('seed', 'MMSI', 'crossed'):
        table(OUT / f'{family}_only_intervals.csv', [{k: r[k] for k in ('domain', 'metric', 'n_seeds',
                'validation_selected_comparator', 'difference_m_comparator_minus_final',
                family + '_CI_low', family + '_CI_high')} for r in paired])
    node = Path('C:/Users/29146/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
    result = subprocess.run([str(node), str(ROOT / 'verify_revision10_csv.mjs'), str(OUT)], cwd=ROOT)
    if result.returncode:
        raise RuntimeError('Artifact-tool CSV verification failed')
    atomic_json(OUT / 'STATISTICS_COMPLETE.json', {'complete': True, 'seeds': SEEDS, 'primary_ADE_cells': len(primary),
            'paired_cells': len(paired), 'bootstrap_draws': 10000, 'ddof': 1,
            'shared_selection_crossed_intervals_are_conditional_descriptive': True,
            'independent_route_sensitivity_complete': True, 'small_MMSI_cluster_inference_is_approximate': True})
    atomic_json(OUT / 'TEN_SEED_COMPLETE.json', {'complete': True, 'domains': DOMAINS, 'seeds': SEEDS,
            'backbone_results': 280, 'packed_fusion_checkpoints': 40, 'main_metric_rows': len(rows),
            'independent_route_rows': len(sensitivity_metrics), 'probability_baseline_remains_five_seed': True,
            'original_three_and_five_seed_files_unchanged': True, 'full_revision_complete': False})
    (OUT / 'REPORT.md').write_text('\n'.join([
        '# Four-domain ten-seed comparison', '', 'Seeds: ' + ', '.join(map(str, SEEDS)),
        'Seven backbone models and 40 self-contained five-expert fusion checkpoints.',
        '140 audited existing backbone runs reused; 140 new backbones (including 20 own-seed two-stage SA runs).',
        'All ten fusion routes refitted using the same validation-only shared specialist rule.',
        'Per-seed independent validation routing is a separately reported sensitivity, not a test-selected replacement.',
        'Sample standard deviations use ddof=1. CV15 is a deterministic reference without artificial seed SD.',
        'Primary ADE, three-horizon FDE and secondary metrics use separate 12/12/24-cell Holm families.',
        'Shared-selection crossed intervals are conditional/descriptive; small-cluster inference is approximate.',
        'The historically observed test set is not an untouched independent external dataset.',
        'BLSTM-MDN remains at five seeds and is not mixed into this ten-seed cohort.',
        'Capacity-matched GRU, deferred internal ablations and independent AIS remain outside this campaign.',
        'No negative seed is deleted. No new architecture is selected using test results.',
        'Full revision checklist and manuscript/reply-letter integration remain incomplete.',
        '', 'Completed at: ' + time.strftime('%Y-%m-%d %H:%M:%S')]), encoding='utf-8')
    log('summary_complete', main_rows=len(rows), summary_rows=len(means))


if __name__ == '__main__':
    main()
