"""Grouped validation experiments; no test-driven selection or deadlines."""
from __future__ import annotations
import argparse
import gc
import itertools
import time
from pathlib import Path
import numpy as np
import torch
from torch import nn
from revision_all_routes_common import *
from revision_followup16_training import snapshot_rng, restore_rng

class SampleGate(nn.Module):
    def __init__(self,kind,route,mask):
        super().__init__();self.kind=kind
        self.base=nn.Parameter(torch.log(torch.as_tensor(route['weights'],dtype=torch.float32).clamp_min(1e-12)))
        self.register_buffer('mask',torch.as_tensor(mask,dtype=torch.bool))
        if kind.startswith('gru'):
            self.encoder=nn.GRU(6,32,batch_first=True)
            width=32+(12 if kind=='gru_disagreement' else 0)
        else:width=20
        self.head=nn.Sequential(nn.Linear(width,32),nn.GELU(),nn.Linear(32,15))
        nn.init.zeros_(self.head[-1].weight);nn.init.zeros_(self.head[-1].bias)
        self.register_buffer('basis',torch.as_tensor(expand_route({'steps':[15,30,180],'weights':np.eye(3)}),dtype=torch.float32))
    def forward(self,x,p):
        if self.kind.startswith('gru'):
            s,_=self.encoder(x);f=s[:,-1]
            if self.kind=='gru_disagreement':
                reference=int(torch.nonzero(self.mask)[0].item())
                others=[k for k in range(5) if k!=reference]
                d=torch.linalg.vector_norm(p[:,others][:,:,[14,29,179]]-p[:,reference:reference+1,[14,29,179]],dim=-1)
                d=d*self.mask[None,others,None]
                f=torch.cat((f,torch.log1p(d).flatten(1)),dim=1)
        else:f=torch.cat((x[:,-1],x.mean(1),x.std(1),(x[:,-1,:2]-x[:,0,:2])/90),dim=1)
        logits=(self.base[None]+3*torch.tanh(self.head(f).reshape(-1,3,5))).masked_fill(~self.mask[None,None],-1e9)
        w=torch.einsum('nak,ta->ntk',logits.softmax(-1),self.basis)
        return torch.einsum('ntk,nktd->ntd',w,p)

@torch.inference_mode()
def predict(model,x,p):
    model.eval();out=[]
    for first in range(0,len(x),256):
        xx=torch.from_numpy(x[first:first+256]).to('cuda')
        pp=torch.from_numpy(p[first:first+256]/600).to('cuda')
        out.append((model(xx,pp)*600).cpu().numpy())
    return np.concatenate(out).astype(np.float32)

def gate_loss(p,y):
    d=torch.linalg.vector_norm(p-y,dim=-1)
    return (30*d[:,:15].mean()+12*d[:,:30].mean()+2*d.mean())/4

def train_head(kind,x,p,y,ids,seed,mask,directory,epochs=None,smoke=False):
    directory.mkdir(parents=True,exist_ok=True)
    keep=tuple(np.flatnonzero(mask))
    held=group_folds(ids,seed+400)[0] if epochs is None else np.zeros(len(ids),bool)
    fitted,selection,_=select_route(p[~held],y[~held],ids[~held],seed,keep=keep)
    torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    model=SampleGate(kind,fitted,mask).cuda()
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    rng=np.random.default_rng(seed)
    best={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    best_epoch,stale,start=0,0,1
    best_score=score(predict(model,x[held],p[held]),y[held]) if epochs is None else None
    records=[{'epoch':0,'inner_J':best_score}]
    checkpoint=directory/'last.pt'
    limit=(2 if smoke else 40) if epochs is None else epochs
    if checkpoint.exists():
        old=torch.load(checkpoint,map_location='cpu',weights_only=False)
        if old['kind']!=kind or not np.array_equal(old['mask'],mask) or old['limit']!=limit:
            raise RuntimeError('Gate resume configuration mismatch')
        model.load_state_dict(old['model']);optimizer.load_state_dict(old['optimizer'])
        restore_rng(old['rng']);rng.bit_generator.state=old['numpy_generator']
        best,best_epoch,best_score,stale,records=old['best'],old['best_epoch'],old['best_score'],old['stale'],old['records']
        start=old['epoch']+1
        if epochs is None and stale>=8:start=limit+1
    for epoch in range(start,limit+1):
        begin=time.time();model.train()
        order=rng.permutation(np.flatnonzero(~held))
        for first in range(0,len(order),256):
            ii=order[first:first+256]
            xx=torch.from_numpy(x[ii]).cuda();pp=torch.from_numpy(p[ii]/600).cuda();yy=torch.from_numpy(y[ii]/600).cuda()
            optimizer.zero_grad(set_to_none=True);loss=gate_loss(model(xx,pp),yy)
            if not torch.isfinite(loss):raise RuntimeError('Nonfinite gate loss')
            loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1);optimizer.step()
        if epochs is None:
            value=score(predict(model,x[held],p[held]),y[held])
            if value<best_score-1e-7:
                best_score,best_epoch,stale=value,epoch,0
                best={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            else:stale+=1
        else:value=None
        records.append({'epoch':epoch,'inner_J':value,'seconds':time.time()-begin})
        tmp=checkpoint.with_suffix('.tmp.pt')
        torch.save({'model':model.state_dict(),'optimizer':optimizer.state_dict(),'rng':snapshot_rng(),
             'numpy_generator':rng.bit_generator.state,'best':best,'best_epoch':best_epoch,'best_score':best_score,
             'stale':stale,'records':records,'epoch':epoch,'kind':kind,'mask':mask,'limit':limit},tmp)
        os.replace(tmp,checkpoint)
        if epochs is None and stale>=8:break
    if epochs is None:model.load_state_dict(best)
    model.eval()
    metadata={'selected_epochs':best_epoch if epochs is None else epochs,'completed_epochs':len(records)-1,
              'epoch0_preserved':True,'time_limited':False,'base_selection':selection,'curve':records}
    atomic_json(directory/'TRAINING_COMPLETE.json',metadata)
    return model,metadata

def routing_unit(domain,seed,scope,smoke=False):
    directory=OUT/('smoke' if smoke else 'routing')/scope/domain/f'seed_{seed}'
    if (directory/'RESULT.json').exists():return
    p,y,ids,_=load_data(domain,seed);x=history(domain)
    if smoke:
        ix=np.concatenate([np.flatnonzero(ids==g)[:6] for g in np.unique(ids)[:12]])
        p,y,ids,x=p[ix],y[ix],ids[ix],x[ix]
    mask=np.ones(5,bool) if scope=='all5' else active_mask(domain,seed)
    keep=tuple(np.flatnonzero(mask));folds=group_folds(ids,seed)
    outer=[];fit_choices={};gates={};static={};val_scores={}
    for kind in (*STATIC,*HEADS):
        oof=np.empty_like(y);records=[]
        for fold,h in enumerate(folds):
            if kind in STATIC:
                route,choice,_=select_route(p[~h],y[~h],ids[~h],seed+fold,keep,kind=kind)
                oof[h]=route_blend(p[h],route)
            else:
                m,selection=train_head(kind,x[~h],p[~h],y[~h],ids[~h],seed+fold,mask,
                    directory/'heads'/kind/f'outer_{fold}'/'selection',smoke=smoke)
                epoch=selection['selected_epochs'];del m
                m,choice=train_head(kind,x[~h],p[~h],y[~h],ids[~h],seed+fold,mask,
                    directory/'heads'/kind/f'outer_{fold}'/'refit',epochs=epoch,smoke=smoke)
                oof[h]=predict(m,x[h],p[h]);del m
            records.append({'fold':fold,'J':score(oof[h],y[h]),'choice':choice})
        outer.extend({'domain':domain,'seed':seed,'protocol':scope,'model':kind,**r} for r in records)
        val_scores[kind]=score(oof,y)
        if kind in STATIC:
            static[kind],choice,_=select_route(p,y,ids,seed,keep,kind=kind)
        else:
            m,selection=train_head(kind,x,p,y,ids,seed,mask,directory/'heads'/kind/'final_selection',smoke=smoke)
            epoch=selection['selected_epochs'];del m
            gates[kind],choice=train_head(kind,x,p,y,ids,seed,mask,directory/'heads'/kind/'final_refit',epochs=epoch,smoke=smoke)
        fit_choices[kind]=choice
        emit('routing_method_fitted',domain=domain,seed=seed,scope=scope,model=kind)
    # Lock choices before loading test candidates.
    atomic_json(directory/'VALIDATION_SELECTION_LOCK.json',{'mask':mask,'choices':fit_choices,
         'routes':static,'test_used_for_selection':False,'outer':outer,'source':'ten_seed_frozen_experts'})
    pt,yt,it,jt=load_data(domain,seed,'test');xt=history(domain,'test')
    if smoke:pt,yt,it,jt,xt=pt[:16],yt[:16],it[:16],jt[:16],xt[:16]
    preds={kind:route_blend(pt,route) for kind,route in static.items()}
    for kind,m in gates.items():
        preds[kind]=predict(m,xt,pt)
        torch.save({'model':m.cpu().state_dict(),'kind':kind,'mask':mask,'route_initialization':fit_choices[kind]},directory/f'{kind}.pt')
    save_evaluation(directory,domain,seed,scope,pt,yt,it,jt,preds,val_scores)
    atomic_json(directory/'OUTER_FOLDS.json',outer)
    emit('routing_unit_complete',domain=domain,seed=seed,scope=scope)

def anchors_unit(domain,seed):
    directory=OUT/'anchors'/domain/f'seed_{seed}'
    if (directory/'RESULT.json').exists():return
    p,y,ids,_=load_data(domain,seed)
    routes={};validation={};choices={};outer=[]
    for minutes in ANCHORS:
        tag='anchors_'+'_'.join(map(str,minutes));oof=np.empty_like(y)
        for fold,h in enumerate(group_folds(ids,seed)):
            route,c,_=select_route(p[~h],y[~h],ids[~h],seed+fold,minutes=minutes)
            oof[h]=route_blend(p[h],route)
            outer.append({'domain':domain,'seed':seed,'configuration':tag,'fold':fold,'J':score(oof[h],y[h]),'ridge':c['ridge']})
        began=time.time()
        routes[tag],choices[tag],_=select_route(p,y,ids,seed,minutes=minutes)
        choices[tag].update(fit_seconds=time.time()-began,route_coefficients=5*len(minutes),
                           active_experts=int((routes[tag]['weights'].max(0)>1e-6).sum()))
        validation[tag]=score(oof,y)
    atomic_json(directory/'VALIDATION_SELECTION_LOCK.json',{'routes':routes,'choices':choices,'outer':outer,
         'test_used_for_selection':False,'nested_selection':True,'fixed_expert_set':EXPERTS})
    pt,yt,it,jt=load_data(domain,seed,'test')
    preds={k:route_blend(pt,v) for k,v in routes.items()}
    save_evaluation(directory,domain,seed,'nested_anchor_sensitivity',pt,yt,it,jt,preds,validation)
    emit('anchors_unit_complete',domain=domain,seed=seed)

def alternate_unit(domain,seed):
    directory=OUT/'alternate_objective'/domain/f'seed_{seed}'
    if (directory/'RESULT.json').exists():return
    p,y,ids,_=load_data(domain,seed)
    fitted={};locks={};selection_rows=[];val_scores={}
    full_bank=ObjectiveRouteBank(p,y,ids,seed)
    folds=group_folds(ids,seed)
    outer_banks=[ObjectiveRouteBank(p[~h],y[~h],ids[~h],seed+fold) for fold,h in enumerate(folds)]
    for scale_name in ('original','CV15_validation','best_expert_validation','median_expert_validation'):
        scales=scales_for(p,y,domain,scale_name)
        for hw in ((1.,1.,2.),(1.,1.,1.),(1.,1.,4.)):
            tag=scale_name+'__'+''.join(str(int(w)) for w in hw)
            # Denominators below are recomputed on each outer training split.
            route,choice,ranking=full_bank.select(scales,hw)
            fold_values=[]
            for fold,h in enumerate(folds):
                if scale_name=='original':inner_scales=(20.,50.,600.)
                elif scale_name=='CV15_validation':
                    from amf.adaptive_moe import AdaptivePhysicsExperts
                    hx=np.load(ROOT/'cache'/domain/f'{domain}_val'/'history.npy',mmap_mode='r')
                    cv=AdaptivePhysicsExperts._cv(torch.from_numpy(np.asarray(hx[~h,:,:2]).copy()),15,torch.arange(1,181).view(1,-1,1)).numpy()
                    inner_scales=tuple(max(displacement_metrics(cv,y[~h])[f'ADE@{t}'],1e-6) for t in (5,10,60))
                else:
                    a=np.asarray([[displacement_metrics(p[~h,k],y[~h])[f'ADE@{t}'] for t in (5,10,60)] for k in range(5)])
                    inner_scales=tuple(np.maximum(a.min(0) if scale_name=='best_expert_validation' else np.median(a,axis=0),1e-6))
                inner,chosen,_=outer_banks[fold].select(inner_scales,hw)
                # Own-run validation short-specialist override, never shared across seeds.
                options=[inner]
                for k in range(5):
                    w=inner['weights'].copy();w[:2]=0;w[:2,k]=1;options.append({'steps':[15,30,180],'weights':w})
                inner=min(options,key=lambda r:score(route_blend(p[~h],r),y[~h],inner_scales,hw))
                fold_values.append(score(route_blend(p[h],inner),y[h],inner_scales,hw))
            options=[route]
            for k in range(5):
                w=route['weights'].copy();w[:2]=0;w[:2,k]=1;options.append({'steps':[15,30,180],'weights':w})
            selected=min(range(6),key=lambda k:score(route_blend(p,options[k]),y,scales,hw))
            fitted[tag]=options[selected];locks[tag]={'scales':scales,'horizon_weights':hw,'chosen':choice,
                'ranking':ranking,'short_specialist':None if selected==0 else EXPERTS[selected-1],
                'nested_outer_scores':fold_values,'selection_uses_only_own_seed':True}
            val_scores[tag]=score(route_blend(p,fitted[tag]),y)
            selection_rows.append({'domain':domain,'seed':seed,'model':tag,'scales':scales,'horizon_weights':hw,
                 'outer_validation_alternate_J':float(np.mean(fold_values)), 'actual_route_refit':True})
    atomic_json(directory/'VALIDATION_SELECTION_LOCK.json',{'routes':fitted,'choices':locks,'selection_rows':selection_rows,
         'test_used_for_selection':False,'fit_surrogate':'same anchor least squares; changed validation selection objective'})
    pt,yt,it,jt=load_data(domain,seed,'test')
    preds={k:route_blend(pt,r) for k,r in fitted.items()}
    save_evaluation(directory,domain,seed,'alternate_validation_reselection',pt,yt,it,jt,preds,val_scores)
    emit('alternate_objective_unit_complete',domain=domain,seed=seed)

def stability_unit(seed):
    directory=OUT/'stability'/f'seed_{seed}'
    if (directory/'RESULT.json').exists():return
    p,y,ids,_=load_data('piraeus',seed);groups=np.unique(ids)
    full,choice,ranking=select_route(p,y,ids,seed,subsets=True)
    rng=np.random.default_rng(seed+18000);rows=[];anonymous=[]
    for fraction in (.25,.5,.75,1.):
        repeats=1 if fraction==1 else 50
        for repeat in range(repeats):
            chosen=groups if fraction==1 else rng.choice(groups,max(3,round(len(groups)*fraction)),replace=False)
            included=np.isin(ids,chosen)
            fit,c,_=select_route(p[included],y[included],ids[included],seed+repeat,subsets=True)
            rows.append({'seed':seed,'fraction':fraction,'repeat':repeat,'selected_MMSI':len(chosen),
                'windows':int(included.sum()),'ridge':c['ridge'],'active_experts':';'.join(EXPERTS[k] for k in np.flatnonzero(fit['weights'].max(0)>1e-6)),
                'mean_anchor_weight_absolute_change':float(np.abs(fit['weights']-full['weights']).mean()),
                'heldout_validation_J':None if fraction==1 else score(route_blend(p[~included],fit),y[~included]),
                'full_fraction_not_repeated_as_independent':fraction==1,'weights':fit['weights']})
    for j,g in enumerate(groups):anonymous.append({'anonymous_validation_ship':j,'windows':int((ids==g).sum())})
    atomic_json(directory/'RESULT.json',{'complete':True,'rows':rows,'anonymous_counts':anonymous,
         'full_selection':choice,'subsample_ridge_and_subset_reselected':True,'test_labels_used':False})
    emit('stability_unit_complete',seed=seed)

def internal_summary():
    import revision_2h_results as old
    rows=[];fusion=[];provenance=[];all_errors=[]
    for domain in DOMAINS:
        for variant in ('full','uniform_router'):
            records={};directory=OUT/'internal_fusion'/domain/variant
            for seed in FIVE:
                z=collect_sa(variant,domain,seed)
                p,y,ids,index=load_data(domain,seed)
                if not np.array_equal(ids,z['val_MMSI']) or np.max(np.abs(y-z['val_target']))>.05:
                    raise RuntimeError('SA ablation window mismatch')
                loaded={'sa_repair':z}
                for k,name in enumerate(EXPERTS[1:],1):
                    with collect_main(name,domain,seed) as other:loaded[name]={kk:other[kk].copy() for kk in other.files}
                records[seed]=loaded
                rows.append(old.metric_row(domain,seed,variant,'matched_internal_five_seed',z['test_prediction'],z['test_target'],z['val_prediction'],z['val_target']))
                a,b=sa_pair(variant,domain,seed)
                provenance.append({'domain':domain,'seed':seed,'variant':variant,'pretraining':str(a),'repair':str(b),'checkpoint_sha256':sha(b/'best.pt')})
                archive(OUT/'internal_errors'/domain/variant/f'seed_{seed}.npz',mmsi=z['test_MMSI'],**errors(z['test_prediction'],z['test_target']))
            weights,lock=old.fit_fusion_group(records,FIVE,domain)
            atomic_json(directory/'VALIDATION_SELECTION_LOCK.json',lock)
            for seed,zr in records.items():
                predicted={}
                for split in ('val','test'):
                    p=np.stack([zr[n][split+'_prediction'] for n in EXPERTS],axis=1)
                    predicted[split]=route_blend(p,{'steps':[15,30,180],'weights':weights[seed]})
                z=zr['sa_repair']
                fusion.append(old.metric_row(domain,seed,variant,'refitted_fusion_five_seed',predicted['test'],z['test_target'],predicted['val'],z['val_target']))
                archive(directory/f'seed_{seed}'/'test_errors.npz',mmsi=z['test_MMSI'],**errors(predicted['test'],z['test_target']))
            del records;gc.collect()
    table('SA_internal_uniform_per_seed.csv',rows)
    table('SA_internal_uniform_mean_std.csv',mean_std(rows,keys=('domain','model','protocol'),expected=FIVE))
    table('fusion_internal_uniform_per_seed.csv',fusion)
    table('fusion_internal_uniform_mean_std.csv',mean_std(fusion,expected=FIVE))
    table('SA_training_provenance.csv',provenance)
    for family in ('SA_only','whole_fusion'):
        for domain in DOMAINS:
            for metric in METRICS:
                d=[]
                for seed in FIVE:
                    paths=[OUT/'internal_errors'/domain/v/f'seed_{seed}.npz' if family=='SA_only' else
                           OUT/'internal_fusion'/domain/v/f'seed_{seed}'/'test_errors.npz' for v in ('full','uniform_router')]
                    with np.load(paths[0]) as f,np.load(paths[1]) as u:
                        if not np.array_equal(f['mmsi'],u['mmsi']):raise RuntimeError('Paired MMSI mismatch')
                        ids=f['mmsi'].copy();d.append(u[metric]-f[metric])
                all_errors.append({'family':family,'domain':domain,'metric':metric,'n_seeds':5,
                    'difference_direction':'uniform_minus_adaptive_positive_favors_full',
                    **paired_uncertainty(np.stack(d),ids,np.random.default_rng(24000+len(all_errors)),draws=10000)})
        selected=[r for r in all_errors if r['family']==family and r['metric'] in ('ADE@5','ADE@10','ADE@60')]
        holm(selected,'primary_ADE_12cell_Holm_p')
        holm([r for r in all_errors if r['family']==family and r['metric'] in ('FDE@5','FDE@10','FDE@60')],'FDE_12cell_Holm_p')
    table('SA_internal_uniform_paired_uncertainty.csv',all_errors)
    atomic_json(OUT/'INTERNAL_COMPLETE.json',{'complete':True,'four_domains_five_seeds':True,
             'whole_fusion_shared_short_specialist_dependence':True})

def summary():
    routing=[];anchors=[];alternate=[];outer=[];choices=[];stability=[];paired=[];anchor_details=[];weight_rows=[]
    for domain in DOMAINS:
        for seed in SEEDS:
            for scope in ('all5','formal_mask'):
                directory=OUT/'routing'/scope/domain/f'seed_{seed}'
                routing+=read(directory/'RESULT.json')['rows'];outer+=read(directory/'OUTER_FOLDS.json')
            anchors+=read(OUT/'anchors'/domain/f'seed_{seed}'/'RESULT.json')['rows']
            lock=read(OUT/'anchors'/domain/f'seed_{seed}'/'VALIDATION_SELECTION_LOCK.json')
            for name,c in lock['choices'].items():
                anchor_details.append({'domain':domain,'seed':seed,'configuration':name,'ridge':c['ridge'],
                    'fit_seconds':c['fit_seconds'],'route_coefficients':c['route_coefficients'],'active_experts':c['active_experts']})
                for a,(step,w) in enumerate(zip(lock['routes'][name]['steps'],lock['routes'][name]['weights'])):
                    for k,value in enumerate(w):weight_rows.append({'domain':domain,'seed':seed,'configuration':name,
                        'anchor_min':step/3,'expert':EXPERTS[k],'weight':value})
            directory=OUT/'alternate_objective'/domain/f'seed_{seed}'
            alternate+=read(directory/'RESULT.json')['rows'];choices+=read(directory/'VALIDATION_SELECTION_LOCK.json')['selection_rows']
    for seed in SEEDS:stability+=read(OUT/'stability'/f'seed_{seed}'/'RESULT.json')['rows']
    table('routing_10seed_per_seed.csv',routing);table('routing_10seed_mean_std.csv',mean_std(routing))
    table('routing_outer_folds.csv',outer)
    table('anchors_10seed_per_seed.csv',anchors);table('anchors_10seed_mean_std.csv',mean_std(anchors))
    table('anchor_fit_costs.csv',anchor_details);table('anchor_weights.csv',weight_rows)
    table('alternate_objective_10seed_per_seed.csv',alternate);table('alternate_objective_10seed_mean_std.csv',mean_std(alternate))
    table('alternate_objective_validation_selection.csv',choices);table('piraeus_validation_size_stability.csv',stability)
    for scope in ('all5','formal_mask'):
        for name in (*STATIC[:3],*HEADS):
            for domain in DOMAINS:
                for metric in ('ADE@5','ADE@10','ADE@60','FDE@5','FDE@10','FDE@60'):
                    delta=[]
                    for seed in SEEDS:
                        with np.load(OUT/'routing'/scope/domain/f'seed_{seed}'/'test_errors.npz') as z:
                            delta.append(z['three_anchor__'+metric]-z[name+'__'+metric]);ids=z['mmsi'].copy()
                    paired.append({'scope':scope,'method':name,'domain':domain,'metric':metric,'n_seeds':10,
                        'direction':'three_anchor_minus_method_positive_favors_method',
                        **paired_uncertainty(np.stack(delta),ids,np.random.default_rng(30000+len(paired)),draws=10000)})
            for kind in ('ADE','FDE'):
                holm([r for r in paired if r['scope']==scope and r['method']==name and r['metric'].startswith(kind)],kind+'_12cell_Holm_p')
    table('routing_paired_uncertainty.csv',paired)
    macro=[]
    for family,rr in (('routing',routing),('anchors',anchors),('alternate',alternate)):
        for model,protocol in sorted({(r['model'],r['protocol']) for r in rr}):
            ss=[r for r in rr if (r['model'],r['protocol'])==(model,protocol)]
            macro.append({'family':family,'model':model,'protocol':protocol,'four_region_equal_macro_J':float(np.mean([r['test_J'] for r in ss]))})
    table('routing_macro_objectives.csv',macro)
    # The diagnostic three-anchor fit is not silently called the original
    # compact predictor. Preserve its actual ten-seed results separately.
    with (MAIN/'four_domain_10seed_per_seed.csv').open(encoding='utf-8-sig',newline='') as f:
        source=[r for r in csv.DictReader(f) if r['model']=='UnifiedInternalMoE_10seed_refit']
    reference=[]
    for r in source:
        reference.append({'domain':r['domain'],'seed':int(r['seed']),'model':r['model'],
             'protocol':'existing_formal_10seed_route_reference',
             **{k:float(r[k]) for k in ('validation_J','test_J',*METRICS)}})
    table('formal_route_reference_per_seed.csv',reference)
    table('formal_route_reference_mean_std.csv',mean_std(reference))
    figures(routing,anchors,alternate,stability)
    atomic_json(OUT/'ANALYSIS_COMPLETE.json',{'complete':True,'routing_rows':len(routing),'anchors_rows':len(anchors),
         'alternate_rows':len(alternate),'stability_rows':len(stability),'seed_sd_ddof':1})

def figures(routing,anchors,alternate,stability):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    target=OUT/'figures';target.mkdir(exist_ok=True)
    for scope in ('all5','formal_mask'):
        names=(*STATIC,*HEADS)
        matrix=np.array([[np.mean([r['test_J'] for r in routing if r['domain']==d and r['model']==n and r['protocol']==scope])
                           for n in names] for d in DOMAINS])
        fig,ax=plt.subplots(figsize=(11,3.3));im=ax.imshow(matrix,aspect='auto',cmap='viridis_r')
        ax.set_xticks(range(len(names)),names,rotation=20,ha='right');ax.set_yticks(range(4),DOMAINS)
        ax.set_title('Ten-seed mean test J; lower is better ('+scope+')');fig.colorbar(im,ax=ax,label='J (dimensionless)')
        for i in range(4):
            for j in range(len(names)):ax.text(j,i,f'{matrix[i,j]:.3f}',ha='center',va='center',color='black',fontsize=9)
        fig.tight_layout();fig.savefig(target/f'routing_{scope}.png',dpi=250);fig.savefig(target/f'routing_{scope}.pdf');plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,3.6))
    for ax,h in zip(axes,(5,10,60)):
        for i,domain in enumerate(DOMAINS):
            vals=[r[f'ADE@{h}'] for r in routing if r['domain']==domain and r['model']=='three_anchor' and r['protocol']=='all5']
            ax.scatter(np.full(len(vals),i),vals,s=20,alpha=.7)
        ax.set_xticks(range(4),DOMAINS,rotation=20);ax.set_title(f'ADE@{h}');ax.set_ylabel('Error (m)')
    fig.tight_layout();fig.savefig(target/'three_anchor_seed_distribution.png',dpi=250);plt.close(fig)
    fig,ax=plt.subplots(figsize=(6,3.5))
    fractions=(.25,.5,.75)
    vals=[np.array([r['mean_anchor_weight_absolute_change'] for r in stability if r['fraction']==f]) for f in fractions]
    ax.boxplot(vals,tick_labels=['25%','50%','75%']);ax.set_xlabel('Validation MMSI retained')
    ax.set_ylabel('Mean absolute anchor-weight change');fig.tight_layout();fig.savefig(target/'piraeus_route_stability.png',dpi=250);plt.close(fig)

def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',required=True,choices=('routing','anchors','alternate','stability','internal','summary','smoke'))
    p.add_argument('--domain');p.add_argument('--seed',type=int);p.add_argument('--scope',default='all5');args=p.parse_args()
    torch.set_num_threads(4);torch.set_num_interop_threads(2)
    if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; refuse CPU fallback')
    if args.phase=='routing':routing_unit(args.domain,args.seed,args.scope)
    elif args.phase=='anchors':anchors_unit(args.domain,args.seed)
    elif args.phase=='alternate':alternate_unit(args.domain,args.seed)
    elif args.phase=='stability':stability_unit(args.seed)
    elif args.phase=='internal':internal_summary()
    elif args.phase=='summary':summary()
    else:
        routing_unit('piraeus',42,'all5',smoke=True)
        atomic_json(OUT/'ROUTING_SMOKE_COMPLETE.json',{'complete':True,'all_seven_route_methods':True})

if __name__=='__main__':main()
