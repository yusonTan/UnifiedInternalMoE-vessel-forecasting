from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from torch.amp import GradScaler, autocast
from torch.utils.data import DataLoader

from amf.data import EnvShipDataset, RobustTrajectoryScaler, build_cache, resolve_split_file
from amf.metrics import displacement_metrics, weighted_huber
from amf.trainer import seed_everything
from comparison_models import MODEL_SPECS, build_comparison_model


ROOT = Path(__file__).resolve().parent


def atomic_save(payload, path: Path):
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def append_jsonl(path: Path, payload):
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False) + "\n")


@torch.no_grad()
def evaluate(model, loader, scaler, device, save_path: Path | None = None):
    model.eval()
    predictions, targets = [], []
    for history, target, _ in loader:
        history = history.to(device, non_blocking=True)
        prediction = model(history)
        predictions.append(prediction.cpu().numpy())
        targets.append(target.numpy())
    prediction_m = scaler.inverse_positions(np.concatenate(predictions))
    target_m = scaler.inverse_positions(np.concatenate(targets))
    if save_path is not None:
        np.savez_compressed(
            save_path,
            prediction=prediction_m.astype(np.float32),
            target=target_m.astype(np.float32),
        )
    return displacement_metrics(prediction_m, target_m)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=tuple(MODEL_SPECS), required=True)
    parser.add_argument("--domain", choices=("dma", "noaa", "norway", "piraeus"), default="dma")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-root", type=Path, default=ROOT / "paper_comparison")
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--quick-smoke", action="store_true")
    args = parser.parse_args()
    seed_everything(args.seed)
    # cuDNN's deterministic dilated-Conv1d path is pathologically slow on the
    # RTX 3060 (about 18 minutes/epoch versus seconds for the other backbones).
    # The paper fixes random seeds but does not require deterministic kernels.
    if args.model == "tcn_cv" and torch.cuda.is_available():
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True
    spec = MODEL_SPECS[args.model]
    run = args.output_root / "runs" / args.model / args.domain / f"seed_{args.seed}"
    run.mkdir(parents=True, exist_ok=True)
    scaler = RobustTrajectoryScaler.load(ROOT / "cache" / args.domain / "scaler.json")
    datasets = {}
    for split in ("train", "val", "test"):
        source = resolve_split_file(ROOT.parent / "data", args.domain, split)
        cache = build_cache(source, ROOT / "cache" / args.domain, force=False)
        datasets[split] = EnvShipDataset(cache, scaler)
    if args.quick_smoke:
        from torch.utils.data import Subset
        datasets = {name: Subset(ds, range(min(len(ds), size))) for (name, ds), size in zip(datasets.items(), (1024, 512, 512))}
        args.epochs, args.patience = 2, 2
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loaders = {
        name: DataLoader(
            dataset, batch_size=int(spec["batch_size"]), shuffle=name == "train",
            num_workers=args.num_workers, pin_memory=device.type == "cuda",
            persistent_workers=args.num_workers > 0,
        ) for name, dataset in datasets.items()
    }
    model = build_comparison_model(args.model).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(spec["lr"]), weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)
    amp = device.type == "cuda"
    grad_scaler = GradScaler("cuda", enabled=amp)
    start_epoch, best_score, stale = 1, float("inf"), 0
    last_path, best_path = run / "last.pt", run / "best.pt"
    if args.resume and last_path.exists():
        state = torch.load(last_path, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        start_epoch = int(state["epoch"]) + 1
        best_score, stale = float(state["best_score"]), int(state["stale"])
    config = {
        "model": args.model, "category": spec["category"], "domain": args.domain,
        "seed": args.seed, "input": "90x6", "output": "180x2", "sampling_seconds": 20,
        "optimizer": "AdamW", "learning_rate": spec["lr"], "weight_decay": 1e-4,
        "batch_size": spec["batch_size"], "epochs": args.epochs, "patience": args.patience,
        "scheduler": "cosine", "minimum_learning_rate": 1e-6, "gradient_clip": 1.0,
        "loss": "weighted_huber_first_30_steps_x2", "checkpoint_score": "ADE@60+2*ADE@10",
        "parameter_count": sum(p.numel() for p in model.parameters()), "device": str(device),
    }
    (run / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    training_started = time.time()
    for epoch in range(start_epoch, args.epochs + 1):
        model.train()
        loss_sum, count = 0.0, 0
        epoch_started = time.time()
        for history, target, _ in loaders["train"]:
            history = history.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(device_type=device.type, enabled=amp):
                prediction = model(history)
                loss = weighted_huber(prediction, target)
            grad_scaler.scale(loss).backward()
            grad_scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            grad_scaler.step(optimizer)
            grad_scaler.update()
            loss_sum += float(loss.detach()) * history.shape[0]
            count += history.shape[0]
        validation = evaluate(model, loaders["val"], scaler, device)
        score = validation["ADE@60"] + 2.0 * validation["ADE@10"]
        if score < best_score - 1e-6:
            best_score, stale = score, 0
            atomic_save({"model": model.state_dict(), "epoch": epoch, "score": score}, best_path)
        else:
            stale += 1
        scheduler.step()
        payload = {
            "epoch": epoch, "train_loss": loss_sum / max(count, 1), "score": score,
            "best_score": best_score, "stale": stale, "lr": optimizer.param_groups[0]["lr"],
            "seconds": time.time() - epoch_started, **{f"val_{k}": v for k, v in validation.items()},
        }
        append_jsonl(run / "training.jsonl", payload)
        print(json.dumps(payload), flush=True)
        atomic_save({
            "model": model.state_dict(), "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(), "epoch": epoch,
            "best_score": best_score, "stale": stale,
        }, last_path)
        if stale >= args.patience:
            break
    best = torch.load(best_path, map_location=device, weights_only=False)
    model.load_state_dict(best["model"])
    result = {
        "model": args.model, "domain": args.domain, "seed": args.seed,
        "selected_epoch": int(best["epoch"]), "validation_score": float(best["score"]),
        "validation": evaluate(model, loaders["val"], scaler, device),
        "test": evaluate(model, loaders["test"], scaler, device, run / "test_predictions.npz"),
        "parameter_count": config["parameter_count"],
        "training_seconds": time.time() - training_started,
    }
    temporary = run / "result.json.tmp"
    temporary.write_text(json.dumps(result, indent=2), encoding="utf-8")
    os.replace(temporary, run / "result.json")
    print(json.dumps({"result": result}), flush=True)


if __name__ == "__main__":
    main()
