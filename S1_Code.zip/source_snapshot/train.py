from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, Subset, WeightedRandomSampler

from amf.data import (
    EnvShipDataset,
    RobustTrajectoryScaler,
    build_cache,
    resolve_split_file,
)
from amf.model import AMFResLSTM
from amf.adaptive_moe import AdaptiveHorizonMoE, IntentMultiScaleMoE
from amf.heterogeneous_moe import HeterogeneousSingleMoE, SlimLongHorizonMoE
from amf.unified_predictor import UnifiedInternalMoE
from amf.trainer import seed_everything, train_model


def parse_args():
    parser = argparse.ArgumentParser(description="Train the rebuilt AMF-ResLSTM predictor")
    parser.add_argument("--data-root", type=Path, default=Path("../data"))
    parser.add_argument("--domain", choices=("dma", "noaa", "norway", "piraeus"), default="dma")
    parser.add_argument("--cache-dir", type=Path, default=Path("cache"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--model",
        choices=(
            "amf_reslstm", "adaptive_moe", "intent_multiscale_moe",
            "heterogeneous_single_moe",
            "slim_long_moe",
            "unified_internal_moe",
        ),
        default="amf_reslstm",
    )
    parser.add_argument(
        "--adaptive-variant",
        choices=(
            "full", "no_local_frame", "fixed_dynamics",
            "uniform_router", "no_residual_gate",
        ),
        default="full",
    )
    parser.add_argument("--heterogeneous-release-scale", type=float, default=1.0)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--learning-rate", type=float, default=5e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--min-learning-rate", type=float, default=1e-6)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--max-training-seconds", type=float, default=0.0)
    parser.add_argument("--accel-clip", type=float, default=0.15)
    parser.add_argument("--accel-tau", type=float, default=15.0)
    parser.add_argument("--coverage-weight", type=float, default=1e-3)
    parser.add_argument("--velocity-weight", type=float, default=0.0)
    parser.add_argument("--acceleration-weight", type=float, default=0.0)
    parser.add_argument("--heading-weight", type=float, default=0.0)
    parser.add_argument("--anchor-weight", type=float, default=0.0)
    parser.add_argument("--tail-weight", type=float, default=0.0)
    parser.add_argument("--intent-weight", type=float, default=0.0)
    parser.add_argument("--alignment-weight", type=float, default=0.0)
    parser.add_argument("--curvature-weight", type=float, default=0.0)
    parser.add_argument("--ema-decay", type=float, default=0.0)
    parser.add_argument("--difficulty-sampling-strength", type=float, default=0.0)
    parser.add_argument("--distillation-target", type=Path)
    parser.add_argument("--distillation-weight", type=float, default=0.0)
    parser.add_argument("--heterogeneous-expert-weight", type=float, default=0.15)
    parser.add_argument("--heterogeneous-router-weight", type=float, default=0.05)
    parser.add_argument(
        "--unified-study-root", type=Path, default=Path("complete_3seed_4domain_study")
    )
    parser.add_argument(
        "--unified-diagnostic-root", type=Path, default=Path("eight_hour_diagnostic")
    )
    parser.add_argument("--protect-initial-validation", action="store_true")
    parser.add_argument(
        "--heterogeneous-variant",
        choices=HeterogeneousSingleMoE.internal_variants,
        default="full",
    )
    parser.add_argument(
        "--selection-score", choices=("legacy", "goal_normalized", "ade60"), default="legacy"
    )
    parser.add_argument(
        "--v6-variant",
        choices=(
            "multiscale", "intent", "joint", "joint_aligned_intent",
            "joint_aligned_intent_ctrv", "joint_aligned_intent_spline",
            "joint_aligned_intent_horizon_scale",
            "joint_aligned_intent_anchor_residual",
        ),
        default="joint",
    )
    parser.add_argument(
        "--component-ablation",
        choices=IntentMultiScaleMoE.component_ablations,
        default="full",
        help="Single-component intervention for the final SA-MoE study.",
    )
    parser.add_argument("--init-checkpoint", type=Path)
    parser.add_argument("--router-temperature-override", type=float, default=None,
                        help="Hold router temperature fixed during matched SA component ablations.")
    parser.add_argument("--no-tsk", action="store_true")
    parser.add_argument(
        "--variant",
        choices=(
            "full", "no_tsk", "no_coverage", "no_residual",
            "with_tsk", "uniform_gate", "cv3_only", "no_dca", "lstm_only",
        ),
        default="full",
    )
    parser.add_argument("--anisotropic-position-scale", action="store_true")
    parser.add_argument("--force-cache", action="store_true")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--quick-smoke", action="store_true")
    return parser.parse_args()


class DistillationDataset(Dataset):
    def __init__(self, base: Dataset, target_path: Path):
        self.base = base
        self.teacher = np.load(target_path, mmap_mode="r")
        if len(self.teacher) != len(base) or self.teacher.shape[1:] != (180, 2):
            raise ValueError(
                f"Teacher shape {self.teacher.shape} does not match dataset length {len(base)}"
            )

    def __len__(self):
        return len(self.base)

    def __getitem__(self, index):
        history, target, mmsi = self.base[index]
        teacher = torch.from_numpy(np.asarray(self.teacher[index], dtype=np.float32).copy())
        return history, target, mmsi, teacher


def main():
    args = parse_args()
    if args.no_tsk:
        args.variant = "no_tsk"
    seed_everything(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    split_caches = {}
    for split in ("train", "val", "test"):
        source = resolve_split_file(args.data_root, args.domain, split)
        split_caches[split] = build_cache(source, args.cache_dir / args.domain, args.force_cache)

    train_history = np.load(split_caches["train"] / "history.npy", mmap_mode="r")
    train_future = np.load(split_caches["train"] / "future.npy", mmap_mode="r")
    scaler_path = args.cache_dir / args.domain / "scaler.json"
    scaler = RobustTrajectoryScaler.fit(
        train_history,
        train_future,
        isotropic_position=not args.anisotropic_position_scale,
    )
    scaler.save(scaler_path)

    datasets = {
        split: EnvShipDataset(path, scaler) for split, path in split_caches.items()
    }
    train_sample_weights = None
    if args.difficulty_sampling_strength > 0.0:
        train_dataset = datasets["train"]
        history = np.asarray(train_dataset.history[..., :2], dtype=np.float32)
        future = np.asarray(train_dataset.future, dtype=np.float32)
        recent_velocity = np.diff(history[:, -6:], axis=1).mean(axis=1)
        steps = np.arange(1, future.shape[1] + 1, dtype=np.float32)[None, :, None]
        cv_future = history[:, -1:, :] + steps * recent_velocity[:, None, :]
        deviation = np.linalg.norm(future - cv_future, axis=-1).mean(axis=1)
        velocity = np.diff(future, axis=1)
        v0, v1 = velocity[:, :-1], velocity[:, 1:]
        cross = v0[..., 0] * v1[..., 1] - v0[..., 1] * v1[..., 0]
        dot = (v0 * v1).sum(axis=-1)
        turn = np.abs(np.arctan2(cross, dot)).mean(axis=1)
        acceleration = np.linalg.norm(np.diff(velocity, axis=1), axis=-1).mean(axis=1)
        speed = np.linalg.norm(velocity, axis=-1).mean(axis=1)
        speed_change = acceleration / np.maximum(speed, 1e-6)

        def percentile_rank(values: np.ndarray) -> np.ndarray:
            order = np.argsort(values, kind="stable")
            ranks = np.empty_like(order, dtype=np.float32)
            ranks[order] = np.linspace(0.0, 1.0, len(values), dtype=np.float32)
            return ranks

        difficulty = (
            0.50 * percentile_rank(deviation)
            + 0.25 * percentile_rank(turn)
            + 0.25 * percentile_rank(speed_change)
        )
        train_sample_weights = 1.0 + 2.0 * args.difficulty_sampling_strength * np.square(difficulty)
        train_sample_weights /= train_sample_weights.mean()
        print(json.dumps({
            "difficulty_sampling": {
                "strength": args.difficulty_sampling_strength,
                "weight_min": float(train_sample_weights.min()),
                "weight_mean": float(train_sample_weights.mean()),
                "weight_max": float(train_sample_weights.max()),
                "difficulty_q90": float(np.quantile(difficulty, 0.90)),
            }
        }), flush=True)
    if args.distillation_weight < 0.0:
        raise ValueError("distillation-weight must be non-negative")
    if args.distillation_weight > 0.0:
        if args.distillation_target is None or not args.distillation_target.exists():
            raise FileNotFoundError(f"Distillation target missing: {args.distillation_target}")
        datasets["train"] = DistillationDataset(datasets["train"], args.distillation_target)
    if args.quick_smoke:
        args.epochs = min(args.epochs, 2)
        args.patience = 2
        datasets = {
            name: Subset(dataset, range(min(len(dataset), size)))
            for (name, dataset), size in zip(datasets.items(), (1024, 512, 512))
        }
        if train_sample_weights is not None:
            train_sample_weights = train_sample_weights[: len(datasets["train"])]

    train_sampler = None
    if train_sample_weights is not None:
        generator = torch.Generator().manual_seed(args.seed)
        train_sampler = WeightedRandomSampler(
            torch.as_tensor(train_sample_weights, dtype=torch.double),
            num_samples=len(datasets["train"]),
            replacement=True,
            generator=generator,
        )

    loaders = {
        name: DataLoader(
            dataset,
            batch_size=args.batch_size,
            shuffle=name == "train" and train_sampler is None,
            sampler=train_sampler if name == "train" else None,
            num_workers=args.num_workers,
            pin_memory=device.type == "cuda",
            persistent_workers=args.num_workers > 0,
        )
        for name, dataset in datasets.items()
    }
    initialization = None
    if args.model == "unified_internal_moe":
        model = UnifiedInternalMoE().to(device)
        initialization = model.load_staged_experts(
            args.unified_study_root,
            args.unified_diagnostic_root,
            args.domain,
            args.seed,
        )
        model.to(device)
    elif args.model == "slim_long_moe":
        model = SlimLongHorizonMoE(
            v6_variant=args.v6_variant,
            component_ablation=args.component_ablation,
            release_scale=args.heterogeneous_release_scale,
        ).to(device)
    elif args.model == "heterogeneous_single_moe":
        model = HeterogeneousSingleMoE(
            v6_variant=args.v6_variant,
            component_ablation=args.component_ablation,
            internal_variant=args.heterogeneous_variant,
        ).to(device)
    elif args.model == "intent_multiscale_moe":
        model = IntentMultiScaleMoE(
            v6_variant=args.v6_variant,
            component_ablation=args.component_ablation,
            router_temperature_override=args.router_temperature_override,
        ).to(device)
    elif args.model == "adaptive_moe":
        model = AdaptiveHorizonMoE(variant=args.adaptive_variant).to(device)
    else:
        model = AMFResLSTM(
            accel_clip=args.accel_clip,
            accel_tau=args.accel_tau,
            use_tsk=args.variant == "with_tsk",
            variant=args.variant,
        ).to(device)
    if args.model == "amf_reslstm":
        expected_parameters = 270_764 if args.variant == "with_tsk" else 269_324
        if model.parameter_count != expected_parameters:
            raise RuntimeError(f"Unexpected parameter count: {model.parameter_count}")
    if args.model == "adaptive_moe" and model.parameter_count != 284_585:
        raise RuntimeError(f"Unexpected parameter count: {model.parameter_count}")
    if args.init_checkpoint is not None:
        if not args.init_checkpoint.exists():
            raise FileNotFoundError(f"Initialization checkpoint not found: {args.init_checkpoint}")
        state = torch.load(args.init_checkpoint, map_location="cpu", weights_only=False)["model"]
        compatible = {
            key: value
            for key, value in state.items()
            if key in model.state_dict() and model.state_dict()[key].shape == value.shape
        }
        missing, unexpected = model.load_state_dict(compatible, strict=False)
        initialization = {
            "checkpoint": str(args.init_checkpoint.resolve()),
            "loaded_tensors": len(compatible),
            "missing_tensors": list(missing),
            "unexpected_tensors": list(unexpected),
        }

    run_dir = args.output_dir / args.domain / f"seed_{args.seed}"
    run_dir.mkdir(parents=True, exist_ok=True)
    effective_coverage_weight = args.coverage_weight
    if args.model == "amf_reslstm" and args.variant != "with_tsk":
        effective_coverage_weight = 0.0
    if args.model == "adaptive_moe" and args.adaptive_variant == "uniform_router":
        effective_coverage_weight = 0.0
    config = vars(args).copy()
    config.update(
        {
            "data_root": str(args.data_root.resolve()),
            "cache_dir": str(args.cache_dir.resolve()),
            "output_dir": str(args.output_dir.resolve()),
            "init_checkpoint": (
                str(args.init_checkpoint.resolve())
                if args.init_checkpoint is not None
                else None
            ),
            "distillation_target": (
                str(args.distillation_target.resolve())
                if args.distillation_target is not None
                else None
            ),
            "unified_study_root": str(args.unified_study_root.resolve()),
            "unified_diagnostic_root": str(args.unified_diagnostic_root.resolve()),
            "device": str(device),
            "parameter_count": model.parameter_count,
            "effective_coverage_weight": effective_coverage_weight,
            "initialization": initialization,
            "scaler": scaler.__dict__,
        }
    )
    (run_dir / "config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"run_dir": str(run_dir), "device": str(device), "parameters": model.parameter_count}), flush=True)
    train_model(
        model,
        loaders["train"],
        loaders["val"],
        loaders["test"],
        scaler,
        device,
        run_dir,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        min_learning_rate=args.min_learning_rate,
        patience=args.patience,
        max_training_seconds=args.max_training_seconds,
        coverage_weight=effective_coverage_weight,
        velocity_weight=args.velocity_weight,
        acceleration_weight=args.acceleration_weight,
        heading_weight=args.heading_weight,
        anchor_weight=args.anchor_weight,
        tail_weight=args.tail_weight,
        intent_weight=args.intent_weight,
        alignment_weight=args.alignment_weight,
        curvature_weight=args.curvature_weight,
        distillation_weight=args.distillation_weight,
        heterogeneous_expert_weight=(
            args.heterogeneous_expert_weight
            if args.model in ("heterogeneous_single_moe", "slim_long_moe", "unified_internal_moe") else 0.0
        ),
        heterogeneous_router_weight=(
            args.heterogeneous_router_weight
            if args.model in ("heterogeneous_single_moe", "slim_long_moe", "unified_internal_moe") else 0.0
        ),
        ema_decay=args.ema_decay,
        selection_score=args.selection_score,
        resume=args.resume,
        protect_initial_validation=args.protect_initial_validation,
    )


if __name__ == "__main__":
    main()
