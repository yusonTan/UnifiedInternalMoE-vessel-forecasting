"""Fresh-run equations match Direct-GRU; only the recurrent width is enlarged."""
from __future__ import annotations
import argparse
import json
import math
import os
import time
import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from comparison_models import DirectRNN
from amf.data import EnvShipDataset, RobustTrajectoryScaler
from amf.metrics import weighted_huber, displacement_metrics
from amf.trainer import seed_everything
from revision_followup16_training import snapshot_rng, restore_rng
import capacity_match_common as c


def save(payload, path):
    temporary = path.with_suffix('.tmp.pt'); torch.save(payload, temporary); os.replace(temporary, path)


@torch.inference_mode()
def evaluate(model, loader, scaler, device):
    model.eval(); pp, yy, ii = [], [], []
    for x, y, ids in loader:
        pred = model(x.to(device, non_blocking=True))
        pp.append(pred.cpu().numpy()); yy.append(y.numpy()); ii.append(ids.numpy())
    p = scaler.inverse_positions(np.concatenate(pp)).astype(np.float32)
    y = scaler.inverse_positions(np.concatenate(yy)).astype(np.float32)
    if not np.isfinite(p).all(): raise RuntimeError('Nonfinite validation/test predictions')
    return {'prediction': p, 'target': y, 'mmsi': np.concatenate(ii), 'window_index': np.arange(len(y))}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--domain', choices=c.DOMAINS, required=True)
    parser.add_argument('--seed', type=int, required=True); parser.add_argument('--output', type=str)
    parser.add_argument('--smoke', action='store_true'); parser.add_argument('--resume', action='store_true')
    parser.add_argument('--stop-after-epoch', type=int, default=0)
    args = parser.parse_args()
    if args.stop_after_epoch and not args.smoke: raise RuntimeError('Manual truncation is a smoke-only test feature')
    torch.set_num_threads(4); torch.set_num_interop_threads(2); seed_everything(args.seed)
    if not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable; no CPU fallback')
    device = torch.device('cuda'); c.check_frozen()
    folder = c.Path(args.output) if args.output else c.run(args.domain, args.seed)
    folder.mkdir(parents=True, exist_ok=True)
    cfg = c.config(args.domain, args.seed, args.smoke)
    if (folder/'config.json').exists() and c.read(folder/'config.json') != cfg:
        raise RuntimeError('Resume configuration drift')
    c.atomic_json(folder/'config.json', cfg)
    if c.completed(folder, deep=True):
        print('Already complete', flush=True); return
    scaler = RobustTrajectoryScaler(**cfg['scaler'])
    datasets = {s: EnvShipDataset(c.ROOT/'cache'/args.domain/f'{args.domain}_{s}', scaler) for s in ('train','val','test')}
    if args.smoke:
        datasets = {s: Subset(ds, range(min(len(ds), n))) for (s,ds),n in zip(datasets.items(), (1024,512,512))}
    loaders = {s: DataLoader(ds, batch_size=256, shuffle=s=='train', num_workers=0, pin_memory=True)
               for s,ds in datasets.items()}
    model = DirectRNN('gru', hidden=c.HIDDEN).to(device)
    if sum(p.numel() for p in model.parameters()) != cfg['parameter_count']: raise RuntimeError('Parameter-count mismatch')
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg['learning_rate'], weight_decay=cfg['weight_decay'])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg['epochs'], eta_min=cfg['minimum_learning_rate'])
    amp = torch.amp.GradScaler('cuda', enabled=True)
    start, best_score, stale, elapsed_before, records = 1, float('inf'), 0, 0., []
    last, best = folder/'last.pt', folder/'best.pt'
    if last.exists():
        if not args.resume: raise RuntimeError('Existing unfinished checkpoint requires explicit resume')
        state = torch.load(last, map_location=device, weights_only=False)
        if state['config'] != cfg: raise RuntimeError('Last-checkpoint configuration mismatch')
        model.load_state_dict(state['model']); optimizer.load_state_dict(state['optimizer'])
        scheduler.load_state_dict(state['scheduler']); amp.load_state_dict(state['amp'])
        start, best_score, stale = state['epoch']+1, state['best_score'], state['stale']
        elapsed_before, records = state['elapsed_seconds'], state['records']
        restore_rng(state['rng'])
        print(json.dumps({'resume_epoch': start, 'restored': ['RNG','AMP','model','optimizer','scheduler']}), flush=True)
        del state
    elif args.resume: raise RuntimeError('Requested resume checkpoint does not exist')
    active = time.perf_counter()
    print(json.dumps({'domain': args.domain, 'seed': args.seed, 'parameters': cfg['parameter_count'],
        'training_windows': len(datasets['train']), 'device': str(device), 'smoke': args.smoke}), flush=True)
    if stale >= cfg['patience']: start = cfg['epochs']+1
    for epoch in range(start, cfg['epochs']+1):
        epoch_start = time.perf_counter(); model.train(); loss_sum, count = 0., 0
        for x, y, _ in loaders['train']:
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast('cuda'):
                prediction = model(x); loss = weighted_huber(prediction, y)
            if not torch.isfinite(loss): raise RuntimeError('Nonfinite training loss; no hyperparameter rescue')
            amp.scale(loss).backward(); amp.unscale_(optimizer)
            # GradScaler retains the original comparator's overflow/skip behavior.
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
            amp.step(optimizer); amp.update(); loss_sum += float(loss.detach())*len(x); count += len(x)
        val = evaluate(model, loaders['val'], scaler, device)
        metrics = displacement_metrics(val['prediction'], val['target'])
        value = metrics['ADE@60']+2*metrics['ADE@10']
        improved = value < best_score-1e-6
        if improved:
            best_score, stale = value, 0
            save({'model': model.state_dict(), 'epoch': epoch, 'score': value, 'config': cfg}, best)
        else: stale += 1
        scheduler.step()
        row = {'epoch': epoch, 'train_loss': loss_sum/max(count,1), 'validation_score': value,
            'best_score': best_score, 'stale': stale, 'lr': optimizer.param_groups[0]['lr'],
            'seconds': time.perf_counter()-epoch_start, 'validation_improved': improved,
            **{f'val_{k}':v for k,v in metrics.items()}}
        records.append(row)
        save({'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(),
            'amp': amp.state_dict(), 'rng': snapshot_rng(), 'epoch': epoch, 'best_score': best_score,
            'stale': stale, 'records': records, 'config': cfg,
            'elapsed_seconds': elapsed_before+time.perf_counter()-active}, last)
        c.atomic_json(folder/'TRAINING_CURVE.json', records)
        print(json.dumps(row), flush=True)
        if args.stop_after_epoch and epoch >= args.stop_after_epoch:
            print('Intentional smoke interruption after saved epoch', flush=True); return
        if stale >= cfg['patience']: break
    elapsed = elapsed_before+time.perf_counter()-active
    payload = torch.load(best, map_location=device, weights_only=False); model.load_state_dict(payload['model'])
    outputs = {}; evaluations = {}
    for split in ('val','test'):
        z = evaluate(model, loaders[split], scaler, device); outputs[split] = z
        c.archive(folder/(split+'_predictions.npz'), **z)
        evaluations[split] = displacement_metrics(z['prediction'], z['target'])
    result = {'model': 'Wide-GRU', 'domain': args.domain, 'seed': args.seed,
        'selected_epoch': int(payload['epoch']), 'completed_epochs': records[-1]['epoch'],
        'validation_score': float(payload['score']), 'validation': evaluations['val'], 'test': evaluations['test'],
        'parameter_count': cfg['parameter_count'], 'training_seconds': elapsed,
        'stopped_by_patience': stale >= cfg['patience'], 'hit_epoch_limit': records[-1]['epoch']==cfg['epochs'],
        'last_epoch_improved': records[-1]['validation_improved'],
        'tail_training_loss_slope_per_epoch': float(np.polyfit(np.arange(min(10,len(records))),
            [r['train_loss'] for r in records[-10:]],1)[0]) if len(records)>1 else None,
        'test_used_for_selection': False, 'smoke': args.smoke,
        'peak_training_GPU_allocated_MiB': torch.cuda.max_memory_allocated()/2**20}
    c.atomic_json(folder/'result.json', result)
    torch.save(snapshot_rng(), folder/'final_rng.pt')
    names = ('best.pt','config.json','result.json','val_predictions.npz','test_predictions.npz','TRAINING_CURVE.json','final_rng.pt')
    c.atomic_json(folder/'COMPLETE.json', {'complete': True, 'files': {n:c.sha(folder/n) for n in names}})
    print(json.dumps({'training_complete': True, 'epoch': result['completed_epochs']}), flush=True)


if __name__ == '__main__': main()
