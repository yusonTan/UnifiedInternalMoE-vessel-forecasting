"""Isolated Finnish AIS external validation: provenance and safe HTTP ranges."""
from __future__ import annotations
import hashlib
import json
import os
import shutil
import struct
import time
import urllib.error
import urllib.request
from pathlib import Path
import numpy as np
from run_plos_rigor_suite import atomic_json
from run_revision_10seed import sha, FileLock

ROOT=Path(__file__).resolve().parent
OUT=Path('E:/OE_independent_AIS_20261016')
ARCHIVE_URL='https://zenodo.org/records/8112336/files/AIS_Dataset.zip?download=1'
ARCHIVE_BYTES=43556570046
SOURCE_DOI='10.5281/zenodo.8112336'
SEEDS=(42,52,62,72,82)
BACKBONES=('sa_repair','transformer_cv','itransformer_fa_faithful','mstformer_faithful','direct_gru','direct_lstm','tcn_cv')
EXPERTS=BACKBONES[:5]
DOMAINS=('dma','noaa','norway','piraeus')
METRICS=tuple(f'{k}@{h}' for h in (5,10,20,30,45,60) for k in ('ADE','FDE'))

def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def emit(event,**kw):
    OUT.mkdir(parents=True,exist_ok=True);r={'time':time.strftime('%Y-%m-%d %H:%M:%S'),'event':event,**kw}
    with (OUT/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    atomic_json(OUT/'STATUS.json',r);print(json.dumps(r,ensure_ascii=False),flush=True)

def archive(p,**a):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp.npz');np.savez_compressed(tmp,**a);os.replace(tmp,p)

def free_space(minimum=3*2**30):
    if shutil.disk_usage(OUT).free<minimum:raise RuntimeError('E free space below reserve; preserve state and stop')

def request_range(first,last):
    if not 0<=first<=last<ARCHIVE_BYTES:raise ValueError('Range outside published archive')
    req=urllib.request.Request(ARCHIVE_URL,headers={'Range':f'bytes={first}-{last}','Accept-Encoding':'identity','User-Agent':'OE-academic-AIS-validation/1.0'})
    response=urllib.request.urlopen(req,timeout=40)
    wanted=f'bytes {first}-{last}/{ARCHIVE_BYTES}'
    if response.status!=206 or response.headers.get('Content-Range')!=wanted:
        response.close();raise RuntimeError('Public download did not honor exact Range; full archive fetch refused')
    return response

def range_bytes(first,last,tag):
    folder=OUT/'raw_ranges';folder.mkdir(parents=True,exist_ok=True);p=folder/(tag+'.bin');meta=p.with_suffix('.json')
    if p.exists() and meta.exists():
        r=read(meta)
        if r['first']!=first or r['last']!=last or sha(p)!=r['sha256']:raise RuntimeError('Range cache mismatch')
        return p.read_bytes()
    for attempt in (1,2,3):
        try:
            with request_range(first,last) as r:body=r.read(last-first+2);headers=dict(r.headers)
            if len(body)!=last-first+1:raise RuntimeError('Short archive range')
            tmp=p.with_suffix('.tmp');tmp.write_bytes(body);os.replace(tmp,p)
            atomic_json(meta,{'url':ARCHIVE_URL,'first':first,'last':last,'sha256':sha(p),'headers':headers,'attempt':attempt})
            return body
        except urllib.error.HTTPError as e:
            if e.code in (401,403):raise
            if attempt==3:raise
        except Exception as e:
            emit('range_retry',tag=tag,attempt=attempt,error=str(e))
            if attempt==3:raise
        time.sleep(attempt*2)

def zip_directory():
    """Parse preserved ZIP64 central directory without swallowing HTTP errors."""
    tail=range_bytes(ARCHIVE_BYTES-65536,ARCHIVE_BYTES-1,'tail_65536')
    eocd=tail.rfind(b'PK\x05\x06')
    if eocd<0:raise RuntimeError('Archive EOCD absent in verified remote tail')
    _,_,_,n1,n2,size,offset,comment=struct.unpack_from('<4s4H2IH',tail,eocd)
    if offset==0xffffffff or size==0xffffffff or n2==65535:
        locator=tail.rfind(b'PK\x06\x07',0,eocd)
        if locator<0:raise RuntimeError('ZIP64 locator missing')
        _,disk,record_offset,total_disks=struct.unpack_from('<4sIQI',tail,locator)
        relative=record_offset-(ARCHIVE_BYTES-65536)
        z64=tail[relative:relative+56] if 0<=relative<len(tail)-55 else range_bytes(record_offset,record_offset+55,'zip64_record')
        fields=struct.unpack_from('<4sQ2H2I4Q',z64)
        n2,size,offset=fields[7],fields[8],fields[9]
    if size>2**20:raise RuntimeError('Unexpected central directory over 1 MiB')
    central=range_bytes(offset,offset+size-1,'central_directory');items=[];pos=0
    while pos<len(central):
        fields=struct.unpack_from('<4s6H3I5H2I',central,pos)
        if fields[0]!=b'PK\x01\x02':raise RuntimeError('Bad central-directory signature')
        comp,crc,cs,us=fields[4],fields[7],fields[8],fields[9]
        nl,xl,cl=fields[10:13];off=fields[16]
        name=central[pos+46:pos+46+nl].decode('utf-8');extra=central[pos+46+nl:pos+46+nl+xl]
        ep=0
        while ep+4<=len(extra):
            kind,length=struct.unpack_from('<HH',extra,ep);payload=extra[ep+4:ep+4+length];ep+=4+length
            if kind==1:
                cursor=0
                if us==0xffffffff:us=struct.unpack_from('<Q',payload,cursor)[0];cursor+=8
                if cs==0xffffffff:cs=struct.unpack_from('<Q',payload,cursor)[0];cursor+=8
                if off==0xffffffff:off=struct.unpack_from('<Q',payload,cursor)[0]
        items.append({'name':name,'compression':comp,'CRC32':crc,'compressed_bytes':cs,'uncompressed_bytes':us,'local_header_offset':off})
        pos+=46+nl+xl+cl
    if len(items)!=n2:raise RuntimeError('ZIP member count mismatch')
    atomic_json(OUT/'ARCHIVE_DIRECTORY.json',{'url':ARCHIVE_URL,'archive_bytes':ARCHIVE_BYTES,'entries':items,'n_entries':len(items)})
    return items

def member_start(member):
    offset=member['local_header_offset'];h=range_bytes(offset,offset+4095,'header_'+str(offset))
    if h[:4]!=b'PK\x03\x04':raise RuntimeError('Invalid local member header')
    nl,xl=struct.unpack_from('<HH',h,26)
    return offset+30+nl+xl

def download_member(member):
    import zlib
    folder=OUT/'raw';folder.mkdir(parents=True,exist_ok=True)
    p=folder/Path(member['name']).name;compressed=p.with_suffix('.deflate');marker=p.with_suffix('.receipt.json')
    if marker.exists():
        r=read(marker)
        raw=Path(r['raw_path'])
        if sha(raw)!=r['raw_sha256']:raise RuntimeError('Downloaded raw source changed')
        return raw
    if member['compression']!=8:raise RuntimeError('Only verified DEFLATE members supported')
    if member['compressed_bytes']>600*2**20:raise RuntimeError('Single daily member exceeds 600 MiB acquisition cap')
    start=member_start(member);total=member['compressed_bytes'];have=compressed.stat().st_size if compressed.exists() else 0
    if have>total:raise RuntimeError('Partial download longer than source member')
    last_log=time.monotonic()
    while have<total:
        stop=min(have+2**20,total)
        for attempt in (1,2,3):
            try:
                with request_range(start+have,start+stop-1) as response,compressed.open('ab') as output:
                    while have<stop:
                        block=response.read(min(65536,stop-have))
                        if not block:raise IOError('Truncated member transfer')
                        output.write(block);have+=len(block)
                if have!=stop:raise RuntimeError('Download size mismatch')
                break
            except urllib.error.HTTPError as e:
                if e.code in (401,403) or attempt==3:raise
            except Exception as e:
                emit('raw_member_retry',member=member['name'],attempt=attempt,error=str(e));have=compressed.stat().st_size
                if attempt==3:raise
            time.sleep(attempt*2)
        if time.monotonic()-last_log>20:
            free_space();emit('raw_download_progress',member=member['name'],bytes=have,total_bytes=total);last_log=time.monotonic()
    # Preserve the original downloaded compressed bytes and a gzip text copy.
    # CSV conversion is a derived artefact; CRC is checked against ZIP metadata.
    import gzip
    destination=p.with_suffix(p.suffix+'.gz');tmp=destination.with_suffix('.tmp.gz');crc=0;count=0
    d=zlib.decompressobj(-15)
    with compressed.open('rb') as f,gzip.open(tmp,'wb',compresslevel=3) as out:
        for block in iter(lambda:f.read(2**20),b''):
            b=d.decompress(block);crc=zlib.crc32(b,crc);count+=len(b);out.write(b)
        b=d.flush();crc=zlib.crc32(b,crc);count+=len(b);out.write(b)
    if not d.eof or count!=member['uncompressed_bytes'] or crc!=member['CRC32']:raise RuntimeError('Member CRC/decompression verification failed')
    os.replace(tmp,destination)
    # No uncompressed daily CSV is created.
    raw_sha=sha(destination)
    atomic_json(marker,{'source_DOI':SOURCE_DOI,'source_url':ARCHIVE_URL,'member':member,'compressed_sha256':sha(compressed),
        'raw_sha256':raw_sha,'raw_path':str(destination),'gzip_is_reencoded_source_bytes':True,'CRC32_verified':True})
    return destination
