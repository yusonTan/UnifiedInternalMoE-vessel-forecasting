"""Detached, resumable queue: feasibility screen -> CV15 -> transfer -> tables."""
from __future__ import annotations
import argparse
import ctypes
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
import torch
import revision_extension_common as c

NODE=Path('C:/Users/29146/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')

def freeze(files,p):
    p=Path(p)
    if not p.exists():raise FileNotFoundError(p)
    if str(p) not in files:
        s=p.stat();files[str(p)]={'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':c.sha(p)}

def preflight():
    if (c.OUT/'PROTOCOL.json').exists():c.check_frozen();return
    files={};caches={}
    inherited=c.read(c.MAIN/'PROTOCOL.json')['code_sha256']
    for name,digest in inherited.items():
        if c.sha(c.ROOT/name)!=digest:raise RuntimeError('Historical code changed since ten-seed campaign: '+name)
        freeze(files,c.ROOT/name)
    for domain in c.DOMAINS:
        sets={}
        for split in ('train','val','test'):
            hx,fy,ids=c.data(domain,split);sets[split]=set(ids.tolist())
            if hx.shape!=(len(ids),90,6) or fy.shape!=(len(ids),180,2):raise RuntimeError('Data shape mismatch')
            for name in ('history','future','mmsi'):freeze(files,c.ROOT/'cache'/domain/f'{domain}_{split}'/(name+'.npy'))
            freeze(files,c.ROOT.parent/'data'/domain/split/'part-000.csv.gz')
        if any(sets[a]&sets[b] for a,b in (('train','val'),('train','test'),('val','test'))):raise RuntimeError('MMSI split leakage')
        freeze(files,c.ROOT/'cache'/domain/'scaler.json')
        for seed in c.SEEDS:
            for model in c.BACKBONES:
                run=c.run_of(model,domain,seed)
                for name in ('best.pt','config.json'):freeze(files,run/name)
                p=c.prediction_path(model,domain,seed);caches[f'{model}/{domain}/{seed}']=str(p);freeze(files,p)
            folder=c.MAIN/'fusion_10seed_refit'/domain/f'seed_{seed}'
            for name in ('best.pt','config.json','val_predictions.npz','test_predictions.npz'):freeze(files,folder/name)
    if shutil.disk_usage(c.OUT).free<4*2**30:raise RuntimeError('Need at least 4 GiB free on E before start')
    c.atomic_json(c.OUT/'PROTOCOL.json',{'created_at':time.strftime('%Y-%m-%d %H:%M:%S'),
        'domains':c.DOMAINS,'seeds':c.SEEDS,'transfer_models':c.MODELS,'external_audit_only':True,
        'CV15_floor':{'betas':c.BETAS,'ridges':c.RIDGES,'anchors_minutes':[5,10,60],
            'floor_at_all_anchors':True,'expert_candidates':'fixed all5 vs fixed all5+rawCV15',
            'inner_MMSI_folds':3,'outer_MMSI_folds':3,'selection_J':'mean inner J + 0.25 population SD',
            'J':'(ADE5/20 + ADE10/50 + 2*ADE60/600)/4','short_specialist_override':False},
        'selection':'validation only; beta/ridge/weights locked before test loading; no target calibration in transfer',
        'test_history_limitation':'Existing EnvShip test data observed historically; this is not new external validation',
        'storage':'All-window error arrays and deterministic first8 trajectories; full prediction replay via frozen code/cache/checkpoints',
        'frozen_files':files,'prediction_caches':caches,'code_hashes':{n:c.sha(c.ROOT/n) for n in c.CODE},
        'inherited_source_hashes':inherited,'statistical_SD':'sample ddof1; CV15 deterministic reference',
        'original_model_never_replaced_using_test_scores':True})
    c.emit('preflight_complete',frozen_files=len(files),protection_runs=40,source_seed_transfer_units=40)

def execute(command,label,logpath):
    command=list(map(str,command));logpath=Path(logpath);logpath.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(c.OUT).free<3*2**30:raise RuntimeError('E free space below 3 GiB; preserve outputs and stop')
    for attempt in (1,2):
        with logpath.open('a',encoding='utf-8') as f:
            p=subprocess.Popen(command,cwd=c.ROOT,stdout=f,stderr=subprocess.STDOUT,
                env={**os.environ,'PYTHONUTF8':'1','PYTHONUNBUFFERED':'1'})
            c.atomic_json(c.OUT/'CHILD.json',{'pid':p.pid,'label':label,'command':command,'attempt':attempt})
            c.emit('task_started',label=label,pid=p.pid,attempt=attempt);rc=p.wait()
        c.emit('task_exit',label=label,exit_code=rc,attempt=attempt)
        if rc==0:return
        if attempt==1:c.emit('retry_same_configuration',label=label)
    raise RuntimeError('Task failed twice: '+label)

def worker(phase,domain,seed,smoke=False):
    return [sys.executable,'-u',c.ROOT/'revision_cv_transfer.py',phase,'--domain',domain,'--seed',str(seed),*(['--smoke'] if smoke else [])]

def estimate():
    records={p:[] for p in ('protection','transfer')};pending={p:[] for p in records}
    for p in records:
        for domain in c.DOMAINS:
            for seed in c.SEEDS:
                f=c.OUT/p/domain/f'seed_{seed}'
                if c.complete(f):records[p].append((domain,c.read(f/'RESULT.json')['seconds']))
                else:pending[p].append(domain)
    remaining=0.
    for p in records:
        for domain in pending[p]:
            same=[t for d,t in records[p] if d==domain]
            fallback=[t for _,t in records[p]]
            # Pre-benchmark provisional seconds; refine as each domain completes.
            seconds=sum(same)/len(same) if same else (sum(fallback)/len(fallback) if fallback else (360 if p=='protection' else 90))
            if p=='protection' and not same and domain in ('dma','noaa'):seconds=max(seconds,300)
            remaining+=seconds+5
    remaining+=900 # final paired statistics, figures, verification and input SHA audit
    c.atomic_json(c.OUT/'ETA.json',{'updated_at':time.strftime('%Y-%m-%d %H:%M:%S'),
        'completed_units':{k:len(v) for k,v in records.items()},'pending_units':{k:len(v) for k,v in pending.items()},
        'remaining_hours_central':remaining/3600,'remaining_hours_range':[remaining*.75/3600,remaining*1.5/3600],
        'central_finish_local':time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()+remaining)),
        'domain_timings_seconds':records,'is_estimate_not_deadline':True})

def main():
    a=argparse.ArgumentParser();a.add_argument('--preflight-only',action='store_true');a.add_argument('--smoke',action='store_true');a.add_argument('--benchmark-only',action='store_true');args=a.parse_args()
    c.OUT.mkdir(parents=True,exist_ok=True);lock=c.FileLock(c.OUT/'campaign.lock')
    if not lock.acquire():raise RuntimeError('Another queue already owns this output')
    if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        preflight()
        if args.preflight_only:return
        if not torch.cuda.is_available():raise RuntimeError('CUDA required, no CPU fallback')
        if args.smoke:
            execute(worker('protection','norway',42,True),'CV15_smoke',c.OUT/'smoke/protection.log')
            execute(worker('transfer','dma',42,True),'transfer_smoke',c.OUT/'smoke/transfer.log')
            c.atomic_json(c.OUT/'SMOKE_COMPLETE.json',{'complete':True,'CUDA':torch.cuda.get_device_name(),
                'protection_test_rows':16,'transfer_all8models':True,'not_formal_results':True});return
        if not (c.OUT/'SMOKE_COMPLETE.json').exists():raise RuntimeError('CUDA smoke tests must pass first')
        if not (c.OUT/'ACTIVATION.json').exists():c.atomic_json(c.OUT/'ACTIVATION.json',{'started_at':time.strftime('%Y-%m-%d %H:%M:%S')})
        audit=c.OUT/'external_feasibility/FEASIBILITY.json'
        if not audit.exists():execute([sys.executable,'-u',c.ROOT/'revision_external_feasibility.py'],'external_feasibility_screen',c.OUT/'external_feasibility.log')
        # Representative large-domain protection + a full source-seed transfer
        # benchmark are retained as formal results, not thrown-away pilot runs.
        units=[('protection','dma',42),('transfer','dma',42)]
        if not args.benchmark_only:
            units += [(p,d,s) for p in ('protection','transfer') for s in c.SEEDS for d in c.DOMAINS if (p,d,s) not in units]
        for phase,domain,seed in units:
            directory=c.OUT/phase/domain/f'seed_{seed}'
            if not c.complete(directory,True):execute(worker(phase,domain,seed),f'{phase}/{domain}/{seed}',directory/'terminal.log')
            if not c.complete(directory,True):raise RuntimeError('Worker exited without acceptance files')
            estimate()
        if args.benchmark_only:return
        c.atomic_json(c.OUT/'INFERENCE_COMPLETE.json',{'complete':True,'protection_units':40,'transfer_units':40})
        execute([sys.executable,'-u',c.ROOT/'revision_cv_transfer.py','summary'],'statistics_and_figures',c.OUT/'summary.log')
        execute([NODE,c.ROOT/'verify_cv_transfer_csv.mjs',c.OUT],'CSV_artifact_verification',c.OUT/'CSV_verification.log')
        c.check_frozen(deep=True)
        (c.OUT/'REPORT.md').write_text('# CV15 protection and ten-seed cross-region extension\n\n'
            'Four-region ten-seed nested CV15 floor sensitivity and 12-direction ten-seed source-only transfer for eight learning predictors are complete. '
            'The original fusion is preserved. No target-domain scaler/router fitting is used in transfer; source selection is not made using target test scores. '
            'CV15 is a deterministic reference, not ten independent training fits. Test history and shared-route uncertainty limitations remain.\n\n'
            'External AIS feasibility is separate: see external_feasibility/REPORT.md and FEASIBILITY.json. No independent external AIS experiment is claimed. '
            'Licence, raw-row units/cadence, MMSI overlap and 90-minute eligibility require actual raw-data verification. '
            'Full revision, manuscript integration and public reproducibility packaging are not marked complete.\n',encoding='utf-8')
        c.atomic_json(c.OUT/'COMPLETE.json',{'complete':True,'finished_at':time.strftime('%Y-%m-%d %H:%M:%S'),
            'CV15_protection_complete':True,'transfer_extension_complete':True,'external_AIS_validation_complete':False,
            'full_revision_complete':False})
        c.emit('campaign_complete')
    except Exception as exc:
        c.atomic_json(c.OUT/'FAILURE.json',{'time':time.strftime('%Y-%m-%d %H:%M:%S'),'reason':str(exc),'traceback':traceback.format_exc(),'resumable':True})
        c.emit('campaign_failed',reason=str(exc));raise
    finally:
        if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.release()

if __name__=='__main__':main()
