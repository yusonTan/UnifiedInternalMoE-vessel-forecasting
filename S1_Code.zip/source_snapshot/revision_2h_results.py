"""Validation-only fusion refitting and matched two-stage ablation reporting."""
from __future__ import annotations
import json
import time
from pathlib import Path
import numpy as np
import torch

import evaluate_compact_committee as compact
from amf.data import RobustTrajectoryScaler
from amf.metrics import displacement_metrics
from amf.unified_predictor import UnifiedInternalMoE
from run_plos_rigor_suite import atomic_json, write_csv
from revision_5h_analysis import jscore, route_blend
from run_revision_5h import archive, forward_final
from run_revision_2h import ROOT, OUT, DOMAINS, NEW_SEEDS, ALL_SEEDS, ABLATIONS, log, sha

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
EXPERTS = UnifiedInternalMoE.expert_order
COMPARATORS = ("direct_lstm", "direct_gru", "tcn_cv", "transformer_cv", "itransformer_fa_faithful", "mstformer_faithful", "sa_repair")


def check_deadline(deadline):
    if time.time() >= deadline:
        raise TimeoutError("Summary phase reached the two-hour campaign deadline")


def run_of(model, domain, seed):
    if model == "sa_repair":
        root = OUT / "SA_seed_repair" if seed in NEW_SEEDS else ROOT / "eight_hour_diagnostic" / "repairs" / "router_sharp150_cov_0p0"
        return root / domain / f"seed_{seed}"
    root = OUT / "comparisons" if seed in NEW_SEEDS else ROOT / "complete_3seed_4domain_study" / "comparisons"
    family = "faithful_sota" if "faithful" in model else "runs"
    return root / family / model / domain / f"seed_{seed}"


def data(domain, split):
    path = ROOT / "cache" / domain / f"{domain}_{split}"
    return tuple(np.load(path / f"{name}.npy", mmap_mode="r") for name in ("history", "future", "mmsi"))


@torch.inference_mode()
def collect(model_name, run, domain, seed, tag=None):
    destination = OUT / "predictions" / (tag or model_name) / domain / f"seed_{seed}.npz"
    checkpoint = run / "best.pt"
    checkpoint_sha = sha(checkpoint)
    if destination.exists():
        existing = np.load(destination)
        if str(existing["checkpoint_sha256"].item()) != checkpoint_sha:
            raise RuntimeError("Stale checkpoint prediction cache")
        return existing
    model = compact.build_model(model_name, run)
    model.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=False)["model"], strict=True)
    model.to(DEVICE).eval()
    config = json.loads((run / "config.json").read_text(encoding="utf-8"))
    scaler = RobustTrajectoryScaler(**config["scaler"]) if "scaler" in config else RobustTrajectoryScaler.load(ROOT / "cache" / domain / "scaler.json")
    saved = {"checkpoint_sha256": np.asarray(checkpoint_sha), "source_checkpoint": np.asarray(str(checkpoint))}
    for split in ("val", "test"):
        history, future, mmsi = data(domain, split)
        predictions = []
        for first in range(0, len(history), 16):
            x = torch.from_numpy(scaler.transform_history(np.asarray(history[first:first + 16])).copy()).to(DEVICE)
            predictions.append(scaler.inverse_positions(model(x).cpu().numpy()).astype(np.float32))
        saved[split + "_prediction"] = np.concatenate(predictions)
        saved[split + "_target"] = scaler.inverse_positions(scaler.transform_future(np.asarray(future))).astype(np.float32)
        saved[split + "_MMSI"] = np.asarray(mmsi)
        saved[split + "_window_index"] = np.arange(len(mmsi))
    archive(destination, **saved)
    del model
    torch.cuda.empty_cache()
    return np.load(destination)


def metric_row(domain, seed, model, protocol, prediction, target, validation, val_target, selected_epoch=None):
    return {"domain": domain, "seed": seed, "model": model, "protocol": protocol,
            "selected_epoch": selected_epoch, "validation_J": jscore(validation, val_target),
            "test_J": jscore(prediction, target), **displacement_metrics(prediction, target)}


def aggregate(rows, expected_seeds):
    result = []
    for domain in DOMAINS:
        for model, protocol in sorted({(r["model"], r["protocol"]) for r in rows if r["domain"] == domain}):
            selected = [r for r in rows if r["domain"] == domain and r["model"] == model and r["protocol"] == protocol]
            expected = (42, 52, 62) if protocol == "original_submission_reference_only" else expected_seeds
            row = {"domain": domain, "model": model, "protocol": protocol, "n_seeds": len(selected),
                   "all_expected_seeds_complete": set(r["seed"] for r in selected) == set(expected)}
            for metric in ("validation_J", "test_J", *[f"{kind}@{h}" for h in (5, 10, 20, 30, 45, 60) for kind in ("ADE", "FDE")]):
                v = np.asarray([r[metric] for r in selected])
                row[metric + "_mean"] = float(v.mean())
                row[metric + "_std"] = float(v.std(ddof=1)) if len(v) > 1 else None
            result.append(row)
    return result


def fit_fusion_group(records, seeds, domain):
    # Keep the self-contained model's five-expert pool. TCN remains a comparator,
    # not a sixth expert silently added to the architecture.
    saved_candidates = compact.CANDIDATES
    compact.CANDIDATES = EXPERTS
    fitted, selections = {}, {}
    try:
        for seed in seeds:
            loaded = records[seed]
            target = loaded["sa_repair"]["val_target"]
            ids = loaded["sa_repair"]["val_MMSI"]
            predictions = {name: loaded[name]["val_prediction"] for name in EXPERTS}
            for name in EXPERTS:
                if not np.array_equal(loaded[name]["val_MMSI"], ids):
                    raise RuntimeError("Fusion MMSI alignment failed")
                if np.abs(loaded[name]["val_target"] - target).max() > .05:
                    raise RuntimeError("Fusion target alignment failed")
            chosen, local, _, ranking = compact.choose_committee(predictions, target, ids, seed)
            full = np.zeros((3, 5))
            for j, name in enumerate(chosen["candidates"]):
                full[:, EXPERTS.index(name)] = local[:, j]
            fitted[seed] = full
            selections[seed] = {"selected": chosen, "ranking": ranking}
    finally:
        compact.CANDIDATES = saved_candidates
    scores = {}
    for option in (None, *EXPERTS):
        each = []
        for seed in seeds:
            weights = fitted[seed].copy()
            if option is not None:
                weights[:2] = 0
                weights[:2, EXPERTS.index(option)] = 1
            loaded = records[seed]
            candidates = np.stack([loaded[n]["val_prediction"] for n in EXPERTS], axis=1)
            each.append(4 * jscore(route_blend(candidates, {"steps": [15, 30, 180], "weights": weights}), loaded["sa_repair"]["val_target"]))
        scores["keep_committee" if option is None else option] = float(np.mean(each))
    specialist = min(EXPERTS, key=lambda n: scores[n])
    if scores[specialist] >= scores["keep_committee"] - 1e-5:
        specialist = None
    for seed in seeds:
        if specialist is not None:
            fitted[seed][:2] = 0
            fitted[seed][:2, EXPERTS.index(specialist)] = 1
    return fitted, {"domain": domain, "shared_validation_seeds": list(seeds), "selected_short_specialist": specialist,
                    "mean_validation_goal": scores, "per_seed_compact_selection": selections,
                    "candidate_pool": EXPERTS, "test_used_for_selection": False,
                    "route_selection_not_independent_across_seeds": True}


def summarize_seeds(deadline):
    torch.set_num_threads(4)
    rows, provenance = [], []
    for domain in DOMAINS:
        records = {}
        for seed in ALL_SEEDS:
            check_deadline(deadline)
            records[seed] = {}
            for name in COMPARATORS:
                run = run_of(name, domain, seed)
                z = collect(name, run, domain, seed)
                config = json.loads((run / "config.json").read_text(encoding="utf-8"))
                runtime = json.loads((run / "revision_runtime.json").read_text(encoding="utf-8")) if (run / "revision_runtime.json").exists() else {}
                if seed in NEW_SEEDS and "loader_workers" not in runtime:
                    runtime["loader_workers"] = 0 if "loader workers=0" in (run / "terminal.log").read_text(encoding="utf-8", errors="replace") else 2
                state = torch.load(run / "best.pt", map_location="cpu", weights_only=False)
                rows.append(metric_row(domain, seed, name, "original_architecture_model_specific_training", z["test_prediction"],
                                       z["test_target"], z["val_prediction"], z["val_target"], int(state["epoch"])))
                provenance.append({"domain": domain, "seed": seed, "model": name, "source": str(run),
                                   "checkpoint_sha256": sha(run / "best.pt"), "new_independent_training": seed in NEW_SEEDS,
                                   "loader_workers": runtime.get("loader_workers", config.get("num_workers", "historical comparator uses workers=2")),
                                   "init_checkpoint": config.get("init_checkpoint"), "CPU_threads_new_jobs": 4 if seed in NEW_SEEDS else "historical"})
                records[seed][name] = z
            log("seed_predictions_collected", domain=domain, seed=seed)
        fitted, selection = fit_fusion_group(records, ALL_SEEDS, domain)
        directory = OUT / "fusion_5seed_refit" / domain
        atomic_json(directory / "VALIDATION_SELECTION_LOCK.json", selection)
        for seed in ALL_SEEDS:
            check_deadline(deadline)
            torch.manual_seed(seed)
            model = UnifiedInternalMoE()
            for name, module in zip(EXPERTS, model.expert_modules):
                module.load_state_dict(torch.load(run_of(name, domain, seed) / "best.pt", map_location="cpu", weights_only=False)["model"], strict=True)
            with torch.no_grad():
                model.global_route_logits.copy_(torch.log(torch.as_tensor(fitted[seed].T, dtype=torch.float32).clamp_min(1e-12)))
            model.to(DEVICE).eval()
            scaler = RobustTrajectoryScaler.load(ROOT / "cache" / domain / "scaler.json")
            run = directory / f"seed_{seed}"
            run.mkdir(parents=True, exist_ok=True)
            config = {"model": "unified_internal_moe", "domain": domain, "seed": seed, "scaler": scaler.__dict__,
                      "protocol": "all five seed routes refitted under common five-expert selection rule",
                      "short_specialist": selection["selected_short_specialist"], "knot_weights": fitted[seed],
                      "expert_checkpoints": {n: str(run_of(n, domain, seed) / "best.pt") for n in EXPERTS},
                      "route_choice_shared_across_five_seeds": True, "not_original_submission_route_version": True}
            atomic_json(run / "config.json", config)
            torch.save({"model": model.state_dict(), "epoch": 0, "scaler": scaler.__dict__, "protocol": config["protocol"]}, run / "best.pt")
            pp = {}
            for split in ("val", "test"):
                history, _, ids = data(domain, split)
                prediction, _ = forward_final(model, history, scaler, capture=False)
                target = records[seed]["sa_repair"][split + "_target"]
                candidates = np.stack([records[seed][n][split + "_prediction"] for n in EXPERTS], axis=1)
                reconstructed = route_blend(candidates, {"steps": [15, 30, 180], "weights": fitted[seed]})
                difference = float(np.abs(prediction - reconstructed).max())
                if difference > .05:
                    raise RuntimeError(f"Packed predictor replay mismatch {domain}/{seed}: {difference}")
                archive(run / f"{split}_predictions.npz", prediction=prediction, target=target, mmsi=np.asarray(ids), window_index=np.arange(len(ids)))
                pp[split] = prediction
            rows.append(metric_row(domain, seed, "UnifiedInternalMoE_5seed_refit", "five_seed_shared_validation_route_selection", pp["test"],
                                   records[seed]["sa_repair"]["test_target"], pp["val"], records[seed]["sa_repair"]["val_target"], 0))
            del model
            torch.cuda.empty_cache()
        # The original three-seed submission remains a separate reference, not
        # concatenated with newly routed seeds to masquerade as a homogeneous set.
        for seed in (42, 52, 62):
            zt = np.load(ROOT / "revision_5h_20261009" / "canonical" / domain / f"seed_{seed}" / "test.npz")
            zv = np.load(ROOT / "revision_5h_20261009" / "canonical" / domain / f"seed_{seed}" / "val.npz")
            rows.append(metric_row(domain, seed, "UnifiedInternalMoE_original3", "original_submission_reference_only", zt["prediction"],
                                   zt["target"], zv["prediction"], zv["target"], 0))
        write_csv(OUT / "two_domain_5seed_per_seed.csv", rows)
        write_csv(OUT / "training_provenance.csv", provenance)
    write_csv(OUT / "two_domain_5seed_mean_std.csv", aggregate(rows, ALL_SEEDS))
    atomic_json(OUT / "FIVE_SEED_COMPLETE.json", {"complete": True, "domains": DOMAINS, "seeds": ALL_SEEDS,
                "new_backbone_training_replications": 28, "new_SA_pretraining_plus_repair_runs": 8,
                "route_shared_selection_dependence": True, "four_domain_five_seed_complete": False,
                "runtime_change": "new jobs CPU threads=4; workers=0 after startup benchmark; historical jobs/initial benchmark used workers=2"})


def summarize_ablations():
    torch.set_num_threads(4)
    rows, missing, fusion_rows = [], [], []
    for domain in DOMAINS:
        for variant in ABLATIONS:
            loaded, records = {}, {}
            for seed in (42, 52, 62):
                run = OUT / "SA_matched" / variant / "repair" / domain / f"seed_{seed}"
                if not (run / "test_metrics.json").exists():
                    missing.append({"domain": domain, "seed": seed, "variant": variant})
                    continue
                z = collect("sa_repair", run, domain, seed, tag="SA_matched_" + variant)
                loaded[seed] = z
                rows.append(metric_row(domain, seed, variant, "matched_component_active_in_both_training_stages", z["test_prediction"],
                                       z["test_target"], z["val_prediction"], z["val_target"],
                                       int(torch.load(run / "best.pt", map_location="cpu", weights_only=False)["epoch"])))
                records[seed] = {"sa_repair": z}
                for name in EXPERTS[1:]:
                    records[seed][name] = collect(name, run_of(name, domain, seed), domain, seed)
            if len(records) == 3:
                weights, selection = fit_fusion_group(records, (42, 52, 62), domain)
                atomic_json(OUT / "SA_matched" / variant / domain / "fusion_selection.json", selection)
                for seed in (42, 52, 62):
                    p = {}
                    for split in ("val", "test"):
                        candidates = np.stack([records[seed][n][split + "_prediction"] for n in EXPERTS], axis=1)
                        p[split] = route_blend(candidates, {"steps": [15, 30, 180], "weights": weights[seed]})
                        archive(OUT / "SA_matched" / variant / domain / f"seed_{seed}" / f"fusion_{split}.npz",
                                prediction=p[split], target=loaded[seed][split + "_target"], mmsi=loaded[seed][split + "_MMSI"])
                    fusion_rows.append(metric_row(domain, seed, variant, "matched_fusion_with_retrained_SA_component_and_refitted_route",
                                                  p["test"], loaded[seed]["test_target"], p["val"], loaded[seed]["val_target"], 0))
    write_csv(OUT / "SA_internal_ablation_per_seed.csv", rows)
    write_csv(OUT / "SA_internal_ablation_mean_std.csv", aggregate(rows, (42, 52, 62)))
    write_csv(OUT / "fusion_SA_internal_ablation_per_seed.csv", fusion_rows)
    write_csv(OUT / "fusion_SA_internal_ablation_mean_std.csv", aggregate(fusion_rows, (42, 52, 62)))
    changes = []
    for family, values in (("SA_only", rows), ("whole_fusion", fusion_rows)):
        for domain in DOMAINS:
            for variant in ABLATIONS[1:]:
                pairs = [(next((r for r in values if r["domain"] == domain and r["seed"] == seed and r["model"] == "full"), None),
                          next((r for r in values if r["domain"] == domain and r["seed"] == seed and r["model"] == variant), None)) for seed in (42, 52, 62)]
                pairs = [(full, ablated) for full, ablated in pairs if full is not None and ablated is not None]
                if not pairs:
                    continue
                row = {"family": family, "domain": domain, "variant": variant, "matched_seed_pairs": len(pairs),
                       "all_three_pairs_complete": len(pairs) == 3}
                for metric in ("validation_J", "test_J", "ADE@5", "ADE@10", "ADE@60", "FDE@60"):
                    full = np.mean([r[0][metric] for r in pairs]); ablated = np.mean([r[1][metric] for r in pairs])
                    row[metric + "_relative_change_percent"] = 100 * (ablated - full) / full
                changes.append(row)
    write_csv(OUT / "SA_internal_ablation_paired_changes.csv", changes)
    atomic_json(OUT / "MATCHED_ABLATION_COMPLETE.json", {"complete": not missing, "missing": missing,
                "retrained_final_models": len(rows), "training_stages_per_model": 2,
                "temperature_pretraining": 1., "temperature_repair": 1.5,
                "removed_component_active_from_pretraining_start": True,
                "no_residual_definition": "gated dense and gated spline removed; separate intent head retained"})


def report():
    lines = ["# Two-hour revision experiment batch", "", "## Scope", "",
             "Norway and Piraeus only. This is not four-domain five-seed completion.",
             "New seed72/82 SA models use independent random pretraining and own-seed repair.",
             "Five-seed routes are refitted uniformly and reported separately from the original three-seed submission.",
             "Route specialist selection is shared across validation replications; fusion routing is not independently selected per seed.",
             "New jobs use four CPU threads and single-process cached-data loading after a startup benchmark; optimizer, loss, epoch caps and validation rules are unchanged.",
             "", "## Status", ""]
    for name in ("FIVE_SEED_COMPLETE.json", "MATCHED_ABLATION_COMPLETE.json"):
        path = OUT / name
        payload = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"complete": False}
        lines.append(f"- {name}: complete={payload['complete']}")
    lines += ["", "Internal ablations remove a component in both training stages, not just at inference.",
              "No-residual removes gated dense/spline corrections, not the separate intent endpoint head.",
              "Results need not favor the full architecture; no failed variants or unfavorable seed results are discarded.",
              "", "## Still pending", "", "DMA/NOAA extra seeds, other internal component ablations, an independent AIS source and a probabilistic comparator."]
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    atomic_json(OUT / "code_manifest.json", {str(path.relative_to(ROOT)): sha(path) for path in
                (ROOT / "run_revision_2h.py", ROOT / "revision_training_job.py", ROOT / "revision_2h_results.py",
                 ROOT / "amf" / "adaptive_moe.py", ROOT / "train.py", ROOT / "evaluate_compact_committee.py")})
