"""Complete the locked eight-variant, four-domain, five-seed internal ablation."""
from __future__ import annotations
import argparse
import ctypes
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
import numpy as np
import torch
import revision_all_routes_common as c
import run_revision_all_routes as previous
from run_revision_2h import set_arg

ROOT = Path(__file__).resolve().parent
OUT = Path('E:/OE_internal_full_20261014')
PRIOR = Path('E:/OE_all_routes_20261013')
FOLLOWUP = Path('E:/OE_revision16_20261010')
SMALL = ROOT / 'revision_2h_20261009'
VARIANTS = ('full', 'no_dca', 'no_residual', 'uniform_router',
            'single_scale', 'ungated_residual', 'no_spline', 'no_intent')
NEW_FILES = ('run_revision_internal_full.py', 'revision_internal_full_results.py',
             'verify_internal_full_csv.mjs', 'tests/test_revision_internal_full.py',
             'start_revision_internal_full.ps1', 'monitor_revision_internal_full.ps1')


def activate():
    c.OUT = OUT
    return c.configure_sa()


def plan():
    return [{'variant': v, 'domain': d, 'seed': s}
            for v in VARIANTS for s in c.FIVE for d in c.DOMAINS]


def key(item):
    return item['variant'], item['domain'], item['seed']


def candidates(item):
    v, d, s = key(item)
    for row in c.read(PRIOR / 'PROTOCOL.json')['SA_reuse']:
        if (row['variant'], row['domain'], row['seed']) == key(item):
            yield Path(row['pretraining']), Path(row['repair'])
    for base in (PRIOR, FOLLOWUP, SMALL):
        folder = base / 'SA_matched' / v
        yield folder / 'pretraining' / d / f'seed_{s}', folder / 'repair' / d / f'seed_{s}'
    if v == 'full' and d in ('norway', 'piraeus') and s in (72, 82):
        yield SMALL / 'SA_seed_pretraining' / d / f'seed_{s}', SMALL / 'SA_seed_repair' / d / f'seed_{s}'
    if v == 'full':
        b = c.run_of('sa_repair', d, s)
        if (b / 'config.json').exists():
            init = c.read(b / 'config.json').get('init_checkpoint')
            if init:
                yield Path(init).parent, b


def sources():
    return {**previous.source_hashes(), **{n: c.sha(ROOT / n) for n in NEW_FILES}}


def freeze_file(files, path):
    path = Path(path)
    files[str(path)] = {'sha256': c.sha(path), 'bytes': path.stat().st_size,
                        'mtime_ns': path.stat().st_mtime_ns}


def check_frozen(deep=False):
    p = c.read(OUT / 'PROTOCOL.json')
    if p['source_hashes'] != sources():
        raise RuntimeError('Code drift after campaign freeze; preserve state and stop')
    for name, record in p['frozen_files'].items():
        f = Path(name)
        if (f.stat().st_size != record['bytes'] or f.stat().st_mtime_ns != record['mtime_ns']
                or (deep and c.sha(f) != record['sha256'])):
            raise RuntimeError('Frozen source changed: ' + name)


def preflight():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / 'PROTOCOL.json').exists():
        check_frozen()
        c.emit('preflight_resume_verified')
        return
    if not c.read(PRIOR / 'COMPLETE.json')['complete']:
        raise RuntimeError('Previous all-routing campaign incomplete')
    previous.check_frozen(deep=True)
    if shutil.disk_usage(OUT).free < 8 * 1024**3:
        raise RuntimeError('Need at least 8 GiB free on E:')
    files = dict(c.read(PRIOR / 'PROTOCOL.json')['frozen_files'])
    reuse, rejected = [], []
    for item in plan():
        for pair in candidates(item):
            if not all((r / 'config.json').exists() for r in pair):
                continue
            try:
                previous.validate_pair(*key(item), pair)
            except Exception as exc:
                rejected.append({**item, 'candidate': str(pair[1]), 'reason': str(exc)})
                continue
            reuse.append({**item, 'pretraining': str(pair[0]), 'repair': str(pair[1])})
            for run in pair:
                for name in ('best.pt', 'config.json', 'test_metrics.json', 'last.pt', 'test_predictions.npz', 'adaptive_diagnostics.json'):
                    if (run / name).exists():
                        freeze_file(files, run / name)
            for base in (PRIOR, ROOT / 'revision_followup16_20261010', SMALL):
                archive = base / 'predictions' / ('SA_matched_' + item['variant']) / item['domain'] / f"seed_{item['seed']}.npz"
                if archive.exists():
                    with np.load(archive) as z:
                        if str(z['checkpoint_sha256'].item()) == c.sha(pair[1] / 'best.pt'):
                            freeze_file(files, archive)
            break
    if len(reuse) != 112:
        c.atomic_json(OUT / 'REUSE_AUDIT_FAILURE.json', {'reused': reuse, 'rejected': rejected})
        raise RuntimeError(f'Expected audited 112 pairs, found {len(reuse)}; do not silently retrain or drop seeds')
    seen = {key(r) for r in reuse}
    pending = [i for i in plan() if key(i) not in seen]
    if len(pending) != 48 or any(i['domain'] not in ('dma', 'noaa') for i in pending):
        raise RuntimeError('Unexpected missing cohort')
    # Separate cache: train.py rewrites scaler.json. No hardlink for mutable files.
    for domain in c.DOMAINS:
        dest = OUT / 'training_cache' / domain
        if not dest.exists():
            shutil.copytree(ROOT / 'cache' / domain, dest)
        for split in ('train', 'val', 'test'):
            for name in ('history', 'future', 'mmsi'):
                src = ROOT / 'cache' / domain / f'{domain}_{split}' / (name + '.npy')
                copy = dest / f'{domain}_{split}' / (name + '.npy')
                if c.sha(src) != c.sha(copy):
                    raise RuntimeError('Isolated cache mismatch')
        if c.read(dest / 'scaler.json') != c.read(ROOT / 'cache' / domain / 'scaler.json'):
            raise RuntimeError('Isolated scaler mismatch')
    protocol = {'created_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'variants': VARIANTS,
        'domains': c.DOMAINS, 'seeds': c.FIVE, 'expected_total_models': 160,
        'SA_reuse': reuse, 'pending': pending, 'reuse_rejected': rejected,
        'source_hashes': sources(), 'frozen_files': files, 'estimated_hours': [38, 44],
        'independent_random_pretraining_then_own_checkpoint_repair': True,
        'component_switch_active_in_both_stages': True, 'new_training_stages': 96,
        'no_global_time_cutoff': True, 'validation_selection': 'ADE@60',
        'pretrain_epochs_patience_lr': [120, 24, .0001], 'repair_epochs_patience_lr': [60, 12, .00002],
        'repair_cap_seconds': {'dma': 600, 'noaa': 600, 'norway': 240, 'piraeus': 240},
        'temperature_pretrain_repair': [1., 1.5], 'batch_size': 256, 'num_workers': 0,
        'statistics_bootstrap_draws': 10000, 'std_ddof': 1, 'primary_metrics': ['ADE@5', 'ADE@10', 'ADE@60'],
        'Holm_families': ['per variant/family 12 primary ADE cells', 'per variant/family 12 anchor FDE cells',
                          'per family 84 primary ADE cells', 'per family 252 other ADE/FDE cells'],
        'negative_results_retained': True, 'no_test_based_pruning_or_selection': True,
        'historical_test_observed': True, 'no_residual_retains_separate_intent_endpoint_head': True,
        'branch_switches_not_physical_parameter_pruning': True,
        'whole_fusion_shared_five_seed_validation_specialist_selection': True,
        'excluded': ['capacity matched wide-GRU', 'external AIS', 'new model improvements', 'revision manuscript']}
    c.atomic_json(OUT / 'PROTOCOL.json', protocol)
    for name in protocol['source_hashes']:
        dest = OUT / 'frozen_code' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / name, dest)
    c.table('training_plan.csv', [{**i, 'reuse': key(i) in seen} for i in plan()])
    c.emit('preflight_complete', reused_models=len(reuse), new_models=len(pending), new_stages=96)


def execute(cmd, label, logpath):
    check_frozen()
    if shutil.disk_usage(OUT).free < 3 * 1024**3:
        raise RuntimeError('E: below 3 GiB free; preserve checkpoints and stop safely')
    logpath.parent.mkdir(parents=True, exist_ok=True)
    for attempt in (1, 2):
        effective = list(map(str, cmd))
        if 'revision_followup16_training.py' in ' '.join(effective) and (logpath.parent / 'last.pt').exists() and '--resume' not in effective:
            effective.append('--resume')
        with logpath.open('a', encoding='utf-8') as stream:
            proc = subprocess.Popen(effective, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8',
                     'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4', 'OPENBLAS_NUM_THREADS': '4',
                     'TEMP': str(OUT / 'temp'), 'TMP': str(OUT / 'temp')})
            c.atomic_json(OUT / 'CHILD.json', {'pid': proc.pid, 'label': label, 'training_log': str(logpath), 'command': effective})
            c.emit('task_started', label=label, attempt=attempt, pid=proc.pid)
            code = proc.wait()
        c.emit('task_exit', label=label, attempt=attempt, exit_code=code)
        if code == 0:
            return
    raise RuntimeError('Failed after one identical-configuration retry: ' + label)


def training(smoke=False):
    fc, runner = activate()
    if smoke:
        items = [{'variant': v, 'domain': 'piraeus', 'seed': 42} for v in VARIANTS if v not in ('full', 'uniform_router')]
    else:
        reused = {key(i) for i in c.read(OUT / 'PROTOCOL.json')['SA_reuse']}
        items = [i for i in plan() if key(i) not in reused]
    completed = 0
    for item in items:
        for stage in ('pretraining', 'repair'):
            run = c.sa_pair(*key(item))[0 if stage == 'pretraining' else 1]
            if not smoke and fc.finished(run):
                previous.validate_pair(*key(item), c.sa_pair(*key(item))) if stage == 'repair' else fc.validate_config(item, run, stage)
                continue
            cmd = runner.command(item, stage, smoke=smoke)
            set_arg(cmd, '--cache-dir', OUT / 'training_cache')
            if smoke:
                run = OUT / 'smoke' / item['variant'] / stage / item['domain'] / f"seed_{item['seed']}"
                set_arg(cmd, '--output-dir', run.parents[1])
                if stage == 'repair':
                    set_arg(cmd, '--init-checkpoint', OUT / 'smoke' / item['variant'] / 'pretraining' / item['domain'] / f"seed_{item['seed']}" / 'best.pt')
            execute(cmd, '/'.join(map(str, (*key(item), stage))), run / 'terminal.log')
            if not fc.finished(run):
                raise RuntimeError('Training exited without complete checkpoint/predictions: ' + str(run))
            if not smoke:
                fc.validate_config(item, run, stage)
        completed += 1
        c.emit('model_pair_complete', **item, completed_this_invocation=completed, scheduled_models=len(items))
    c.atomic_json(OUT / ('SMOKE_COMPLETE.json' if smoke else 'TRAINING_COMPLETE.json'), {'complete': True, 'models': len(items)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--summary-only', action='store_true')
    parser.add_argument('--refreeze-before-training', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'temp').mkdir(exist_ok=True)
    activate()
    lock = c.FileLock(OUT / 'campaign.lock')
    if not lock.acquire():
        raise RuntimeError('Campaign already running: duplicate launch refused')
    if os.name == 'nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        if args.refreeze_before_training:
            # Implementation repair is allowed only before any formal activation.
            events = OUT / 'events.jsonl'
            import json
            if events.exists() and any(json.loads(line).get('event') == 'campaign_started'
                    for line in events.read_text(encoding='utf-8').splitlines()):
                raise RuntimeError('Cannot refreeze after formal activation')
            p = c.read(OUT / 'PROTOCOL.json')
            if any(p['source_hashes'][n] != value for n, value in previous.source_hashes().items()):
                raise RuntimeError('Historical implementation drift')
            for name, record in p['frozen_files'].items():
                if c.sha(Path(name)) != record['sha256']:
                    raise RuntimeError('Historical input changed')
            shutil.copy2(OUT / 'PROTOCOL.json', OUT / ('PROTOCOL_before_activation_' + time.strftime('%H%M%S') + '.json'))
            p['source_hashes'] = sources()
            c.atomic_json(OUT / 'PROTOCOL.json', p)
            for name in p['source_hashes']:
                dest = OUT / 'frozen_code' / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(ROOT / name, dest)
            c.emit('implementation_refrozen_before_formal_training')
        preflight()
        if args.preflight_only:
            return
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable; no automatic CPU fallback')
        if args.smoke:
            training(smoke=True)
            execute([sys.executable, '-u', ROOT / 'revision_internal_full_results.py', '--smoke'], 'summary_smoke', OUT / 'smoke' / 'summary.log')
            c.atomic_json(OUT / 'ALL_SMOKE_COMPLETE.json', {'complete': True})
            return
        if not (OUT / 'ALL_SMOKE_COMPLETE.json').exists():
            raise RuntimeError('CUDA and analysis smoke tests must pass first')
        c.emit('campaign_started', GPU=torch.cuda.get_device_name(), estimated_hours=[38, 44])
        if not args.summary_only:
            training()
        execute([sys.executable, '-u', ROOT / 'revision_internal_full_results.py'], 'full_statistics_and_figures', OUT / 'summary.log')
        node = Path('C:/Users/29146/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
        execute([node, ROOT / 'verify_internal_full_csv.mjs', OUT], 'artifact_CSV_verification', OUT / 'CSV_verification.log')
        check_frozen(deep=True)
        c.atomic_json(OUT / 'COMPLETE.json', {'complete': True, 'finished_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            'models': 160, 'domains': c.DOMAINS, 'seeds': c.FIVE, 'full_revision_complete': False})
        c.emit('campaign_complete', models=160)
    except Exception as exc:
        c.atomic_json(OUT / 'FAILURE.json', {'time': time.strftime('%Y-%m-%d %H:%M:%S'),
            'reason': str(exc), 'traceback': traceback.format_exc(), 'resumable': True})
        c.emit('campaign_error', reason=str(exc))
        raise
    finally:
        if os.name == 'nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.release()


if __name__ == '__main__':
    main()
