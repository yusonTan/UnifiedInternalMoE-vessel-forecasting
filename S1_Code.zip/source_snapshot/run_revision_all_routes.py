"""Execute all locked routing experiments serially; resume without seed pruning."""
from __future__ import annotations
import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
import numpy as np
import torch
from revision_all_routes_common import *

SOURCE_NAMES = ('revision_all_routes_common.py','revision_all_routes_analysis.py','run_revision_all_routes.py',
    'verify_all_routes_csv.mjs','tests/test_revision_all_routes.py','revision_followup16_training.py',
    'revision_followup16_common.py','run_revision_followup16.py','run_revision_10seed.py','revision_10seed_results.py',
    'revision_2h_results.py','run_revision_2h.py','revision_5h_analysis.py','evaluate_compact_committee.py',
    'run_plos_rigor_suite.py','run_complete_study_stage.py','train.py','comparison_models.py','faithful_sota_models.py')

def source_hashes():
    paths=[ROOT/n for n in SOURCE_NAMES]+list((ROOT/'amf').glob('*.py'))
    return {str(p.relative_to(ROOT)):sha(p) for p in paths}

def reuse_candidates(variant,domain,seed):
    from revision_followup16_common import existing_run
    roots=[Path('E:/OE_revision16_20261010')/'SA_matched'/variant]
    for root in roots:
        yield root/'pretraining'/domain/f'seed_{seed}',root/'repair'/domain/f'seed_{seed}'
    item={'variant':variant,'domain':domain,'seed':seed}
    a,b=existing_run(item,'pretraining'),existing_run(item,'repair')
    if a is not None:yield a,b
    if variant=='full':
        from run_revision_7h import run_of as previous_run
        b=run_of('sa_repair',domain,seed)
        cfg=b/'config.json'
        if cfg.exists() and read(cfg).get('init_checkpoint'):
            a=Path(read(cfg)['init_checkpoint']).parent
            yield a,b

def validate_pair(variant,domain,seed,pair):
    import revision_followup16_common as c
    before=c.selected_run
    c.selected_run=lambda item,stage:pair[0 if stage=='pretraining' else 1]
    try:
        for stage,r in zip(('pretraining','repair'),pair):
            if not c.finished(r):raise RuntimeError('Incomplete predecessor/repair')
            cfg=c.validate_config({'variant':variant,'domain':domain,'seed':seed},r,stage)
            if cfg['scaler']!=read(ROOT/'cache'/domain/'scaler.json'):raise RuntimeError('Scaler mismatch')
    finally:c.selected_run=before

def preflight():
    OUT.mkdir(parents=True,exist_ok=True)
    if not read(MAIN/'TEN_SEED_COMPLETE.json')['complete']:raise RuntimeError('Ten-seed source incomplete')
    if shutil.disk_usage(OUT).free<6*1024**3:raise RuntimeError('Need 6 GiB on output drive')
    # train.py refits/saves scaler.json on every invocation. Never let new
    # training rewrite metadata or files in the frozen historical cache.
    for domain in DOMAINS:
        destination=OUT/'training_cache'/domain
        if not destination.exists():shutil.copytree(ROOT/'cache'/domain,destination)
    if (OUT/'PROTOCOL.json').exists():
        check_frozen();emit('preflight_resume_verified');return
    reuse=[];rejected=[];files={};data=[]
    f=MAIN/'four_domain_10seed_per_seed.csv'
    files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
    for variant in ('full','uniform_router'):
        for domain in DOMAINS:
            for seed in FIVE:
                for pair in reuse_candidates(variant,domain,seed):
                    if not pair[0].exists() or not pair[1].exists():continue
                    try:validate_pair(variant,domain,seed,pair)
                    except Exception as e:
                        rejected.append({'variant':variant,'domain':domain,'seed':seed,'candidate':str(pair[1]),'reason':str(e)});continue
                    reuse.append({'variant':variant,'domain':domain,'seed':seed,'pretraining':str(pair[0]),'repair':str(pair[1])})
                    for r in pair:
                        for n in ('config.json','best.pt'):
                            f=r/n;files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
                    break
    for domain in DOMAINS:
        sets=[]
        for split in ('train','val','test'):
            folder=ROOT/'cache'/domain/f'{domain}_{split}'
            x,y,ids=[np.load(folder/(n+'.npy'),mmap_mode='r') for n in ('history','future','mmsi')]
            if x.shape[1:]!=(90,6) or y.shape[1:]!=(180,2) or not len(x)==len(y)==len(ids):raise RuntimeError('Invalid cache dimensions')
            sets.append(set(np.unique(ids).tolist()));data.append({'domain':domain,'split':split,'windows':len(ids),'MMSI':len(sets[-1])})
            for n in ('history','future','mmsi'):
                f=folder/(n+'.npy');files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
        if any(sets[a]&sets[b] for a,b in ((0,1),(0,2),(1,2))):raise RuntimeError('MMSI split overlap')
        f=ROOT/'cache'/domain/'scaler.json';files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
        for seed in SEEDS:
            for name in EXPERTS:
                for filename in ('best.pt','config.json'):
                    f=run_of(name,domain,seed)/filename
                    files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
                with collect_main(name,domain,seed) as z:
                    f=Path(z.fid.name)
                    files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
            f=MAIN/'fusion_10seed_refit'/domain/f'seed_{seed}'/'best.pt'
            files[str(f)]={'sha256':sha(f),'bytes':f.stat().st_size,'mtime_ns':f.stat().st_mtime_ns}
            p,y,ids,idx=load_data(domain,seed)
            cacheids=np.load(ROOT/'cache'/domain/f'{domain}_val'/'mmsi.npy')
            if not np.array_equal(ids,cacheids) or not np.array_equal(idx,np.arange(len(ids))):raise RuntimeError('Prediction window IDs differ from canonical cache')
            del p,y,ids,idx
            emit('source_domain_seed_audited',domain=domain,seed=seed)
    protocol={'created_at':time.strftime('%Y-%m-%d %H:%M:%S'),'estimated_hours':[14,18],'planning_budget_hours':20,
       'global_deadline_does_not_truncate_training':True,'outer_domains':DOMAINS,'outer_seeds':SEEDS,
       'outer_models':(*STATIC,*HEADS),'outer_scopes':['all5','formal_mask'],'inner_seeds':FIVE,
       'inner_variants':['full','uniform_router'],'SA_reuse':reuse,'reuse_rejected':rejected,
       'source_hashes':source_hashes(),'frozen_files':files,'data':data,'ridge_grid':RIDGES,'anchor_grid':ANCHORS,
       'gate_epoch_limit':40,'gate_patience':8,'gate_epoch0_candidate':True,'gate_per_fit_time_cap':None,
       'alternate_scales':['original','CV15_validation','best_expert_validation','median_expert_validation'],
       'alternate_horizon_weights':[[1,1,2],[1,1,1],[1,1,4]],'alternate_subset_family':'SA plus zero, one or two other experts',
       'selection':'nested MMSI validation; own-seed outer routes; SA whole-fusion specialist remains shared across five seeds',
       'SA_original_training_caps_retained_seconds':{'dma':600,'noaa':600,'norway':240,'piraeus':240},
       'stability_fractions':[.25,.5,.75,1.],'stability_repetitions':[50,50,50,1],
       'historical_test_was_observed':True,'new_test_based_model_selection':False,
       'scope_excludes':['capacity matched GRU','other SA internal components','external AIS','full revision manuscript']}
    atomic_json(OUT/'PROTOCOL.json',protocol)
    for name in protocol['source_hashes']:
        dest=OUT/'frozen_code'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,dest)
    table('source_audit.csv',data)
    emit('preflight_complete',reused_SA_pairs=len(reuse),new_SA_pairs=40-len(reuse),output=str(OUT))

def check_frozen(deep=False):
    p=read(OUT/'PROTOCOL.json')
    if p['source_hashes']!=source_hashes():raise RuntimeError('Code changed after protocol freeze')
    for name,s in p['frozen_files'].items():
        f=Path(name)
        if f.stat().st_size!=s['bytes'] or f.stat().st_mtime_ns!=s['mtime_ns'] or (deep and sha(f)!=s['sha256']):
            raise RuntimeError('Frozen input changed: '+name)

def execute(cmd,label,logpath):
    check_frozen()
    if shutil.disk_usage(OUT).free<3*1024**3:raise RuntimeError('Output drive below 3 GiB; preserve state and stop')
    logpath.parent.mkdir(parents=True,exist_ok=True)
    for attempt in (1,2):
        effective=list(cmd)
        if 'revision_followup16_training.py' in ' '.join(effective) and (logpath.parent/'last.pt').exists() and '--resume' not in effective:
            effective.append('--resume')
        with logpath.open('a',encoding='utf-8') as stream:
            child=subprocess.Popen(effective,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,
                  env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','OMP_NUM_THREADS':'4',
                       'MKL_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4','TEMP':str(OUT/'temp'),'TMP':str(OUT/'temp')})
            atomic_json(OUT/'CHILD.json',{'pid':child.pid,'label':label,'training_log':str(logpath),'command':effective})
            emit('task_started',label=label,attempt=attempt,pid=child.pid)
            code=child.wait()
        emit('task_exit',label=label,attempt=attempt,exit_code=code)
        if code==0:return
    raise RuntimeError('Task failed after same-configuration retry: '+label)

def sa_training(smoke=False):
    c,runner=configure_sa()
    variants=('uniform_router',) if smoke else ('full','uniform_router')
    domains=('piraeus',) if smoke else DOMAINS
    seeds=(42,) if smoke else FIVE
    from run_revision_2h import set_arg
    for seed in seeds:
        for domain in domains:
            for variant in variants:
                item={'variant':variant,'domain':domain,'seed':seed}
                for stage in ('pretraining','repair'):
                    run=sa_pair(variant,domain,seed)[0 if stage=='pretraining' else 1]
                    if not smoke and c.finished(run):
                        c.validate_config(item,run,stage);continue
                    cmd=runner.command(item,stage,smoke=smoke)
                    set_arg(cmd,'--cache-dir',OUT/'training_cache')
                    if smoke:
                        run=OUT/'smoke'/'SA'/variant/stage/domain/f'seed_{seed}'
                        set_arg(cmd,'--output-dir',run.parents[1])
                        if stage=='repair':set_arg(cmd,'--init-checkpoint',OUT/'smoke'/'SA'/variant/'pretraining'/domain/f'seed_{seed}'/'best.pt')
                    execute(cmd,f'SA/{variant}/{domain}/{seed}/{stage}',run/'terminal.log')
                    if not c.finished(run):raise RuntimeError('Training exited without complete output')
                    if not smoke:c.validate_config(item,run,stage)
    atomic_json(OUT/('SA_SMOKE_COMPLETE.json' if smoke else 'SA_TRAINING_COMPLETE.json'),{'complete':True})

def phase_commands():
    entry=str(ROOT/'revision_all_routes_analysis.py')
    for seed in SEEDS:
        for domain in DOMAINS:
            for scope in ('all5','formal_mask'):
                yield f'routing/{scope}/{domain}/{seed}',[sys.executable,'-u',entry,'--phase','routing','--domain',domain,'--seed',str(seed),'--scope',scope],OUT/'routing'/scope/domain/f'seed_{seed}'/'RESULT.json'
            for phase,folder in (('anchors','anchors'),('alternate','alternate_objective')):
                yield f'{phase}/{domain}/{seed}',[sys.executable,'-u',entry,'--phase',phase,'--domain',domain,'--seed',str(seed)],OUT/folder/domain/f'seed_{seed}'/'RESULT.json'
        yield f'stability/{seed}',[sys.executable,'-u',entry,'--phase','stability','--seed',str(seed)],OUT/'stability'/f'seed_{seed}'/'RESULT.json'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'temp').mkdir(exist_ok=True)
    lock=FileLock(OUT/'campaign.lock')
    if not lock.acquire():raise RuntimeError('Campaign already running; duplicate launch refused')
    if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        preflight()
        if args.preflight_only:return
        if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; no CPU training fallback')
        if args.smoke:
            sa_training(smoke=True)
            execute([sys.executable,'-u',str(ROOT/'revision_all_routes_analysis.py'),'--phase','smoke'],'routing_smoke',OUT/'smoke'/'routing.log')
            atomic_json(OUT/'SMOKE_COMPLETE.json',{'complete':True});return
        if not (OUT/'SMOKE_COMPLETE.json').exists():raise RuntimeError('Smoke tests must pass before official launch')
        emit('campaign_started',GPU=torch.cuda.get_device_name(),estimated_hours=[14,18])
        sa_training()
        execute([sys.executable,'-u',str(ROOT/'revision_all_routes_analysis.py'),'--phase','internal'],'internal_five_seed_summary',OUT/'internal_summary.log')
        for label,cmd,marker in phase_commands():
            if marker.exists() and read(marker).get('complete'):continue
            execute(cmd,label,marker.parent/'terminal.log')
        execute([sys.executable,'-u',str(ROOT/'revision_all_routes_analysis.py'),'--phase','summary'],'all_route_statistics',OUT/'summary.log')
        node=Path('C:/Users/29146/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
        execute([str(node),str(ROOT/'verify_all_routes_csv.mjs'),str(OUT)],'CSV_artifact_verification',OUT/'CSV_verification.log')
        check_frozen(deep=True)
        (OUT/'REPORT.md').write_text('# Completed routing evidence\n\nFour-domain ten-seed external routes, nested anchor sensitivity, alternative validation objective reselection, Piraeus validation-size stability and four-domain five-seed matched SA uniform-routing controls are complete.\n\nOriginal outputs remain unchanged. All negative outcomes are retained. Historical test observations and shared five-seed SA-fusion specialist selection remain limitations. This is not an untouched external holdout. Capacity matching and other revision tasks are outside this campaign.\n',encoding='utf-8')
        atomic_json(OUT/'COMPLETE.json',{'complete':True,'finished_at':time.strftime('%Y-%m-%d %H:%M:%S'),
             'outer_seeds':SEEDS,'internal_seeds':FIVE,'full_revision_complete':False})
        emit('campaign_complete')
    except Exception as e:
        atomic_json(OUT/'FAILURE.json',{'time':time.strftime('%Y-%m-%d %H:%M:%S'),'reason':str(e),'traceback':traceback.format_exc(),'resumable':True})
        emit('campaign_error',reason=str(e));raise
    finally:
        if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.release()

if __name__=='__main__':main()
