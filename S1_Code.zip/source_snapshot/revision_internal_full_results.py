"""Audited matched component effects, before and after validation-only refusion."""
from __future__ import annotations
import argparse
import gc
import json
from pathlib import Path
import numpy as np
import torch
import revision_all_routes_common as c
import revision_2h_results as old
from run_revision_internal_full import OUT, ROOT, PRIOR, SMALL, VARIANTS, activate, check_frozen, plan


def aligned(a, b, split):
    for suffix in ('MMSI', 'window_index'):
        if not np.array_equal(a[split + '_' + suffix], b[split + '_' + suffix]):
            raise RuntimeError('Prediction MMSI/window alignment failed')
    if a[split + '_target'].shape != b[split + '_target'].shape or np.max(np.abs(a[split + '_target'] - b[split + '_target'])) > .05:
        raise RuntimeError('Prediction target alignment failed')


def collect(variant, domain, seed):
    run = c.sa_pair(variant, domain, seed)[1]
    digest = c.sha(run / 'best.pt')
    for base in (OUT, PRIOR, ROOT / 'revision_followup16_20261010', SMALL):
        path = base / 'predictions' / ('SA_matched_' + variant) / domain / f'seed_{seed}.npz'
        if path.exists():
            with np.load(path, allow_pickle=False) as z:
                if str(z['checkpoint_sha256'].item()) == digest:
                    return {k: z[k].copy() for k in z.files}
    return c.collect_sa(variant, domain, seed)


def error_path(family, domain, variant, seed):
    return OUT / 'errors' / family / domain / variant / f'seed_{seed}.npz'


def summarize_unit(domain, variant):
    directory = OUT / 'fusion' / domain / variant
    marker = directory / 'RESULT.json'
    if marker.exists():
        saved = c.read(marker)
        if saved.get('complete') and len(saved['rows']) == 10 and all(error_path(f, domain, variant, s).exists() for f in ('SA_only', 'whole_fusion') for s in c.FIVE):
            return saved['rows'], saved['provenance'], saved['stages'], saved['anchor_rows']
    rows, provenance, stages, anchors, records = [], [], [], [], {}
    for seed in c.FIVE:
        z = collect(variant, domain, seed)
        loaded = {'sa_repair': z}
        for name in c.EXPERTS[1:]:
            with c.collect_main(name, domain, seed) as other:
                loaded[name] = {k: other[k].copy() for k in other.files}
            for split in ('val', 'test'):
                aligned(z, loaded[name], split)
        for split in ('val', 'test'):
            ids = np.load(ROOT / 'cache' / domain / f'{domain}_{split}' / 'mmsi.npy', mmap_mode='r')
            if not np.array_equal(ids, z[split + '_MMSI']) or not np.array_equal(np.arange(len(ids)), z[split + '_window_index']):
                raise RuntimeError('SA predictions differ from canonical split/window order')
            if not np.isfinite(z[split + '_prediction']).all():
                raise RuntimeError('Nonfinite predictions')
        records[seed] = loaded
        pre, repair = c.sa_pair(variant, domain, seed)
        best = torch.load(repair / 'best.pt', map_location='cpu', weights_only=False)
        rows.append({'family': 'SA_only', **old.metric_row(domain, seed, variant,
            'matched_internal_five_seed', z['test_prediction'], z['test_target'], z['val_prediction'], z['val_target'], int(best['epoch']))})
        c.archive(error_path('SA_only', domain, variant, seed), mmsi=z['test_MMSI'],
            window_index=z['test_window_index'], **c.errors(z['test_prediction'], z['test_target']))
        parameters = sum(v.numel() for k, v in best['model'].items() if torch.is_tensor(v))
        provenance.append({'domain': domain, 'seed': seed, 'variant': variant, 'pretraining': str(pre),
            'repair': str(repair), 'checkpoint_sha256': c.sha(repair / 'best.pt'),
            'state_dict_elements_including_buffers': parameters,
            'branch_disabled_not_physically_pruned': True, 'no_residual_retains_intent': variant == 'no_residual'})
        del best
        for stage, run in (('pretraining', pre), ('repair', repair)):
            cfg = c.read(run / 'config.json')
            last = torch.load(run / 'last.pt', map_location='cpu', weights_only=False) if (run / 'last.pt').exists() else {}
            stages.append({'domain': domain, 'seed': seed, 'variant': variant, 'stage': stage, 'run': str(run),
                'epochs_completed': last.get('epoch'), 'cumulative_training_seconds': last.get('followup16_elapsed'),
                'init_checkpoint': cfg.get('init_checkpoint'), 'checkpoint_sha256': c.sha(run / 'best.pt')})
            del last
    # Both expert and subset decisions are locked from validation before evaluating fusion test metrics.
    weights, lock = old.fit_fusion_group(records, c.FIVE, domain)
    c.atomic_json(directory / 'VALIDATION_SELECTION_LOCK.json', lock)
    for seed, zr in records.items():
        z = zr['sa_repair']
        c.atomic_json(directory / f'seed_{seed}' / 'replay_config.json', {
            'domain': domain, 'seed': seed, 'variant': variant, 'input_shape': [90, 6], 'output_shape': [180, 2],
            'expert_checkpoints': {'sa_repair': str(c.sa_pair(variant, domain, seed)[1] / 'best.pt'),
                **{n: str(c.run_of(n, domain, seed) / 'best.pt') for n in c.EXPERTS[1:]}},
            'steps': [15, 30, 180], 'weights': weights[seed],
            'frozen_validation_route': True, 'shared_five_seed_specialist': True})
        predictions = {}
        for split in ('val', 'test'):
            p = np.stack([zr[name][split + '_prediction'] for name in c.EXPERTS], axis=1)
            predictions[split] = c.route_blend(p, {'steps': [15, 30, 180], 'weights': weights[seed]})
            c.archive(directory / f'seed_{seed}' / (split + '_predictions.npz'), prediction=predictions[split],
                target=z[split + '_target'], mmsi=z[split + '_MMSI'], window_index=z[split + '_window_index'])
        rows.append({'family': 'whole_fusion', **old.metric_row(domain, seed, variant,
            'refitted_fusion_five_seed_shared_validation_specialist', predictions['test'], z['test_target'],
            predictions['val'], z['val_target'], 0)})
        c.archive(error_path('whole_fusion', domain, variant, seed), mmsi=z['test_MMSI'],
            window_index=z['test_window_index'], **c.errors(predictions['test'], z['test_target']))
        for j, minute in enumerate((5, 10, 60)):
            for k, expert in enumerate(c.EXPERTS):
                anchors.append({'domain': domain, 'variant': variant, 'seed': seed,
                    'minute': minute, 'expert': expert, 'weight': float(weights[seed][j, k]),
                    'shared_validation_specialist': lock['selected_short_specialist']})
    c.atomic_json(marker, {'complete': True, 'rows': rows, 'provenance': provenance, 'stages': stages, 'anchor_rows': anchors})
    del records
    gc.collect()
    c.emit('analysis_unit_complete', domain=domain, variant=variant)
    return rows, provenance, stages, anchors


def paired_statistics():
    result, per_seed = [], []
    for family in ('SA_only', 'whole_fusion'):
        for variant in VARIANTS[1:]:
            for domain in c.DOMAINS:
                deltas, canonical = {m: [] for m in c.METRICS}, None
                for seed in c.FIVE:
                    with np.load(error_path(family, domain, 'full', seed)) as a, np.load(error_path(family, domain, variant, seed)) as b:
                        if not np.array_equal(a['mmsi'], b['mmsi']) or not np.array_equal(a['window_index'], b['window_index']):
                            raise RuntimeError('Paired error ordering differs')
                        if canonical is not None and not np.array_equal(canonical, a['mmsi']):
                            raise RuntimeError('Seed MMSI ordering differs')
                        canonical = a['mmsi'].copy()
                        row = {'family': family, 'variant': variant, 'domain': domain, 'seed': seed,
                               'direction': 'variant_minus_full_positive_favors_full'}
                        for metric in c.METRICS:
                            difference = b[metric] - a[metric]
                            deltas[metric].append(difference)
                            row[metric + '_difference_m'] = float(difference.mean())
                        per_seed.append(row)
                for metric in c.METRICS:
                    result.append({'family': family, 'variant': variant, 'domain': domain, 'metric': metric,
                        'n_seeds': 5, 'direction': 'variant_minus_full_positive_favors_full',
                        'shared_validation_fusion_dependence': family == 'whole_fusion',
                        **c.paired_uncertainty(np.stack(deltas[metric]), canonical,
                            np.random.default_rng(41000 + len(result)), draws=10000)})
                c.emit('paired_statistics_domain_complete', family=family, variant=variant, domain=domain)
            selected = [r for r in result if r['family'] == family and r['variant'] == variant]
            c.holm([r for r in selected if r['metric'] in ('ADE@5', 'ADE@10', 'ADE@60')], 'primary_ADE_12cell_Holm_p')
            c.holm([r for r in selected if r['metric'] in ('FDE@5', 'FDE@10', 'FDE@60')], 'anchor_FDE_12cell_Holm_p')
        selected = [r for r in result if r['family'] == family]
        c.holm([r for r in selected if r['metric'] in ('ADE@5', 'ADE@10', 'ADE@60')], 'all_variants_primary_84cell_Holm_p')
        c.holm([r for r in selected if r['metric'] not in ('ADE@5', 'ADE@10', 'ADE@60')], 'all_variants_secondary_252cell_Holm_p')
    c.table('paired_uncertainty.csv', result)
    c.table('paired_seed_differences.csv', per_seed)


def macros_and_plots(rows, means):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size': 10, 'savefig.dpi': 220})
    macros, changes = [], []
    for family in ('SA_only', 'whole_fusion'):
        for variant in VARIANTS:
            subset = [r for r in rows if r['family'] == family and r['model'] == variant]
            seed_j = [np.mean([r['test_J'] for r in subset if r['seed'] == s]) for s in c.FIVE]
            seed_v = [np.mean([r['validation_J'] for r in subset if r['seed'] == s]) for s in c.FIVE]
            macros.append({'family': family, 'variant': variant, 'four_region_equal_macro_test_J': float(np.mean(seed_j)),
                'macro_J_across_seed_std': float(np.std(seed_j, ddof=1)),
                'four_region_equal_macro_validation_J': float(np.mean(seed_v)), 'n_seeds': 5,
                'J_dimensionless': True})
            for domain in c.DOMAINS:
                current = next(r for r in means if r['family'] == family and r['domain'] == domain and r['model'] == variant)
                baseline = next(r for r in means if r['family'] == family and r['domain'] == domain and r['model'] == 'full')
                changes.append({'family': family, 'domain': domain, 'variant': variant,
                    'test_J_relative_change_percent': 100 * (current['test_J_mean'] / baseline['test_J_mean'] - 1),
                    'validation_J_relative_change_percent': 100 * (current['validation_J_mean'] / baseline['validation_J_mean'] - 1)})
        fig, axes = plt.subplots(2, 2, figsize=(12, 7), constrained_layout=True)
        for domain, ax in zip(c.DOMAINS, axes.flat):
            selected = [next(r for r in means if r['family'] == family and r['domain'] == domain and r['model'] == v) for v in VARIANTS]
            ax.bar(np.arange(8), [r['ADE@60_mean'] for r in selected], yerr=[r['ADE@60_std'] for r in selected], capsize=3)
            ax.set_xticks(np.arange(8), VARIANTS, rotation=35, ha='right')
            ax.set_title(domain.upper()); ax.set_ylabel('ADE@60 (m), mean +/- sample SD')
        fig.savefig(OUT / f'{family}_ADE60.png'); fig.savefig(OUT / f'{family}_ADE60.pdf'); plt.close(fig)
        matrix = np.array([[next(r['test_J_relative_change_percent'] for r in changes if r['family'] == family and r['domain'] == d and r['variant'] == v) for d in c.DOMAINS] for v in VARIANTS])
        fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
        vmax = max(float(np.abs(matrix).max()), .01)
        im = ax.imshow(matrix, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
        ax.set_xticks(range(4), [d.upper() for d in c.DOMAINS]); ax.set_yticks(range(8), VARIANTS)
        for i in range(8):
            for j in range(4): ax.text(j, i, f'{matrix[i, j]:+.2f}%', ha='center', va='center')
        fig.colorbar(im, ax=ax, label='Test J change (%); positive favors full')
        ax.set_title(family + ': matched five-seed component effects')
        fig.savefig(OUT / f'{family}_J_changes.png'); fig.savefig(OUT / f'{family}_J_changes.pdf'); plt.close(fig)
    for row in macros:
        full = next(r for r in macros if r['family'] == row['family'] and r['variant'] == 'full')
        row['relative_to_full_percent'] = 100 * (row['four_region_equal_macro_test_J'] / full['four_region_equal_macro_test_J'] - 1)
    c.table('macro_objectives.csv', macros)
    c.table('domain_relative_changes.csv', changes)


def smoke():
    rng = np.random.default_rng(52)
    records = {}
    for seed in c.FIVE:
        y = rng.normal(size=(18, 180, 2)).astype(np.float32)
        records[seed] = {n: {'val_prediction': y + rng.normal(size=y.shape).astype(np.float32),
                            'val_target': y, 'val_MMSI': np.repeat(np.arange(9), 2)} for n in c.EXPERTS}
    weights, lock = old.fit_fusion_group(records, c.FIVE, 'synthetic')
    for w in weights.values():
        np.testing.assert_allclose(w.sum(1), 1., atol=1e-7)
        assert w.min() >= 0
    c.table('smoke_metrics.csv', [{'model': 'full', 'ADE@60': 1., 'seed': 42}, {'model': 'ablated', 'ADE@60': 2., 'seed': 42, 'extra': 'union_header'}])
    c.atomic_json(OUT / 'smoke' / 'ANALYSIS_COMPLETE.json', {'complete': True, 'synthetic_validation_route': lock})


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--smoke', action='store_true'); args = parser.parse_args()
    activate(); torch.set_num_threads(4); check_frozen()
    if args.smoke:
        smoke(); return
    import revision_followup16_common as fc
    import run_revision_all_routes as previous
    for item in plan():
        previous.validate_pair(item['variant'], item['domain'], item['seed'], c.sa_pair(item['variant'], item['domain'], item['seed']))
    rows, provenance, stages, anchors = [], [], [], []
    for domain in c.DOMAINS:
        for variant in VARIANTS:
            a, b, d, e = summarize_unit(domain, variant)
            rows.extend(a); provenance.extend(b); stages.extend(d); anchors.extend(e)
    means = c.mean_std(rows, keys=('family', 'domain', 'model', 'protocol'), expected=c.FIVE)
    c.table('internal_per_seed.csv', rows); c.table('internal_mean_std.csv', means)
    c.table('training_provenance.csv', provenance); c.table('training_stage_provenance.csv', stages)
    c.table('fusion_anchor_weights.csv', anchors)
    macros_and_plots(rows, means)
    paired_statistics()
    (OUT / 'REPORT.md').write_text('# Four-domain five-seed matched internal ablation\n\n'
        'Eight variants (full plus seven controls), 160 SA models, 112 reused protocol-audited pairs and 48 new independent two-stage pairs. '
        'Both SA-only and whole-fusion results are reported. The other four experts are fixed; fusion is refitted from validation under the same compact family. '
        'Short-specialist selection is shared across five seeds. Fusion bootstrap intervals are conditional/descriptive, not independent-seed claims.\n\n'
        'Positive variant-minus-full differences favor full; negative outcomes are retained. Sample SD uses ddof=1. J is dimensionless with equal region weighting. '
        'Primary comparisons are ADE at 5/10/60 min; multiplicity families are identified in table columns. '
        'MMSI and window ordering are validated before pairing. Cluster bootstrap-t is approximate with few MMSIs.\n\n'
        'Component switches disable computation/outputs rather than prune declared parameters. no_residual disables dense and spline residuals but retains the separate intent endpoint correction. '
        'Historical test observations remain a limitation: these are not unseen external data. No test-driven variant pruning, early stopping, hyperparameter upgrades or incomplete-cohort refitting were performed. '
        'Capacity matching and independent external AIS are outside this campaign.\n', encoding='utf-8')
    c.atomic_json(OUT / 'ANALYSIS_COMPLETE.json', {'complete': True, 'models': 160, 'metric_rows': 320,
        'paired_metric_cells': 672, 'whole_fusion_shared_validation_dependence': True})


if __name__ == '__main__': main()
