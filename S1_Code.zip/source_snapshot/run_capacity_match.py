"""Serial ten-seed capacity control with audited inputs and bounded retries."""
from __future__ import annotations
import argparse
import ctypes
import os
import shutil
import subprocess
import sys
import time
import traceback
import numpy as np
import torch
import capacity_match_common as c

NODE=c.Path('C:/Users/29146/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')


def tasks():
    return [(d,s) for s in c.SEEDS for d in c.DOMAINS]


def freeze_file(files,path):
    path=c.Path(path);files[str(path)]={'sha256':c.sha(path),'bytes':path.stat().st_size,'mtime_ns':path.stat().st_mtime_ns}


def preflight():
    c.OUT.mkdir(parents=True,exist_ok=True);(c.OUT/'temp').mkdir(exist_ok=True)
    if (c.OUT/'PROTOCOL.json').exists():c.check_frozen();c.emit('preflight_resume_verified');return
    if shutil.disk_usage(c.OUT).free<8*1024**3:raise RuntimeError('Need 8 GiB before admission with checkpoint compaction')
    if not c.read(c.MAIN/'TEN_SEED_COMPLETE.json')['complete']:raise RuntimeError('Ten-seed reference cohort incomplete')
    inherited=c.read(c.Path('E:/OE_internal_full_20261014/PROTOCOL.json'))
    for name,value in inherited['source_hashes'].items():
        if c.sha(c.ROOT/name)!=value:raise RuntimeError('Historical implementation drift: '+name)
    files=dict(inherited['frozen_files']);data=[]
    for domain in c.DOMAINS:
        groups=[]
        for split in ('train','val','test'):
            base=c.ROOT/'cache'/domain/f'{domain}_{split}'
            x,y,ids=[np.load(base/(n+'.npy'),mmap_mode='r') for n in ('history','future','mmsi')]
            if x.shape[1:]!=(90,6) or y.shape[1:]!=(180,2) or not len(x)==len(y)==len(ids):raise RuntimeError('Data shape mismatch')
            groups.append(set(np.unique(ids).tolist()));data.append({'domain':domain,'split':split,'windows':len(ids),'MMSI':len(groups[-1])})
        if any(groups[i]&groups[j] for i,j in ((0,1),(0,2),(1,2))):raise RuntimeError('MMSI splits overlap')
        for seed in c.SEEDS:
            original=c.run_of('direct_gru',domain,seed)
            cfg=c.read(original/'config.json')
            for key,value in {'epochs':80,'patience':20,'learning_rate':.0005,'batch_size':256,
                'weight_decay':.0001,'checkpoint_score':'ADE@60+2*ADE@10','parameter_count':276840}.items():
                if cfg.get(key)!=value:raise RuntimeError('Original GRU protocol differs: '+str(original)+' '+key)
            for n in ('best.pt','config.json','result.json'):freeze_file(files,original/n)
            freeze_file(files,c.baseline_archive(domain,seed))
            packed=c.MAIN/'fusion_10seed_refit'/domain/f'seed_{seed}'
            for n in ('best.pt','config.json','val_predictions.npz','test_predictions.npz'):freeze_file(files,packed/n)
        c.emit('reference_domain_audited',domain=domain)
    from amf.unified_predictor import UnifiedInternalMoE
    from comparison_models import DirectRNN
    fusion=UnifiedInternalMoE();wide=DirectRNN('gru',hidden=c.HIDDEN)
    nfull=sum(p.numel() for p in fusion.parameters());nwide=sum(p.numel() for p in wide.parameters())
    if nfull!=17656244 or nwide!=17526696 or abs(nwide/nfull-1)>.10:raise RuntimeError('Capacity definition drift')
    c.atomic_json(c.OUT/'PROTOCOL.json',{'created_at':time.strftime('%Y-%m-%d %H:%M:%S'),
        'domains':c.DOMAINS,'seeds':c.SEEDS,'models':c.MODELS,'new_training_runs':40,'hidden':c.HIDDEN,
        'parameter_counts':{'UnifiedInternalMoE':nfull,'Direct-GRU':276840,'Wide-GRU':nwide},
        'relative_parameter_difference_percent':100*(nwide/nfull-1),'wide_config_example':c.config('dma',42),
        'source_hashes':c.sources(),'frozen_files':files,'data':data,'estimated_hours':[20,26],
        'selection_uses_validation_only':True,'no_test_based_seed_or_model_pruning':True,'no_global_time_cutoff':True,
        'original_predictor_version':'ten_seed_shared_validation_route_selection; not best test-selected internal variant',
        'parameters_matched_not_FLOPs_training_budget_or_latency':True,
        'fusion_shared_validation_dependence':True,'historical_test_previously_observed':True,
        'checkpoint_retention':'all best states retained; completed new-run redundant last optimizer state removed after hash acceptance; active run retains full state',
        'small_cluster_inference':'approximate; crossed intervals for fusion conditional/descriptive',
        'cost_models':['fusion','original_gru','wide_gru','homogeneous_itransformer'],
        'cost_domain_seed':['dma',42],'cost_precision':'FP32','cost_repeats':3,'cost_iterations':200,'cost_warmup':50,
        'minimum_output_free_GiB':3,'std_ddof':1,'bootstrap_draws':10000,
        'convergence_diagnostics':'retain epoch-limit flags, tail loss slope, last validation improvement; no claims that an undertrained baseline proves capacity irrelevant',
        'not_in_scope':['external AIS','new routing algorithm','remaining revision experiments','manuscript editing']})
    for name in c.sources():
        dest=c.OUT/'frozen_code'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(c.ROOT/name,dest)
    c.table('capacity_parameter_audit.csv',[{'model':m,'parameters':n,'relative_to_fusion_percent':100*(n/nfull-1)}
        for m,n in (('UnifiedInternalMoE',nfull),('Direct-GRU',276840),('Wide-GRU',nwide),('homogeneous_itransformer',3*5648924))])
    c.table('capacity_data_audit.csv',data)
    c.check_frozen(deep=True);c.emit('preflight_complete',new_runs=40,relative_capacity_percent=100*(nwide/nfull-1))


def execute(command,label,log):
    c.check_frozen()
    if shutil.disk_usage(c.OUT).free<3*1024**3:raise RuntimeError('E: below 3 GiB; checkpoint and stop safely')
    log.parent.mkdir(parents=True,exist_ok=True)
    for attempt in (1,2):
        cmd=list(map(str,command))
        if 'capacity_match_training.py' in ' '.join(cmd) and (log.parent/'last.pt').exists() and '--resume' not in cmd:cmd.append('--resume')
        with log.open('a',encoding='utf-8') as stream:
            proc=subprocess.Popen(cmd,cwd=c.ROOT,stdout=stream,stderr=subprocess.STDOUT,
                env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','OMP_NUM_THREADS':'4',
                     'OPENBLAS_NUM_THREADS':'4','MKL_NUM_THREADS':'4','TEMP':str(c.OUT/'temp'),'TMP':str(c.OUT/'temp')})
            c.atomic_json(c.OUT/'CHILD.json',{'pid':proc.pid,'label':label,'training_log':str(log),'command':cmd})
            c.emit('task_started',label=label,pid=proc.pid,attempt=attempt);code=proc.wait()
        c.emit('task_exit',label=label,exit_code=code,attempt=attempt)
        if code==0:return
    raise RuntimeError('Failed after one identical-configuration retry: '+label)


def train_command(domain,seed,folder=None,smoke=False):
    cmd=[sys.executable,'-u',str(c.ROOT/'capacity_match_training.py'),'--domain',domain,'--seed',str(seed)]
    if folder:cmd+=['--output',str(folder)]
    if smoke:cmd+=['--smoke']
    return cmd


def smoke_tests():
    base=c.OUT/'smoke';full=base/'uninterrupted';resumed=base/'resumed'
    execute(train_command('piraeus',42,full,True),'smoke_uninterrupted',full/'terminal.log')
    if not (resumed/'last.pt').exists():
        execute(train_command('piraeus',42,resumed,True)+['--stop-after-epoch','1'],'smoke_epoch1_stop',resumed/'terminal.log')
    execute(train_command('piraeus',42,resumed,True)+['--resume'],'smoke_epoch_resume',resumed/'terminal.log')
    a=torch.load(full/'last.pt',map_location='cpu',weights_only=False)
    b=torch.load(resumed/'last.pt',map_location='cpu',weights_only=False)
    if a['epoch']!=2 or b['epoch']!=2 or any(k not in b for k in ('amp','rng','optimizer','scheduler')):raise RuntimeError('Resume state incomplete')
    difference=max(float((a['model'][k]-b['model'][k]).abs().max()) for k in a['model'])
    c.atomic_json(base/'RESUME_AUDIT.json',{'complete':True,'epoch':2,'max_model_tensor_difference':difference,
        'bitwise_resume':difference==0,'explicit_rng_amp_optimizer_scheduler_restored':True,
        'cudnn_dropout_hidden_state_may_preclude_bitwise_resume':difference!=0})
    if not c.completed(full,True) or not c.completed(resumed,True):raise RuntimeError('Smoke results incomplete')
    del a,b
    execute([sys.executable,'-u',c.ROOT/'capacity_match_cost.py','--kind','wide_gru','--device','cuda','--smoke'],
        'cost_smoke',base/'cost'/'terminal.log')
    c.table('capacity_smoke.csv',[{'model':'full','value':1},{'model':'wide','value':2,'extra':'union_header'}])
    execute([NODE,c.ROOT/'verify_capacity_csv.mjs',c.OUT,'--smoke'],'CSV_smoke',base/'CSV.log')
    c.atomic_json(c.OUT/'SMOKE_COMPLETE.json',{'complete':True,'CUDA_train_resume_cost_and_CSV':True,'bitwise_resume':difference==0})
    c.emit('smoke_complete',bitwise_resume=difference==0)


def cost_summary():
    rows=[];repeats=[]
    for kind in ('fusion','original_gru','wide_gru','homogeneous_itransformer'):
        for device in ('cuda','cpu'):
            marker=c.OUT/'cost'/f'{kind}_{device}.json'
            if not marker.exists():execute([sys.executable,'-u',c.ROOT/'capacity_match_cost.py','--kind',kind,'--device',device],
                f'cost/{kind}/{device}',marker.with_suffix('.log'))
            for r in c.read(marker)['rows']:
                rows.append({k:v for k,v in r.items() if k!='repeat_measurements'})
                repeats.extend({'model':kind,'device':device,'batch':r['batch'],'scope':r['scope'],**s} for s in r['repeat_measurements'])
    c.table('capacity_cost.csv',rows);c.table('capacity_cost_repeats.csv',repeats)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(7,5),constrained_layout=True)
    for r in rows:
        if r['device']=='cuda' and r['batch']==1 and r['scope']=='model_only':
            ax.scatter(r['parameters']/1e6,r['p50_ms']);ax.annotate(r['model'],(r['parameters']/1e6,r['p50_ms']),fontsize=8)
    ax.set_xlabel('Registered parameters (million)');ax.set_ylabel('GPU batch1 p50 latency (ms)')
    fig.savefig(c.OUT/'capacity_parameter_latency.png',dpi=220);fig.savefig(c.OUT/'capacity_parameter_latency.pdf');plt.close(fig)
    import csv
    with (c.OUT/'capacity_macro.csv').open(encoding='utf-8-sig',newline='') as stream:macro=list(csv.DictReader(stream))
    fig,axes=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
    for name,kind in (('UnifiedInternalMoE','fusion'),('Direct-GRU','original_gru'),('Wide-GRU','wide_gru')):
        value=next(r for r in macro if r['model']==name)
        cost=next(r for r in rows if r['model']==kind and r['device']=='cuda' and r['batch']==1 and r['scope']=='model_only')
        for ax,x in zip(axes,(cost['parameters']/1e6,cost['p50_ms'])):
            ax.errorbar(x,float(value['four_region_equal_macro_J']),yerr=float(value['macro_J_seed_std']),fmt='o',capsize=3)
            ax.annotate(name,(x,float(value['four_region_equal_macro_J'])),fontsize=8)
            ax.set_ylabel('Four-region macro J, mean +/- seed SD (lower better)')
    axes[0].set_xlabel('Registered parameters (million)');axes[1].set_xlabel('DMA seed42 GPU batch1 p50 latency (ms)')
    fig.savefig(c.OUT/'capacity_accuracy_cost.png',dpi=220);fig.savefig(c.OUT/'capacity_accuracy_cost.pdf');plt.close(fig)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');parser.add_argument('--smoke',action='store_true');parser.add_argument('--summary-only',action='store_true');args=parser.parse_args()
    c.OUT.mkdir(parents=True,exist_ok=True);lock=c.FileLock(c.OUT/'campaign.lock')
    if not lock.acquire():raise RuntimeError('Duplicate capacity campaign refused')
    if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        preflight()
        if args.preflight_only:return
        if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable; no CPU training fallback')
        if args.smoke:smoke_tests();return
        if not (c.OUT/'SMOKE_COMPLETE.json').exists():raise RuntimeError('Smoke must pass before formal activation')
        if not (c.OUT/'ACTIVATION.json').exists():c.atomic_json(c.OUT/'ACTIVATION.json',{'started_at':time.strftime('%Y-%m-%d %H:%M:%S'),'runs':40,'estimated_hours':[20,26]})
        c.emit('capacity_campaign_started',GPU=torch.cuda.get_device_name(),runs=40)
        if not args.summary_only:
            for domain,seed in tasks():
                folder=c.run(domain,seed)
                if not c.completed(folder,deep=True):execute(train_command(domain,seed),f'Wide-GRU/{domain}/{seed}',folder/'terminal.log')
                if not c.completed(folder,deep=True):raise RuntimeError('Training exited without all scientific artifacts')
                c.compact_completed(folder)
                c.emit('wide_model_complete',domain=domain,seed=seed,completed=sum(c.completed(c.run(d,s)) for d,s in tasks()),total=40)
        c.atomic_json(c.OUT/'TRAINING_COMPLETE.json',{'complete':True,'runs':40})
        execute([sys.executable,'-u',c.ROOT/'capacity_match_results.py'],'capacity_statistics_and_figures',c.OUT/'summary.log')
        cost_summary()
        execute([NODE,c.ROOT/'verify_capacity_csv.mjs',c.OUT],'capacity_CSV_verification',c.OUT/'CSV_verification.log')
        c.check_frozen(deep=True)
        (c.OUT/'REPORT.md').write_text('# Ten-seed capacity-matched single-model control\n\n'
            'Four regions, ten seeds; Wide-GRU H=1376 has 17,526,696 active predictive parameters versus 17,656,244 registered parameters in the frozen five-expert reference. '
            'Original GRU optimization is unchanged apart from recurrent width. Its checkpoint criterion is validation ADE@60+2 ADE@10, not the SA-only criterion. '
            'Parameter matching does not imply matched FLOPs, latency, staged training budgets or convergence. All negative findings and epoch-limit/convergence flags are retained.\n\n'
            'The original ten-seed shared-validation fusion is preserved; no best-test internal variant was substituted. '
            'Paired uncertainty involving fusion is conditional/descriptive under shared route selection; small-cluster tests are approximate. '
            'Historical test observations remain a limitation. This is not independent external AIS validation.\n\n'
            'Model-only and cached-window-to-metric-output timings are distinct; neither includes raw AIS decoding or network delay. '
            'Cost uses fixed DMA seed42 checkpoints in isolated model/device processes, FP32, 50 warmups and 3x200 synchronized measurements. '
            'All best checkpoints and scientific outputs are retained. Only redundant optimizer checkpoints of accepted new runs were removed under the locked disk policy. '
            'Explicit RNG/AMP/optimizer/scheduler restoration and any cuDNN bitwise differences are documented in smoke/RESUME_AUDIT.json.\n',encoding='utf-8')
        c.atomic_json(c.OUT/'COMPLETE.json',{'complete':True,'finished_at':time.strftime('%Y-%m-%d %H:%M:%S'),'runs':40,'full_revision_complete':False})
        c.emit('capacity_campaign_complete')
    except Exception as exc:
        c.atomic_json(c.OUT/'FAILURE.json',{'time':time.strftime('%Y-%m-%d %H:%M:%S'),'reason':str(exc),'traceback':traceback.format_exc(),'resumable':True})
        c.emit('capacity_campaign_error',reason=str(exc));raise
    finally:
        if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.release()


if __name__=='__main__':main()
