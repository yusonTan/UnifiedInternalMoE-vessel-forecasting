"""Budgeted PLOS revision evidence. Original artifacts are strictly read-only."""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import torch

from amf.data import RobustTrajectoryScaler
from amf.metrics import displacement_metrics
from amf.unified_predictor import UnifiedInternalMoE
from evaluate_compact_committee import build_model, run_path
from run_plos_rigor_suite import atomic_json, write_csv

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "revision_5h_20261009"
OFFICIAL = ROOT / "terminal_unified_v2_3seed_4domain"
DOMAINS = ("dma", "noaa", "norway", "piraeus")
SEEDS = (42, 52, 62)
EXPERTS = UnifiedInternalMoE.expert_order
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def log(event, **kw):
    row = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "event": event, **kw}
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "events.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    print(json.dumps(row, ensure_ascii=False, default=str), flush=True)
    atomic_json(OUT / "STATUS.json", row)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(2**20), b""):
            h.update(chunk)
    return h.hexdigest()


def archive(path, **arrays):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp.npz")
    np.savez_compressed(temporary, **arrays)
    os.replace(temporary, path)


def cache_path(domain, split):
    return ROOT / "cache" / domain / f"{domain}_{split}"


def arrays(domain, split):
    path = cache_path(domain, split)
    return tuple(np.load(path / f"{name}.npy", mmap_mode="r") for name in ("history", "future", "mmsi"))


def source_config(domain, seed):
    return json.loads((OFFICIAL / domain / f"seed_{seed}" / "config.json").read_text(encoding="utf-8"))


def load_final(domain, seed):
    model = UnifiedInternalMoE()
    state = torch.load(OFFICIAL / domain / f"seed_{seed}" / "best.pt", map_location="cpu", weights_only=False)
    model.load_state_dict(state["model"], strict=True)
    return model.to(DEVICE).eval()


def canonical(domain, seed, split):
    return OUT / "canonical" / domain / f"seed_{seed}" / f"{split}.npz"


@torch.inference_mode()
def forward_final(model, history, scaler, capture=True):
    pp, ee = [], []
    for start in range(0, len(history), 16):
        x = torch.from_numpy(scaler.transform_history(np.asarray(history[start:start + 16])).copy()).to(DEVICE)
        if capture:
            y, aux = model(x, return_aux=True)
            ee.append(scaler.inverse_positions(aux["internal_candidates"].cpu().numpy()).astype(np.float32))
        else:
            y = model(x)
        pp.append(scaler.inverse_positions(y.cpu().numpy()).astype(np.float32))
    return np.concatenate(pp), np.concatenate(ee) if capture else None


@torch.inference_mode()
def extra_comparators(domain, seed, history, scaler):
    result = {}
    for name in ("direct_lstm", "tcn_cv"):
        path = run_path(ROOT / "eight_hour_diagnostic", "router_sharp150_cov_0p0", name, domain, seed)
        model = build_model(name, path)
        model.load_state_dict(torch.load(path / "best.pt", map_location="cpu", weights_only=False)["model"])
        model.to(DEVICE).eval()
        batches = []
        for i in range(0, len(history), 64):
            x = torch.from_numpy(scaler.transform_history(np.asarray(history[i:i + 64])).copy()).to(DEVICE)
            batches.append(scaler.inverse_positions(model(x).cpu().numpy()).astype(np.float32))
        result[name] = np.concatenate(batches)
        del model
    return result


def audit():
    rows, manifests = [], []
    for domain in DOMAINS:
        sets = {split: set(np.asarray(arrays(domain, split)[2]).tolist()) for split in ("train", "val", "test")}
        if any(sets[a] & sets[b] for a, b in (("train", "val"), ("train", "test"), ("val", "test"))):
            raise RuntimeError(f"MMSI overlap in {domain}")
        for seed in SEEDS:
            log("audit_run", domain=domain, seed=seed)
            checkpoint = OFFICIAL / domain / f"seed_{seed}" / "best.pt"
            config = source_config(domain, seed)
            scaler = RobustTrajectoryScaler(**config["scaler"])
            model = load_final(domain, seed)
            weights = torch.softmax(model.global_route_logits, dim=0).detach().cpu().numpy().T
            nonzero_head = float(model.router_head[-1].weight.detach().abs().max()) + float(model.router_head[-1].bias.detach().abs().max())
            if nonzero_head != 0:
                raise RuntimeError("The frozen submission is not the expected zero-increment router")
            manifests.append({"domain": domain, "seed": seed, "checkpoint": str(checkpoint), "sha256": digest(checkpoint),
                              "epoch": 0, "short_specialist": config["initialization"]["domain_short_route_plan"]["selected_short_specialist"],
                              "shared_seed_route_selection": True})
            for split in ("val", "test"):
                destination = canonical(domain, seed, split)
                history, future, mmsi = arrays(domain, split)
                if destination.exists():
                    z = np.load(destination)
                    prediction = z["prediction"]
                else:
                    started = time.time()
                    prediction, experts = forward_final(model, history, scaler)
                    target = scaler.inverse_positions(scaler.transform_future(np.asarray(future))).astype(np.float32)
                    repeat, _ = forward_final(model, history[:min(32, len(history))], scaler, capture=False)
                    repeat_difference = float(np.abs(repeat - prediction[:len(repeat)]).max())
                    if repeat_difference > 0.05:
                        raise RuntimeError(f"Nonrepeatable checkpoint {domain}/{seed}: {repeat_difference}")
                    extra = extra_comparators(domain, seed, history, scaler)
                    archive(destination, prediction=prediction, experts=experts, target=target,
                            mmsi=np.asarray(mmsi), window_index=np.arange(len(mmsi)), knot_weights=weights,
                            checkpoint_sha256=np.asarray(digest(checkpoint)), **extra)
                    log("canonical_saved", domain=domain, seed=seed, split=split, samples=len(prediction),
                        seconds=round(time.time() - started, 2), repeat_max_abs_m=repeat_difference)
                z = np.load(destination)
                if not np.array_equal(z["mmsi"], mmsi):
                    raise RuntimeError("Canonical MMSI alignment failed")
                if split == "test":
                    original = np.load(OFFICIAL / domain / f"seed_{seed}" / "test_predictions.npz")
                    raw = original["raw_prediction"] if "raw_prediction" in original else original["prediction"]
                    difference = float(np.abs(prediction - raw).max())
                    truth_difference = float(np.abs(z["target"] - original["target"]).max())
                    metric_difference = max(abs(v - displacement_metrics(raw, original["target"])[k])
                                            for k, v in displacement_metrics(prediction, z["target"]).items())
                    row = {"domain": domain, "seed": seed, "raw_max_abs_m": difference,
                           "truth_max_abs_m": truth_difference, "metric_max_abs_m": metric_difference,
                           "formal_calibration_max_abs_m": float(np.abs(original["prediction"] - raw).max()),
                           "passed": difference <= 0.05 and truth_difference <= 0.05,
                           "committee_difference_reason": "validation-selected short-specialist override changes two anchors; not interchangeable predictors"}
                    committee = ROOT / "eight_hour_diagnostic" / "committee" / domain / f"seed_{seed}" / "test_predictions.npz"
                    if committee.exists():
                        row["committee_max_abs_m"] = float(np.abs(np.load(committee)["prediction"] - prediction).max())
                    else:
                        row["committee_max_abs_m"] = None
                    rows.append(row)
                    write_csv(OUT / "prediction_source_audit.csv", rows)
                    if not row["passed"] or row["formal_calibration_max_abs_m"] > 0.05:
                        raise RuntimeError(f"Formal replay mismatch: {row}; dependent phases blocked")
                # Compare old expert caches, but use only regenerated expert arrays downstream.
                for j, expert in enumerate(EXPERTS):
                    old = (ROOT / "eight_hour_diagnostic" / "committee" / "prediction_cache" / expert / domain / f"seed_{seed}.npz") if split == "val" else (
                        run_path(ROOT / "eight_hour_diagnostic", "router_sharp150_cov_0p0", expert, domain, seed) / "test_predictions.npz")
                    if old.exists():
                        oldz = np.load(old)
                        key = "raw_prediction" if split == "test" and expert == "sa_repair" and "raw_prediction" in oldz else "prediction"
                        log("expert_cache_comparison", domain=domain, seed=seed, split=split, expert=expert,
                            max_abs_m=float(np.abs(oldz[key] - z["experts"][:, j]).max()))
            del model
            if DEVICE.type == "cuda":
                torch.cuda.empty_cache()
    write_csv(OUT / "checkpoint_manifest.csv", manifests)
    atomic_json(OUT / "audit_COMPLETE.json", {"complete": True, "runs": len(rows), "tolerance_m": 0.05,
                                              "prediction_source": "frozen final checkpoint replay", "rows": rows})


def protocol():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "PROTOCOL.json"
    if not path.exists():
        atomic_json(path, {"created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "deadline_unix": time.time() + 5 * 3600,
                          "domains": DOMAINS, "seeds": SEEDS, "new_backbone_training": False,
                          "expert_source": str(OFFICIAL), "historical_test_previously_observed": True,
                          "new_variant_selection": "MMSI-grouped outer validation, inner epoch/ridge selection; no test selection",
                          "head_types": ["learned_global", "mlp", "gru", "gru_disagreement"],
                          "ridge_grid": [0, .01, .2], "head_epochs": 40, "head_patience": 8,
                          "learning_rate": .001, "weight_decay": .0001, "batch_size": 256,
                          "head_inner_train_seconds_cap": 90, "seed_std_ddof": 1,
                          "replay_absolute_tolerance_m": .05,
                          "scope": "first five-hour evidence batch, not completion of full revision protocol",
                          "retain_validation_macro_improvement": .01, "maximum_regional_validation_degradation": .02})
    return json.loads(path.read_text(encoding="utf-8"))


def campaign():
    spec = protocol()
    # Prevent idle sleep while this process exists; never change permanent power policies.
    if os.name == "nt":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000003)
    budgets = [("audit", 30), ("routing", 80), ("transfer", 60), ("statistics", 35), ("sensitivity", 30), ("engineering", 25)]
    failed = []
    try:
        for phase, minutes in budgets:
            if (OUT / f"{phase}_COMPLETE.json").exists():
                log("phase_resume_skip", phase=phase)
                continue
            remaining = spec["deadline_unix"] - time.time()
            if remaining < 120:
                failed.append({"phase": phase, "reason": "five-hour campaign deadline"})
                continue
            log("phase_started", phase=phase, budget_minutes=minutes, remaining_minutes=round(remaining / 60, 1))
            started = time.time()
            try:
                subprocess.run([sys.executable, "-u", str(Path(__file__).resolve()), "--phase", phase,
                                "--deadline", str(min(spec["deadline_unix"] - 60, time.time() + minutes * 60))],
                               cwd=ROOT, check=True, timeout=min(remaining - 60, minutes * 60 + 30))
                log("phase_finished", phase=phase, elapsed_minutes=round((time.time() - started) / 60, 2))
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
                failed.append({"phase": phase, "reason": str(exc)})
                log("phase_failed", phase=phase, detail=str(exc))
                if phase == "audit":
                    break
        atomic_json(OUT / "CAMPAIGN_RESULT.json", {"finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "complete": not failed and all((OUT / f"{p}_COMPLETE.json").exists() for p, _ in budgets),
                    "failures": failed, "full_revision_complete": False})
        try:
            from revision_5h_analysis import report
            report()
        except Exception:
            traceback.print_exc()
        log("campaign_finished", failures=failed, full_revision_complete=False)
    finally:
        if os.name == "nt":
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", default="campaign")
    parser.add_argument("--deadline", type=float, default=time.time() + 1800)
    args = parser.parse_args()
    torch.set_num_threads(4)
    protocol()
    if args.phase == "campaign":
        campaign()
    elif args.phase == "audit":
        audit()
    else:
        if not (OUT / "audit_COMPLETE.json").exists():
            raise RuntimeError("Formal prediction audit is not complete")
        import revision_5h_analysis as analysis
        getattr(analysis, args.phase)(args.deadline)


if __name__ == "__main__":
    main()
