"""Isolated, parameter-matched Wide-GRU experiment; historical files are read-only."""
from __future__ import annotations
import csv
import json
import os
import time
from pathlib import Path
import numpy as np
from run_revision_10seed import run_of, sha, FileLock
from run_plos_rigor_suite import atomic_json

ROOT = Path(__file__).resolve().parent
OUT = Path('E:/OE_capacity_match_20261015')
MAIN = Path('E:/OE_revision10seed_20261012')
DOMAINS = ('dma', 'noaa', 'norway', 'piraeus')
SEEDS = (42, 52, 62, 72, 82, 92, 102, 112, 122, 132)
MODELS = ('UnifiedInternalMoE', 'Direct-GRU', 'Wide-GRU')
HIDDEN = 1376
METRICS = tuple(f'{k}@{h}' for h in (5, 10, 20, 30, 45, 60) for k in ('ADE', 'FDE'))
NEW_CODE = ('capacity_match_common.py', 'capacity_match_training.py', 'capacity_match_results.py',
            'capacity_match_cost.py', 'run_capacity_match.py', 'verify_capacity_csv.mjs',
            'tests/test_capacity_match.py', 'start_capacity_match.ps1', 'monitor_capacity_match.ps1')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def emit(event, **kw):
    OUT.mkdir(parents=True, exist_ok=True)
    row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, **kw}
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')
    atomic_json(OUT / 'STATUS.json', row)
    print(json.dumps(row, ensure_ascii=False), flush=True)


def table(name, rows):
    if not rows:
        raise ValueError('Cannot report an empty table as completed')
    path = OUT / name; path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(k for r in rows for k in r))
    temporary = path.with_suffix('.csv.tmp')
    with temporary.open('w', encoding='utf-8-sig', newline='') as stream:
        w = csv.DictWriter(stream, fieldnames=fields); w.writeheader(); w.writerows(rows)
    os.replace(temporary, path)


def archive(path, **arrays):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp.npz')
    np.savez_compressed(temporary, **arrays); os.replace(temporary, path)


def run(domain, seed):
    return OUT / 'runs' / domain / f'seed_{seed}'


def config(domain, seed, smoke=False):
    return {'model': 'wide_direct_gru', 'domain': domain, 'seed': seed, 'hidden': HIDDEN,
        'layers': 2, 'head_width': 256, 'dropout': .1, 'input': [90, 6], 'output': [180, 2],
        'parameter_count': 17526696, 'batch_size': 256, 'num_workers': 0, 'CPU_threads': 4,
        'epochs': 2 if smoke else 80, 'patience': 2 if smoke else 20, 'learning_rate': .0005,
        'optimizer': 'AdamW', 'weight_decay': .0001, 'minimum_learning_rate': .000001,
        'scheduler': 'CosineAnnealingLR', 'gradient_clip': 1., 'training_AMP': True,
        'validation_FP32': True, 'loss': 'weighted_huber_first_30_steps_x2',
        'checkpoint_score': 'ADE@60+2*ADE@10', 'smoke': smoke,
        'scaler': read(ROOT / 'cache' / domain / 'scaler.json'),
        'sampling_seconds': 20, 'training_cache_access': 'existing read-only mmap; no build_cache or scaler save',
        'resume_rng_policy': 'save/restore Python, NumPy, Torch CPU/CUDA and AMP; cuDNN state replay audited separately'}


def baseline_archive(domain, seed):
    paths = [MAIN / 'predictions' / 'direct_gru' / domain / f'seed_{seed}.npz']
    paths += [ROOT / p / 'predictions' / 'direct_gru' / domain / f'seed_{seed}.npz'
              for p in ('revision_7h_20261009', 'revision_2h_20261009')]
    digest = sha(run_of('direct_gru', domain, seed) / 'best.pt')
    for p in paths:
        if p.exists():
            with np.load(p) as z:
                if str(z['checkpoint_sha256'].item()) == digest:
                    return p
    raise RuntimeError('No audited cached baseline predictions; never regenerate into historical directories')


def aligned(a, b):
    if not np.array_equal(a['mmsi'], b['mmsi']) or not np.array_equal(a['window_index'], b['window_index']):
        raise RuntimeError('MMSI/window pairing mismatch')
    if a['target'].shape != b['target'].shape or np.max(np.abs(a['target'] - b['target'])) > .05:
        raise RuntimeError('Target pairing mismatch')


def errors(p, y):
    distance = np.linalg.norm(p.astype(np.float64) - y.astype(np.float64), axis=-1)
    return {m: distance[:, :3*int(m.split('@')[1])].mean(1) if m.startswith('ADE')
            else distance[:, 3*int(m.split('@')[1])-1] for m in METRICS}


def score_metrics(m):
    return (m['ADE@5']/20 + m['ADE@10']/50 + 2*m['ADE@60']/600)/4


def completed(folder, deep=False):
    folder = Path(folder)
    if not (folder / 'COMPLETE.json').exists():
        return False
    p = read(folder / 'COMPLETE.json')
    if not p.get('complete'):
        return False
    for name, digest in p['files'].items():
        f = folder / name
        if not f.exists() or (deep and sha(f) != digest):
            raise RuntimeError('Completed run artifact changed: ' + str(f))
    return True


def sources():
    inherited = read(Path('E:/OE_internal_full_20261014/PROTOCOL.json'))['source_hashes']
    return {**{n: sha(ROOT/n) for n in inherited}, **{n: sha(ROOT/n) for n in NEW_CODE}}


def check_frozen(deep=False):
    p = read(OUT / 'PROTOCOL.json')
    if sources() != p['source_hashes']:
        raise RuntimeError('Code changed after protocol lock')
    for name, record in p['frozen_files'].items():
        f = Path(name)
        if f.stat().st_size != record['bytes'] or f.stat().st_mtime_ns != record['mtime_ns'] or (deep and sha(f) != record['sha256']):
            raise RuntimeError('Historical input changed: ' + name)


def compact_completed(folder):
    """Only discard newly generated, redundant optimizer state after full acceptance."""
    folder = Path(folder).resolve()
    allowed = (OUT / 'runs').resolve()
    if not folder.is_relative_to(allowed) or folder == allowed:
        raise RuntimeError('Cleanup outside the exact new training-run tree refused')
    if not completed(folder, deep=True):
        raise RuntimeError('Cannot compact an incomplete run')
    target = folder / 'last.pt'
    if target.exists():
        atomic_json(folder / 'OPTIMIZER_STATE_COMPACTION.json', {
            'completed_model_preserved': True, 'removed_file': str(target), 'bytes': target.stat().st_size,
            'sha256': sha(target), 'recovery': 'redundant final optimizer state is not retained; best.pt and all scientific outputs remain',
            'time': time.strftime('%Y-%m-%d %H:%M:%S')})
        target.unlink()
        emit('completed_optimizer_state_compacted', domain=folder.parent.name, seed=folder.name)
