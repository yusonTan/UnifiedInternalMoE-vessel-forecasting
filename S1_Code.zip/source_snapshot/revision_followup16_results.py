"""Read-only prior-result comparison and matched internal ablation evidence."""
from __future__ import annotations
import argparse
import csv
import json
import time
from pathlib import Path
import numpy as np
import torch
import revision_2h_results as old
from revision_5h_analysis import sample_error, paired_uncertainty, jscore, route_blend
from run_plos_rigor_suite import write_csv
from run_revision_5h import archive
from revision_followup16_common import *

METRICS = tuple(f'{k}@{h}' for h in (5, 10, 20, 30, 45, 60) for k in ('ADE', 'FDE'))


def remaining(deadline, reserve=0):
    if time.time() + reserve >= deadline:
        raise TimeoutError('Report deadline reached; incremental tables remain available')


def table(path, rows):
    if rows:
        # ADE and FDE have different family-specific Holm columns. Preserve
        # their union rather than deriving the schema from the first row.
        fields = list(dict.fromkeys(key for row in rows for key in row))
        normalized = [{key: row.get(key, '') for key in fields} for row in rows]
        destination = OUT / path
        temporary = destination.with_suffix(destination.suffix + '.tmp')
        try:
            write_csv(temporary, normalized)
            temporary.replace(destination)
        finally:
            # A failed export must leave the previous complete CSV untouched.
            if temporary.exists():
                temporary.unlink()


def csv_rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def check_pair(a, b, id_name='mmsi', target_name='target'):
    if not np.array_equal(a[id_name], b[id_name]):
        raise RuntimeError('Paired MMSI ordering mismatch')
    if a[target_name].shape != b[target_name].shape or np.abs(a[target_name] - b[target_name]).max() > .05:
        raise RuntimeError('Paired targets/order mismatch')


def holm(rows, field='Holm_p'):
    cumulative = 0.
    for rank, row in enumerate(sorted(rows, key=lambda r: r['wild_cluster_t_p'])):
        cumulative = max(cumulative, min(1., (len(rows)-rank)*row['wild_cluster_t_p']))
        row[field] = cumulative


def mean_std(rows, metrics, expected):
    groups, result = {}, []
    for r in rows:
        groups.setdefault((r['domain'], r['model'], r['protocol']), []).append(r)
    for (d, model, protocol), values in sorted(groups.items()):
        row = {'domain': d, 'model': model, 'protocol': protocol, 'n_seeds': len(values),
               'seeds': ';'.join(str(r['seed']) for r in values),
               'all_expected_seeds_complete': {int(r['seed']) for r in values} == set(expected)}
        for metric in metrics:
            v = np.asarray([float(r[metric]) for r in values], dtype=float)
            if not np.isfinite(v).all():
                raise RuntimeError('Nonfinite result table')
            row[metric + '_mean'] = float(v.mean())
            row[metric + '_std'] = float(v.std(ddof=1)) if len(v) > 1 else None
        result.append(row)
    return result


def probability(deadline):
    if not validate_dependency():
        raise RuntimeError('Never compare an unfinished probability campaign')
    rows = [r for r in csv_rows(REFERENCE / 'four_domain_5seed_per_seed.csv')
            if r['protocol'] != 'original_submission_reference_only']
    prob_rows, paired, energy_rows = [], [], []
    for domain in DOMAINS:
        finals, others = {}, {}
        for seed in FIVE_SEEDS:
            remaining(deadline)
            run = DEPENDENCY / domain / f'seed_{seed}'
            result = read(run / 'result.json')
            r = {'domain': domain, 'seed': seed, 'model': 'BLSTM_MDN_adapted',
                 'protocol': 'conditional_mean_validation_NLL_selection', **result['test'], **result['probabilistic']}
            rows.append({k: v for k, v in r.items() if k in ('domain', 'seed', 'model', 'protocol', *METRICS)})
            prob_rows.append(r)
            with np.load(run / 'test_predictions.npz') as z:
                others[seed] = {k: z[k].copy() for k in z.files}
            with np.load(REFERENCE / 'fusion_5seed_refit' / domain / f'seed_{seed}' / 'test_predictions.npz') as z:
                finals[seed] = {k: z[k].copy() for k in z.files}
            check_pair(finals[seed], others[seed])
        for kind in ('ADE', 'FDE'):
            for horizon in (5, 10, 60):
                remaining(deadline)
                metric = f'{kind}@{horizon}'
                ours = np.stack([sample_error(finals[s]['prediction'], finals[s]['target'], metric) for s in FIVE_SEEDS])
                other = np.stack([sample_error(others[s]['prediction'], others[s]['target'], metric) for s in FIVE_SEEDS])
                paired.append({'domain': domain, 'metric': metric, 'n_seeds': 5,
                    'comparison_predeclared': 'BLSTM_MDN_adapted minus UnifiedInternalMoE_5seed_refit',
                    'fusion_mean_m': float(ours.mean()), 'MDN_conditional_mean_m': float(other.mean()),
                    **paired_uncertainty(other - ours, finals[42]['mmsi'],
                                          np.random.default_rng(16000 + len(paired)), draws=10000)})
                table('probability_vs_final_paired_uncertainty.csv', paired)
        for horizon in (5, 10, 60):
            remaining(deadline)
            step = horizon * 3
            ours = np.stack([np.sqrt(np.mean((finals[s]['prediction'][:, :step].astype(float)
                                - finals[s]['target'][:, :step].astype(float))**2, axis=(1, 2))) for s in FIVE_SEEDS])
            other = np.stack([others[s][f'energy_RMS_meters@{horizon}'] for s in FIVE_SEEDS])
            energy_rows.append({'domain': domain, 'horizon_min': horizon, 'n_seeds': 5,
                'fusion_energy_RMS_m': float(ours.mean()), 'MDN_energy_RMS_m': float(other.mean()),
                'deterministic_predictor_interpretation': 'Dirac distribution; no predictive interval claimed',
                **paired_uncertainty(other - ours, finals[42]['mmsi'],
                                      np.random.default_rng(17000 + len(energy_rows)), draws=10000)})
        table('comparison_all_models_5seed_per_seed.csv', rows)
        table('probability_only_per_seed.csv', prob_rows)
        emit('probability_report_domain_complete', domain=domain)
    for kind in ('ADE', 'FDE'):
        holm([r for r in paired if r['metric'].startswith(kind)], f'{kind}_12cell_Holm_p')
    holm(energy_rows, 'energy_12cell_Holm_p')
    table('probability_vs_final_paired_uncertainty.csv', paired)
    table('probability_vs_final_energy_score.csv', energy_rows)
    table('comparison_all_models_5seed_mean_std.csv', mean_std(rows, METRICS, FIVE_SEEDS))
    table('probability_only_mean_std.csv', mean_std(prob_rows, (*METRICS, *read(DEPENDENCY / 'dma/seed_42/result.json')['probabilistic']), FIVE_SEEDS))
    # CV is deterministic: copy one value per region, never manufacture five seeds/std.
    table('CV15_deterministic_reference.csv', csv_rows(REFERENCE / 'CV15_four_domain_metrics.csv'))
    atomic(OUT / 'PROBABILITY_COMPARISON_COMPLETE.json', {'complete': len(prob_rows) == 20,
        'primary_paired_ADE_cells': 12, 'secondary_paired_FDE_cells': 12,
        'energy_cells': 12, 'bootstrap_draws': 10000,
        'probability_baseline': 'Sensors 2022 common-task BLSTM-MDN adaptation, not exact original reproduction',
        'conditional_mean_not_oracle_in_primary_comparison': True,
        'marginal_coordinate_coverage_not_joint_trajectory_coverage': True,
        'routing_selection_shared_across_seeds': True})


def load_record(path):
    with np.load(path) as z:
        return {k: z[k].copy() for k in z.files}


def collect_sa(item, deadline):
    remaining(deadline, 20)
    run = selected_run(item, 'repair')
    validate_config(item, run, 'repair')
    tag = 'SA_matched_' + item['variant']
    old_path = PREVIOUS / 'predictions' / tag / item['domain'] / f"seed_{item['seed']}.npz"
    if run == existing_run(item, 'repair') and old_path.exists():
        z = load_record(old_path)
        if str(z['checkpoint_sha256'].item()) == sha(run / 'best.pt'):
            return z
    # Isolated child process sets only the destination global. Prior outputs stay untouched.
    old.OUT, old.DEVICE = OUT, torch.device('cuda')
    handle = old.collect('sa_repair', run, item['domain'], item['seed'], tag=tag)
    try:
        return {k: handle[k].copy() for k in handle.files}
    finally:
        handle.close()


def other_record(name, domain, seed):
    for folder in (REFERENCE, PREVIOUS):
        path = folder / 'predictions' / name / domain / f'seed_{seed}.npz'
        if path.exists():
            record = load_record(path)
            checkpoint = Path(str(record['source_checkpoint'].item()))
            if sha(checkpoint) != str(record['checkpoint_sha256'].item()):
                raise RuntimeError('Frozen expert prediction cache changed relative to its checkpoint')
            return record
    raise FileNotFoundError(f'Missing frozen expert predictions: {name}/{domain}/{seed}')


def ablations(deadline):
    torch.set_num_threads(4)
    rows, fusion_rows, missing, provenance = [], [], [], []
    cohorts = [('primary3', DOMAINS, SEEDS, PRIMARY), ('secondary5', SMALL, FIVE_SEEDS, VARIANTS)]
    # A complete optional uniform-router cohort is reported separately as a 3-seed control.
    _, _, optional = plan()
    if all(finished(selected_run(i, 'repair')) for i in optional):
        cohorts.append(('uniform3', DOMAINS, SEEDS, ('full', 'uniform_router')))
    for cohort, domains, seeds, variants in cohorts:
        for domain in domains:
            for variant in variants:
                records, loaded = {}, {}
                for seed in seeds:
                    remaining(deadline, 20)
                    item = unit(variant, domain, seed, cohort)
                    run = selected_run(item, 'repair')
                    if not finished(run):
                        missing.append({**item, 'cohort': cohort})
                        continue
                    z = collect_sa(item, deadline)
                    loaded[seed] = z
                    selected_epoch = read(run / 'test_metrics.json')['selected_epoch']
                    rows.append(old.metric_row(domain, seed, variant, cohort, z['test_prediction'], z['test_target'],
                                               z['val_prediction'], z['val_target'], selected_epoch))
                    provenance.append({'cohort': cohort, 'domain': domain, 'seed': seed, 'variant': variant,
                        'run': str(run), 'pretraining_run': str(selected_run(item, 'pretraining')),
                        'checkpoint_sha256': sha(run / 'best.pt'), 'reused': run == existing_run(item, 'repair')})
                    records[seed] = {'sa_repair': z}
                    for name in old.EXPERTS[1:]:
                        records[seed][name] = other_record(name, domain, seed)
                        for split in ('val', 'test'):
                            check_pair(z, records[seed][name], split + '_MMSI', split + '_target')
                table('SA_internal_ablation_per_seed.csv', rows)
                table('SA_internal_training_provenance.csv', provenance)
                if set(records) != set(seeds):
                    continue  # No re-routing on a successful-seeds-only subset.
                remaining(deadline, 60)
                weights, selection = old.fit_fusion_group(records, seeds, domain)
                directory = OUT / 'fusion_ablation' / cohort / domain / variant
                atomic(directory / 'VALIDATION_SELECTION_LOCK.json', selection)
                for seed in seeds:
                    pp = {}
                    for split in ('val', 'test'):
                        candidates = np.stack([records[seed][n][split + '_prediction'] for n in old.EXPERTS], axis=1)
                        pp[split] = route_blend(candidates, {'steps': [15, 30, 180], 'weights': weights[seed]})
                        archive(directory / f'seed_{seed}' / f'{split}_predictions.npz', prediction=pp[split],
                                target=loaded[seed][split + '_target'], mmsi=loaded[seed][split + '_MMSI'],
                                window_index=loaded[seed][split + '_window_index'])
                    fusion_rows.append(old.metric_row(domain, seed, variant, cohort,
                        pp['test'], loaded[seed]['test_target'], pp['val'], loaded[seed]['val_target'], 0))
                table('fusion_SA_internal_ablation_per_seed.csv', fusion_rows)
                emit('ablation_cohort_domain_variant_reported', cohort=cohort, domain=domain, variant=variant)
    aggregated, fusion_aggregated, paired = [], [], []
    for cohort, domains, seeds, variants in cohorts:
        for family, values, destination in (('SA_only', rows, aggregated), ('whole_fusion', fusion_rows, fusion_aggregated)):
            subset = [r for r in values if r['protocol'] == cohort]
            destination.extend(mean_std(subset, ('validation_J', 'test_J', *METRICS), seeds))
            for domain in domains:
                for variant in variants:
                    if variant == 'full':
                        continue
                    pairs = [(next((r for r in subset if r['domain'] == domain and r['seed'] == s and r['model'] == 'full'), None),
                              next((r for r in subset if r['domain'] == domain and r['seed'] == s and r['model'] == variant), None)) for s in seeds]
                    pairs = [(a, b) for a, b in pairs if a is not None and b is not None]
                    if not pairs:
                        continue
                    r = {'family': family, 'cohort': cohort, 'domain': domain, 'variant': variant,
                         'matched_seed_pairs': len(pairs), 'complete_cohort': len(pairs) == len(seeds)}
                    for metric in ('test_J', 'ADE@5', 'ADE@10', 'ADE@60', 'FDE@60'):
                        delta = np.array([b[metric] - a[metric] for a, b in pairs])
                        r[metric + '_delta_ablated_minus_full'] = float(delta.mean())
                        r[metric + '_delta_std'] = float(delta.std(ddof=1)) if len(delta) > 1 else None
                        r[metric + '_relative_change_percent'] = float(100 * delta.mean() / np.mean([a[metric] for a, b in pairs]))
                    paired.append(r)
    table('SA_internal_ablation_mean_std.csv', aggregated)
    table('fusion_SA_internal_ablation_mean_std.csv', fusion_aggregated)
    table('SA_internal_ablation_paired_changes.csv', paired)
    macro = []
    for family, values in (('SA_only', rows), ('whole_fusion', fusion_rows)):
        for variant in PRIMARY:
            selected = [r for r in values if r['protocol'] == 'primary3' and r['model'] == variant]
            if len(selected) != 12:
                continue
            macro.append({'family': family, 'variant': variant, 'regions': 4, 'seeds': 3,
                'four_region_macro_J': float(np.mean([r['test_J'] for r in selected])),
                'J_has_no_physical_unit': True, 'macro_weights': 'equal region weights; 1/1/2 normalized ADE horizons'})
    for r in macro:
        full = next((x for x in macro if x['family'] == r['family'] and x['variant'] == 'full'), None)
        if full:
            r['relative_change_vs_full_percent'] = 100 * (r['four_region_macro_J'] / full['four_region_macro_J'] - 1)
    table('four_region_primary_ablation_macro.csv', macro)
    summary = {'complete': not any(r['cohort'] == 'primary3' for r in missing)
                        and len([r for r in fusion_rows if r['protocol'] == 'primary3']) == 36,
        'primary_expected_models': 36, 'primary_reported_models': len([r for r in rows if r['protocol'] == 'primary3']),
        'secondary_complete': not any(r['cohort'] == 'secondary5' for r in missing), 'missing': missing,
        'seven_ablation_four_domain_five_seed_complete': False,
        'matched_component_disabled_in_both_training_stages': True,
        'whole_fusion_routes_refitted_using_validation_only': True,
        'unfavorable_results_retained': True, 'source_provenance_csv': 'SA_internal_training_provenance.csv'}
    atomic(OUT / 'ABLATION_REPORT_STATUS.json', summary)
    lines = ['# 16小时接续实验报告', '',
        f"四域三种子核心消融：{'完成' if summary['complete'] else '未完整完成'}。",
        f"小域五种子扩展消融：{'完成' if summary['secondary_complete'] else '部分完成'}。", '',
        '核心消融为完整SA、去DCA、去门控密集/样条残差；去残差仍保留独立intent终点修正。',
        'DMA、NOAA所有核心变体（含完整版）均从随机初始化重新训练；小域复用已经核验的同协议训练。',
        '所有结果按原始输出报告，不使用CV3后校准来替换指标。完整版不必在所有指标上获胜。',
        '整体融合用相同其他四个专家和同一验证集选择规则重新拟合；它不同于单独SA的内部消融。',
        '五种子概率对照使用条件均值；min-of-K仅为补充，不列入确定性精度主排名。',
        '共享验证集路由选择下的种子区间是条件性/描述性证据，不能声称完全独立的路由选择。', '',
        '未完成项仍包括完整十种子、全四域五种子七项内部消融、独立外部AIS源和容量匹配GRU。',
        '本脚本没有根据测试结果剔除变体、重复训练或修改超参数。', '', '## 四域宏观目标（无物理单位）', '']
    lines += [f"- {r['family']} / {r['variant']}: J={r['four_region_macro_J']:.6f}, Δ={r.get('relative_change_vs_full_percent', 0):+.3f}%" for r in macro]
    (OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('probability', 'ablations'), required=True)
    parser.add_argument('--deadline', type=float, required=True)
    args = parser.parse_args()
    if args.phase == 'probability':
        probability(args.deadline)
    else:
        ablations(args.deadline)
