"""Complete the locked ten-seed cohort, without a wall-clock training cut-off."""
from __future__ import annotations
import argparse
import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
import numpy as np
import torch
import run_revision_7h as previous
from run_revision_2h import sha, set_arg, sa_args as small_sa_args
from run_plos_rigor_suite import atomic_json

ROOT = Path(__file__).resolve().parent
OUT = Path('E:/OE_revision10seed_20261012')
DOMAINS = previous.DOMAINS
MODELS = previous.MODELS
REUSED = (42, 52, 62, 72, 82)
NEW = (92, 102, 112, 122, 132)
SEEDS = REUSED + NEW
CODE = ('run_revision_10seed.py', 'revision_10seed_results.py',
        'revision_seed_comparator_training.py', 'revision_followup16_training.py',
        'run_revision_7h.py', 'run_revision_2h.py', 'revision_2h_results.py',
        'train.py', 'amf/trainer.py', 'train_comparison_model.py',
        'train_faithful_sota.py', 'amf/adaptive_moe.py',
        'amf/unified_predictor.py', 'evaluate_compact_committee.py',
        'revision_5h_analysis.py', 'verify_revision10_csv.mjs',
        'comparison_models.py', 'faithful_sota_models.py', 'amf/data.py',
        'amf/metrics.py', 'run_revision_5h.py', 'run_complete_study_stage.py')


def log(event, **values):
    OUT.mkdir(parents=True, exist_ok=True)
    row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, **values}
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
    atomic_json(OUT / 'STATUS.json', row)
    print(json.dumps(row, ensure_ascii=False, default=str), flush=True)


def run_of(model, domain, seed):
    if seed in REUSED:
        return previous.run_of(model, domain, seed)
    if seed not in NEW:
        raise ValueError(f'Unexpected seed: {seed}')
    if model == 'sa_repair':
        return OUT / 'SA_seed_repair' / domain / f'seed_{seed}'
    family = 'faithful_sota' if 'faithful' in model else 'runs'
    return OUT / 'comparisons' / family / model / domain / f'seed_{seed}'


def sa_args(domain, seed, stage):
    output = OUT / ('SA_seed_pretraining' if stage == 'pretrain' else 'SA_seed_repair')
    predecessor = OUT / 'SA_seed_pretraining' / domain / f'seed_{seed}' / 'best.pt'
    if domain in previous.BIG:
        args = previous.sa_args(domain, seed, output, stage, predecessor)
    else:
        args = small_sa_args(domain, seed, 'full', output, stage, predecessor)
    set_arg(args, '--cache-dir', ROOT / 'cache')
    set_arg(args, '--num-workers', 0)
    return args


def tasks():
    # Balanced seed layers; no seed admission or stopping decision uses accuracy.
    for seed in NEW:
        for domain in DOMAINS:
            for model in MODELS:
                if model == 'sa_repair':
                    for stage in ('pretrain', 'repair'):
                        args = sa_args(domain, seed, stage)
                        run = Path(args[args.index('--output-dir') + 1]) / domain / f'seed_{seed}'
                        yield {'label': f'SA_{stage}/{domain}/{seed}', 'model': model,
                               'domain': domain, 'seed': seed, 'stage': stage,
                               'entry': 'revision_followup16_training.py', 'args': args,
                               'run': run, 'marker': run / 'test_metrics.json'}
                else:
                    script = 'train_faithful_sota' if 'faithful' in model else 'train_comparison_model'
                    run = run_of(model, domain, seed)
                    yield {'label': f'{model}/{domain}/{seed}', 'model': model,
                           'domain': domain, 'seed': seed, 'stage': 'train',
                           'entry': 'revision_seed_comparator_training.py',
                           'args': ['--script', script, '--model', model, '--domain', domain,
                                    '--seed', str(seed), '--output-root', str(OUT / 'comparisons'),
                                    '--num-workers', '0'], 'run': run, 'marker': run / 'result.json'}


def valid_run(run, marker=None):
    marker = marker or (run / ('test_metrics.json' if 'SA_seed' in str(run) or 'repairs' in str(run) else 'result.json'))
    if not all(p.exists() for p in (run / 'best.pt', run / 'config.json', marker)):
        return False
    try:
        payload = json.loads(marker.read_text(encoding='utf-8'))
        test = payload.get('test', payload.get('raw', payload))
        return all(np.isfinite(float(test[k])) for k in ('ADE@5', 'ADE@10', 'ADE@60', 'FDE@60'))
    except (ValueError, KeyError, TypeError):
        return False


def marker_for(model, run):
    return run / ('test_metrics.json' if model == 'sa_repair' else 'result.json')


def complete_seeds():
    return tuple(s for s in SEEDS if all(valid_run(run_of(m, d, s), marker_for(m, run_of(m, d, s)))
                                        for d in DOMAINS for m in MODELS))


def preflight():
    OUT.mkdir(parents=True, exist_ok=True)
    if OUT.resolve().drive == ROOT.resolve().drive:
        raise RuntimeError('New outputs must not consume the almost-full D drive')
    free = shutil.disk_usage(OUT).free
    if free < 12 * 1024**3:
        raise RuntimeError('Need at least 12 GiB on output drive before starting')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; CPU fallback is prohibited')
    codes = {name: sha(ROOT / name) for name in CODE}
    data_manifest, sources = [], []
    for domain in DOMAINS:
        groups = []
        for split in ('train', 'val', 'test'):
            base = ROOT / 'cache' / domain / f'{domain}_{split}'
            h, y, ids = [np.load(base / f'{n}.npy', mmap_mode='r') for n in ('history', 'future', 'mmsi')]
            if h.shape[1:] != (90, 6) or y.shape[1:] != (180, 2) or not len(h) == len(y) == len(ids):
                raise RuntimeError(f'Invalid cache dimensions: {base}')
            groups.append(set(map(int, np.unique(ids))))
            data_manifest.append({'domain': domain, 'split': split, 'windows': len(ids),
                                  'MMSI_groups': len(groups[-1]),
                                  'files': {str(base / f'{n}.npy'): sha(base / f'{n}.npy')
                                            for n in ('history', 'future', 'mmsi')}})
        if any(groups[a] & groups[b] for a, b in ((0, 1), (0, 2), (1, 2))):
            raise RuntimeError(f'MMSI overlap in {domain}')
        scaler = ROOT / 'cache' / domain / 'scaler.json'
        sources.append({'path': str(scaler), 'sha256': sha(scaler)})
        for seed in REUSED:
            for model in MODELS:
                run = run_of(model, domain, seed)
                if not valid_run(run, marker_for(model, run)):
                    raise RuntimeError(f'Incomplete reusable source: {run}')
                for file in ('best.pt', 'config.json'):
                    p = run / file
                    sources.append({'path': str(p), 'sha256': sha(p)})
    spec = {'version': 1, 'seeds': SEEDS, 'new_seeds': NEW, 'domains': DOMAINS,
            'models': MODELS, 'new_backbones': 140, 'new_training_subtasks': 160,
            'SA_repair_time_caps': {'dma': 600, 'noaa': 600, 'norway': 240, 'piraeus': 240},
            'CPU_threads': 4, 'loader_workers': 0, 'sample_std_ddof': 1,
            'fusion': 'same compact subset/ridge plus shared validation short-specialist rule',
            'independent_per_seed_route': 'sensitivity only, no test-based main-model replacement',
            'historical_test_previously_observed': True, 'test_used_for_new_selection': False,
            'probability_comparator_seeds_unchanged': list(REUSED),
            'time_policy': 'finish all ten seeds; no global 17-hour truncation',
            'estimate_hours': [19, 21], 'data': data_manifest, 'sources': sources,
            'code_sha256': codes}
    lock = OUT / 'PROTOCOL.json'
    if lock.exists():
        if json.loads(lock.read_text(encoding='utf-8')) != json.loads(json.dumps(spec)):
            raise RuntimeError('Frozen protocol/source/code changed; do not silently resume')
    else:
        atomic_json(lock, spec)
    atomic_json(OUT / 'PREFLIGHT.json', {'complete': True, 'time': time.strftime('%Y-%m-%d %H:%M:%S'),
                                      'CUDA': torch.cuda.get_device_name(), 'free_output_GiB': free / 1024**3,
                                      'reused_backbone_runs': 140, 'MMSI_disjoint': True})
    log('preflight_complete', free_GiB=round(free / 1024**3, 2), reused_backbones=140)


class FileLock:
    def __init__(self, path):
        self.path, self.file = Path(path), None

    def acquire(self):
        import msvcrt
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open('a+b')
        if self.path.stat().st_size == 0:
            self.file.write(b'0')
            self.file.flush()
        self.file.seek(0)
        try:
            msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            self.file.close()
            self.file = None
            return False

    def release(self):
        if self.file:
            import msvcrt
            self.file.seek(0)
            msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            self.file.close()
            self.file = None


def execute(item, smoke=False):
    if valid_run(item['run'], item['marker']):
        log('task_resume_skip', label=item['label'])
        return True
    if not smoke and shutil.disk_usage(OUT).free < 3 * 1024**3:
        raise RuntimeError('Output drive has less than 3 GiB; preserve checkpoints and stop')
    run = item['run']
    run.mkdir(parents=True, exist_ok=True)
    for attempt in (1, 2):
        args = list(item['args'])
        if (run / 'last.pt').exists():
            args.append('--resume')
        command = [sys.executable, '-u', str(ROOT / item['entry']), *args]
        log('task_started', label=item['label'], attempt=attempt, training_log=str(run / 'terminal.log'))
        started = time.time()
        with (run / 'terminal.log').open('a', encoding='utf-8') as stream:
            child = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            atomic_json(OUT / 'CHILD.json', {'pid': child.pid, 'label': item['label'], 'command': command,
                                           'training_log': str(run / 'terminal.log')})
            result = child.wait()
        if result == 0 and valid_run(run, item['marker']):
            log('task_completed', label=item['label'], seconds=round(time.time() - started, 2), attempt=attempt)
            return True
        log('task_failed', label=item['label'], returncode=result, attempt=attempt)
    return False


def smoke_tasks():
    smoke = OUT / 'smoke'
    for script, model in (('train_comparison_model', 'direct_gru'), ('train_faithful_sota', 'mstformer_faithful')):
        family = 'faithful_sota' if 'faithful' in model else 'runs'
        run = smoke / 'comparisons' / family / model / 'piraeus' / 'seed_92'
        yield {'label': 'smoke/' + model, 'run': run, 'marker': run / 'result.json',
               'entry': 'revision_seed_comparator_training.py',
               'args': ['--script', script, '--model', model, '--domain', 'piraeus', '--seed', '92',
                        '--output-root', str(smoke / 'comparisons'), '--num-workers', '0', '--quick-smoke']}
    for stage in ('pretrain', 'repair'):
        args = sa_args('piraeus', 92, stage)
        output = smoke / ('SA_seed_pretraining' if stage == 'pretrain' else 'SA_seed_repair')
        set_arg(args, '--output-dir', output)
        if stage == 'repair':
            set_arg(args, '--init-checkpoint', smoke / 'SA_seed_pretraining/piraeus/seed_92/best.pt')
        args.append('--quick-smoke')
        run = output / 'piraeus/seed_92'
        yield {'label': 'smoke/SA_' + stage, 'run': run, 'marker': run / 'test_metrics.json',
               'entry': 'revision_followup16_training.py', 'args': args}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--summary-only', action='store_true')
    args = parser.parse_args()
    lock = FileLock(OUT / 'campaign.lock')
    if not lock.acquire():
        raise RuntimeError('Ten-seed campaign already running; duplicate launch refused')
    if os.name == 'nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    failure = None
    try:
        preflight()
        if args.preflight_only:
            return
        if args.smoke:
            for item in smoke_tasks():
                if not execute(item, smoke=True):
                    raise RuntimeError(f'Smoke failed: {item["label"]}')
            atomic_json(OUT / 'SMOKE_COMPLETE.json', {'complete': True, 'four_training_entry_points': True})
            log('smoke_complete')
            return
        if not (OUT / 'SMOKE_COMPLETE.json').exists():
            raise RuntimeError('Run --smoke before production training')
        atomic_json(OUT / 'WORKER.json', {'pid': os.getpid(), 'python': sys.executable})
        log('campaign_started', target_seeds=SEEDS, new_backbones=140, training_subtasks=160)
        if not args.summary_only:
            for item in tasks():
                if not execute(item):
                    raise RuntimeError(f'Failed twice: {item["label"]}; inspect its training log')
        chosen = complete_seeds()
        atomic_json(OUT / 'TRAINING_COMPLETE.json', {'complete': chosen == SEEDS, 'seeds': chosen})
        if chosen != SEEDS:
            raise RuntimeError(f'Incomplete ten-seed cohort: {chosen}')
        log('summary_started', seeds=SEEDS)
        with (OUT / 'summary.log').open('a', encoding='utf-8') as stream:
            result = subprocess.run([sys.executable, '-u', str(ROOT / 'revision_10seed_results.py')],
                                    cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'Summary failed ({result.returncode}); resume with --summary-only')
        atomic_json(OUT / 'CAMPAIGN_RESULT.json', {'complete': True, 'seeds': SEEDS,
                    'finished_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'full_revision_complete': False})
        log('campaign_complete', seeds=SEEDS)
    except Exception as exc:
        failure = str(exc)
        atomic_json(OUT / 'CAMPAIGN_RESULT.json', {'complete': False, 'error': failure,
                    'finished_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'full_revision_complete': False})
        log('campaign_error', detail=failure)
        raise
    finally:
        if os.name == 'nt':
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        lock.release()


if __name__ == '__main__':
    main()
