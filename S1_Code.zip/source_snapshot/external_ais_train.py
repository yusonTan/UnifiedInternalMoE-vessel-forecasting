"""Independent external training. Actual test arrays are not opened here."""
from __future__ import annotations
import argparse
import gc
import os
import time
import numpy as np
import torch
from torch.amp import GradScaler,autocast
from torch.utils.data import DataLoader,Subset
import external_ais_common as c
from amf.data import EnvShipDataset,RobustTrajectoryScaler
from amf.adaptive_moe import IntentMultiScaleMoE
from amf.metrics import displacement_metrics,weighted_huber
from amf.trainer import seed_everything
from comparison_models import MODEL_SPECS,build_comparison_model
from faithful_sota_models import FAITHFUL_SPECS,build_faithful_model
from revision_followup16_training import snapshot_rng,restore_rng

def save(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp.pt');torch.save(obj,tmp);os.replace(tmp,p)

def spec(name,stage='train'):
    if name=='sa_repair':
        return {'epochs':120 if stage=='pretrain' else 60,'patience':24 if stage=='pretrain' else 12,
            'lr':1e-4 if stage=='pretrain' else 2e-5,'batch_size':256,'accumulation':1,'optimizer':'AdamW',
            'minimum_lr':5e-7,'selection_score':'ade60','repair_seconds':0 if stage=='pretrain' else 600}
    if name in FAITHFUL_SPECS:
        s=FAITHFUL_SPECS[name]
        return {k:s[k] for k in ('epochs','patience','lr','batch_size','accumulation','optimizer')}|{'minimum_lr':1e-6,'selection_score':'legacy'}
    s=MODEL_SPECS[name]
    return {'epochs':80,'patience':20,'lr':s['lr'],'batch_size':s['batch_size'],'accumulation':1,'optimizer':'AdamW','minimum_lr':1e-6,'selection_score':'legacy'}

def build(name,stage='train'):
    if name=='sa_repair':return IntentMultiScaleMoE(v6_variant='joint_aligned_intent_spline',
        component_ablation='full' if stage=='pretrain' else 'router_sharp150',router_temperature_override=1. if stage=='pretrain' else 1.5)
    return build_faithful_model(name) if name in FAITHFUL_SPECS else build_comparison_model(name)

def run_dir(name,seed,stage='train',smoke=False):
    return c.OUT/('smoke' if smoke else 'training')/name/f'seed_{seed}'/stage

def loaders(scaler,batch,smoke=False):
    out={}
    for split in ('train','val'):
        dataset=EnvShipDataset(c.OUT/'cache'/split,scaler)
        if smoke:dataset=Subset(dataset,range(min(len(dataset),64 if split=='train' else 32)))
        out[split]=DataLoader(dataset,batch_size=batch,shuffle=split=='train',num_workers=0,pin_memory=True)
    return out

@torch.inference_mode()
def evaluate(model,loader,scaler,sa=False):
    model.eval();pp=[];yy=[];ids=[]
    for x,y,m in loader:
        p=model(x.cuda());pp.append(p.float().cpu().numpy());yy.append(y.numpy());ids.append(np.asarray(m))
    p=scaler.inverse_positions(np.concatenate(pp));y=scaler.inverse_positions(np.concatenate(yy))
    return displacement_metrics(p,y),p.astype(np.float32),y.astype(np.float32),np.concatenate(ids)

def train_sa(seed,stage,smoke=False):
    import amf.trainer as trainer
    folder=run_dir('sa_repair',seed,stage,smoke);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'COMPLETE.json').exists():return
    seed_everything(seed);scaler=RobustTrajectoryScaler.load(c.OUT/'cache/scaler.json');s=spec('sa_repair',stage)
    if smoke:s={**s,'epochs':1,'patience':1,'batch_size':16,'repair_seconds':0}
    model=build('sa_repair',stage).cuda()
    if stage=='repair':
        model.load_state_dict(torch.load(run_dir('sa_repair',seed,'pretrain',smoke)/'best.pt',map_location='cpu',weights_only=False)['model'],strict=True)
    config={'model':'sa_repair','domain':'independent_finland','seed':seed,'stage':stage,'scaler':scaler.__dict__,
        'v6_variant':'joint_aligned_intent_spline','component_ablation':'full' if stage=='pretrain' else 'router_sharp150',
        'router_temperature_override':1. if stage=='pretrain' else 1.5,'training_protocol':s,
        'actual_test_not_loaded':True,'stage_test_files_are_validation_proxy_only':True,'no_cv3_calibration_used_in_formal_results':True}
    c.atomic_json(folder/'config.json',config)
    original_load=trainer.torch.load;original_save=trainer._atomic_torch_save;original_amp=trainer.GradScaler;amp={}
    last=folder/'last.pt';prior=original_load(last,map_location='cpu',weights_only=False) if last.exists() else None
    elapsed=float(prior.get('external_elapsed_seconds',0)) if prior else 0.;started=time.monotonic()
    def make_amp(*a,**kw):obj=original_amp(*a,**kw);amp['scaler']=obj;return obj
    def atomic(payload,path):
        if path.name=='last.pt':payload={**payload,'external_rng':snapshot_rng(),'external_AMP':amp['scaler'].state_dict(),'external_elapsed_seconds':elapsed+time.monotonic()-started}
        original_save(payload,path)
    def load(path,*a,**kw):
        obj=original_load(path,*a,**kw)
        if prior is not None and not hasattr(path,'read') and os.fspath(path)==os.fspath(last):
            restore_rng(obj['external_rng']);amp['scaler'].load_state_dict(obj['external_AMP'])
        return obj
    trainer.GradScaler=make_amp;trainer._atomic_torch_save=atomic;trainer.torch.load=load
    try:
        ls=loaders(scaler,s['batch_size'],smoke);epochs=s['epochs'];cap=s['repair_seconds']
        if prior and (prior['stale']>=s['patience'] or prior['epoch']>=epochs or (cap and elapsed>=cap)):epochs=prior['epoch']
        trainer.train_model(model,ls['train'],ls['val'],ls['val'],scaler,torch.device('cuda'),folder,
            epochs=epochs,learning_rate=s['lr'],min_learning_rate=s['minimum_lr'],patience=s['patience'],
            max_training_seconds=max(.001,cap-elapsed) if cap else 0.,coverage_weight=0.,velocity_weight=.08,
            acceleration_weight=.02,heading_weight=.008,anchor_weight=.08,tail_weight=1.,intent_weight=.05,
            alignment_weight=.005,curvature_weight=.002,selection_score='ade60',resume=prior is not None)
        c.atomic_json(folder/'VALIDATION_PROXY_NOTICE.json',{'actual_external_test_never_opened':True,
            'legacy_trainer_test_filenames_in_this_stage_contain_validation_only':True,
            'formal_independent_test_results_are_only_in_evaluation_directory':True})
    finally:
        trainer.GradScaler=original_amp;trainer._atomic_torch_save=original_save;trainer.torch.load=original_load
    val,p,y,ids=evaluate(model,ls['val'],scaler,True)
    c.archive(folder/'validation_predictions.npz',prediction=p,target=y,mmsi=ids,window_index=np.arange(len(ids)))
    c.atomic_json(folder/'COMPLETE.json',{'complete':True,'seconds':elapsed+time.monotonic()-started,'actual_test_not_used':True,
        'best_sha256':c.sha(folder/'best.pt'),'validation':val})
    c.emit('external_training_stage_complete',model='sa_repair',seed=seed,stage=stage,smoke=smoke)

def train_comparator(name,seed,smoke=False):
    folder=run_dir(name,seed,'train',smoke);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'COMPLETE.json').exists():return
    seed_everything(seed)
    if name in FAITHFUL_SPECS or name=='tcn_cv':
        torch.backends.cudnn.deterministic=False;torch.backends.cudnn.benchmark=True
    s=spec(name)
    if smoke:s={**s,'epochs':1,'patience':1,'batch_size':min(s['batch_size'],16)}
    scaler=RobustTrajectoryScaler.load(c.OUT/'cache/scaler.json');ls=loaders(scaler,s['batch_size'],smoke)
    model=build(name).cuda();optimizer=(torch.optim.Adam if s['optimizer']=='Adam' else torch.optim.AdamW)(model.parameters(),lr=s['lr'],weight_decay=1e-4)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=s['epochs'],eta_min=s['minimum_lr']);amp=GradScaler('cuda')
    best=float('inf');stale=0;start_epoch=1;elapsed=0.;last=folder/'last.pt'
    if last.exists():
        old=torch.load(last,map_location='cpu',weights_only=False);model.load_state_dict(old['model']);optimizer.load_state_dict(old['optimizer']);scheduler.load_state_dict(old['scheduler']);amp.load_state_dict(old['AMP']);restore_rng(old['rng'])
        best,stale,start_epoch,elapsed=old['best_score'],old['stale'],old['epoch']+1,old['elapsed_seconds']
    c.atomic_json(folder/'config.json',{'model':name,'domain':'independent_finland','seed':seed,'scaler':scaler.__dict__,
        'training_protocol':s,'actual_test_not_loaded':True,'parameter_count':sum(p.numel() for p in model.parameters())})
    started=time.monotonic()
    if stale>=s['patience']:start_epoch=s['epochs']+1
    for epoch in range(start_epoch,s['epochs']+1):
        model.train();optimizer.zero_grad(set_to_none=True);loss_sum=seen=0;begin=time.monotonic()
        for i,(x,y,_) in enumerate(ls['train'],1):
            with autocast(device_type='cuda'):
                pred=model(x.cuda());loss=weighted_huber(pred,y.cuda())/s['accumulation']
            if not torch.isfinite(loss):raise RuntimeError('Nonfinite external training loss')
            amp.scale(loss).backward()
            if i%s['accumulation']==0 or i==len(ls['train']):
                amp.unscale_(optimizer);torch.nn.utils.clip_grad_norm_(model.parameters(),1.);amp.step(optimizer);amp.update();optimizer.zero_grad(set_to_none=True)
            loss_sum+=float(loss.detach())*s['accumulation']*len(x);seen+=len(x)
        val,_,_,_=evaluate(model,ls['val'],scaler);score=val['ADE@60']+2*val['ADE@10']
        if score<best-1e-6:best,stale=score,0;save(folder/'best.pt',{'model':model.state_dict(),'epoch':epoch,'score':score})
        else:stale+=1
        scheduler.step();record={'epoch':epoch,'train_loss':loss_sum/seen,'score':score,'stale':stale,'seconds':time.monotonic()-begin,**{'val_'+k:v for k,v in val.items()}}
        with (folder/'training.jsonl').open('a',encoding='utf-8') as f:f.write(__import__('json').dumps(record)+'\n')
        print(__import__('json').dumps(record),flush=True)
        save(last,{'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scheduler':scheduler.state_dict(),'AMP':amp.state_dict(),
            'rng':snapshot_rng(),'epoch':epoch,'best_score':best,'stale':stale,'elapsed_seconds':elapsed+time.monotonic()-started})
        if stale>=s['patience']:break
    best_state=torch.load(folder/'best.pt',map_location='cpu',weights_only=False);model.load_state_dict(best_state['model'])
    val,p,y,ids=evaluate(model,ls['val'],scaler)
    c.archive(folder/'validation_predictions.npz',prediction=p,target=y,mmsi=ids,window_index=np.arange(len(ids)))
    c.atomic_json(folder/'COMPLETE.json',{'complete':True,'seconds':elapsed+time.monotonic()-started,'selected_epoch':best_state['epoch'],
        'best_sha256':c.sha(folder/'best.pt'),'validation':val,'actual_test_not_used':True})
    c.emit('external_training_stage_complete',model=name,seed=seed,stage='train',smoke=smoke)

def main():
    a=argparse.ArgumentParser();a.add_argument('--model',choices=c.BACKBONES,required=True);a.add_argument('--seed',type=int,choices=c.SEEDS,required=True)
    a.add_argument('--stage',choices=('train','pretrain','repair'),default='train');a.add_argument('--smoke',action='store_true');args=a.parse_args()
    torch.set_num_threads(4);torch.set_num_interop_threads(2)
    if not torch.cuda.is_available():raise RuntimeError('CUDA required; no silent CPU fallback')
    if args.model=='sa_repair':train_sa(args.seed,args.stage,args.smoke)
    else:train_comparator(args.model,args.seed,args.smoke)

if __name__=='__main__':main()
