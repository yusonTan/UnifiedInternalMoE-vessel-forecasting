from __future__ import annotations

import math

import torch
from torch import nn

from .adaptive_moe import IntentMultiScaleMoE


class HeterogeneousSingleMoE(IntentMultiScaleMoE):
    """One-checkpoint heterogeneous MoE distilled from committee behaviour.

    The original SA-MoE remains the safe core.  Three small internal adapters
    add the inductive biases exposed by the committee study: a recurrent
    correction, an inverted-variable long-horizon mixer, and a short-horizon
    manoeuvre correction.  There is no domain id and no external model at
    inference time.
    """

    internal_expert_names = ("SA-Core", "GRU-Residual", "Long-Variable", "Manoeuvre")
    internal_variants = ("full", "no_gru", "no_long", "no_manoeuvre", "core_only")

    def __init__(
        self,
        *args,
        long_width: int = 48,
        recurrent_width: int = 64,
        internal_variant: str = "full",
        **kwargs,
    ):
        if internal_variant not in self.internal_variants:
            raise ValueError(f"Unknown heterogeneous internal variant: {internal_variant}")
        kwargs.setdefault("v6_variant", "joint_aligned_intent_spline")
        kwargs.setdefault("component_ablation", "adaptive_sharp150")
        super().__init__(*args, **kwargs)
        self.internal_variant = internal_variant
        active = {
            "full": (True, True, True, True),
            "no_gru": (True, False, True, True),
            "no_long": (True, True, False, True),
            "no_manoeuvre": (True, True, True, False),
            "core_only": (True, False, False, False),
        }[internal_variant]
        self.register_buffer("internal_active_mask", torch.tensor(active, dtype=torch.bool))
        representation_size = 128 + 6
        knot_count = len(self.knot_steps)

        # This adapter consumes the shared LSTM sequence; it is not a second
        # complete trajectory encoder.
        self.recurrent_adapter = nn.GRU(
            128, recurrent_width, num_layers=1, batch_first=True
        )
        self.recurrent_head = nn.Sequential(
            nn.Linear(recurrent_width + representation_size, 96),
            nn.GELU(),
            nn.Linear(96, knot_count * 2),
        )

        # Inverted attention mixes six variables, not 90 global time tokens.
        # It recovers the long-horizon bias seen in the NOAA committee without
        # restoring the discarded global temporal-attention block.
        self.long_temporal_projection = nn.Linear(90, long_width)
        self.long_variable_embedding = nn.Parameter(torch.zeros(1, 6, long_width))
        long_layer = nn.TransformerEncoderLayer(
            d_model=long_width,
            nhead=4,
            dim_feedforward=long_width * 2,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.long_variable_mixer = nn.TransformerEncoder(
            long_layer, num_layers=1, norm=nn.LayerNorm(long_width)
        )
        self.long_head = nn.Sequential(
            nn.Linear(6 * long_width + representation_size, 128),
            nn.GELU(),
            nn.Linear(128, knot_count * 2),
        )

        self.manoeuvre_head = nn.Sequential(
            nn.Linear(representation_size, 96),
            nn.GELU(),
            nn.Linear(96, knot_count * 2),
        )

        # Residual magnitudes at the six knots are rotation invariant and give
        # the router a direct disagreement/confidence signal.
        router_features = representation_size + 3 * knot_count
        self.internal_router = nn.Sequential(
            nn.Linear(router_features, 96),
            nn.GELU(),
            nn.Linear(96, len(self.internal_expert_names) * knot_count),
        )
        self.internal_release = nn.Sequential(
            nn.Linear(representation_size, 32),
            nn.GELU(),
            nn.Linear(32, knot_count),
        )
        self._initialize_internal_heads()

    def _initialize_internal_heads(self) -> None:
        nn.init.normal_(self.long_variable_embedding, std=0.02)
        for head in (self.recurrent_head, self.long_head, self.manoeuvre_head):
            nn.init.zeros_(head[-1].weight)
            nn.init.zeros_(head[-1].bias)
        nn.init.zeros_(self.internal_router[-1].weight)
        knot_count = len(self.knot_steps)
        # Start from a safe core-heavy router.  Long and manoeuvre priors vary
        # smoothly with horizon, but all added candidates are exact no-ops at
        # initialization so a warm-started checkpoint is preserved.
        initial = torch.stack(
            (
                torch.full((knot_count,), 2.0),
                torch.full((knot_count,), -0.8),
                torch.linspace(-2.0, -0.4, knot_count),
                torch.linspace(-0.4, -2.0, knot_count),
            )
        )
        with torch.no_grad():
            self.internal_router[-1].bias.copy_(initial.reshape(-1))
        nn.init.zeros_(self.internal_release[-1].weight)
        nn.init.constant_(self.internal_release[-1].bias, -1.5)

    def _residual_from_knots(self, points: torch.Tensor) -> torch.Tensor:
        return self._interpolate(points.transpose(1, 2)).transpose(1, 2)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        core_prediction, aux = super().forward(history, return_aux=True)
        representation = aux["shared_representation"]
        sequence = aux["shared_sequence"]
        local_history = aux["local_history"]
        batch = history.shape[0]
        knot_count = len(self.knot_steps)

        recurrent_sequence, _ = self.recurrent_adapter(sequence)
        recurrent_points = self.recurrent_head(
            torch.cat((recurrent_sequence[:, -1], representation), dim=-1)
        ).view(batch, knot_count, 2)
        recurrent_residual = self._residual_from_knots(recurrent_points)

        variable_tokens = self.long_temporal_projection(
            local_history.transpose(1, 2)
        ) + self.long_variable_embedding
        variable_tokens = self.long_variable_mixer(variable_tokens).flatten(1)
        long_points = self.long_head(
            torch.cat((variable_tokens, representation), dim=-1)
        ).view(batch, knot_count, 2)
        long_residual = self._residual_from_knots(long_points)

        manoeuvre_points = self.manoeuvre_head(representation).view(batch, knot_count, 2)
        manoeuvre_residual = self._residual_from_knots(manoeuvre_points)

        steps = torch.arange(
            1, self.prediction_steps + 1,
            dtype=history.dtype, device=history.device,
        )
        long_profile = (steps / float(self.prediction_steps)).pow(1.5).view(1, -1, 1)
        manoeuvre_profile = torch.exp(
            -torch.relu(steps - 30.0) / 45.0
        ).view(1, -1, 1)
        long_residual = long_profile * long_residual
        manoeuvre_residual = manoeuvre_profile * manoeuvre_residual

        local_residuals = torch.stack(
            (recurrent_residual, long_residual, manoeuvre_residual), dim=1
        )
        global_residuals = self._to_global(
            local_residuals,
            aux["frame_origin"],
            aux["frame_cosine"],
            aux["frame_sine"],
            add_origin=False,
        )
        internal_candidates = torch.cat(
            (
                core_prediction[:, None],
                core_prediction[:, None] + global_residuals,
            ),
            dim=1,
        )

        knot_index = torch.tensor(
            [step - 1 for step in self.knot_steps],
            dtype=torch.long,
            device=history.device,
        )
        disagreement = torch.linalg.vector_norm(
            local_residuals.index_select(2, knot_index), dim=-1
        ).flatten(1).detach()
        router_input = torch.cat((representation, torch.log1p(disagreement)), dim=-1)
        knot_logits = self.internal_router(router_input).view(
            batch, len(self.internal_expert_names), knot_count
        )
        knot_logits = knot_logits.masked_fill(
            ~self.internal_active_mask.view(1, -1, 1), -1e4
        )
        raw_knot_weights = torch.softmax(knot_logits, dim=1)

        raw_entropy = -(
            raw_knot_weights * torch.log(raw_knot_weights.clamp_min(1e-8))
        ).sum(dim=1) / math.log(float(len(self.internal_expert_names)))
        confidence = 1.0 - raw_entropy.detach()
        learned_release = torch.sigmoid(self.internal_release(representation))
        effective_release = learned_release * (0.5 + 0.5 * confidence)
        core_prior = torch.zeros_like(raw_knot_weights)
        core_prior[:, 0] = 1.0
        knot_weights = core_prior + effective_release[:, None] * (
            raw_knot_weights - core_prior
        )
        internal_weights = self._interpolate(knot_weights)
        prediction = torch.sum(
            internal_weights.unsqueeze(-1) * internal_candidates, dim=1
        )
        if not return_aux:
            return prediction

        aux.update(
            {
                "core_prediction": core_prediction,
                "internal_candidates": internal_candidates,
                "internal_expert_weights": internal_weights,
                "internal_raw_knot_weights": raw_knot_weights,
                "internal_knot_weights": knot_weights,
                "internal_release": effective_release,
                "internal_disagreement": disagreement.view(batch, 3, knot_count),
                "internal_active_mask": self.internal_active_mask,
                "internal_branch_roles": ("recurrent", "long", "manoeuvre"),
            }
        )
        return prediction, aux


class SlimLongHorizonMoE(IntentMultiScaleMoE):
    """Pruned single model containing only the useful long-horizon adapter."""

    internal_expert_names = ("SA-Core", "Long-Variable")

    def __init__(
        self,
        *args,
        long_width: int = 48,
        release_scale: float = 1.0,
        **kwargs,
    ):
        if release_scale <= 0.0:
            raise ValueError("release_scale must be positive")
        kwargs.setdefault("v6_variant", "joint_aligned_intent_spline")
        kwargs.setdefault("component_ablation", "adaptive_sharp150")
        super().__init__(*args, **kwargs)
        self.release_scale = float(release_scale)
        representation_size = 128 + 6
        knot_count = len(self.knot_steps)

        self.long_temporal_projection = nn.Linear(90, long_width)
        self.long_variable_embedding = nn.Parameter(torch.zeros(1, 6, long_width))
        layer = nn.TransformerEncoderLayer(
            d_model=long_width,
            nhead=4,
            dim_feedforward=long_width * 2,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.long_variable_mixer = nn.TransformerEncoder(
            layer, num_layers=1, norm=nn.LayerNorm(long_width)
        )
        self.long_head = nn.Sequential(
            nn.Linear(6 * long_width + representation_size, 128),
            nn.GELU(),
            nn.Linear(128, knot_count * 2),
        )
        self.internal_router = nn.Sequential(
            nn.Linear(representation_size + knot_count, 64),
            nn.GELU(),
            nn.Linear(64, len(self.internal_expert_names) * knot_count),
        )
        self.internal_release = nn.Sequential(
            nn.Linear(representation_size, 32),
            nn.GELU(),
            nn.Linear(32, knot_count),
        )
        self.register_buffer(
            "internal_active_mask", torch.ones(2, dtype=torch.bool)
        )
        self._initialize_slim_heads()

    def _initialize_slim_heads(self) -> None:
        nn.init.normal_(self.long_variable_embedding, std=0.02)
        nn.init.zeros_(self.long_head[-1].weight)
        nn.init.zeros_(self.long_head[-1].bias)
        nn.init.zeros_(self.internal_router[-1].weight)
        knot_count = len(self.knot_steps)
        initial = torch.stack(
            (
                torch.full((knot_count,), 1.5),
                torch.linspace(-1.8, 0.2, knot_count),
            )
        )
        with torch.no_grad():
            self.internal_router[-1].bias.copy_(initial.reshape(-1))
        nn.init.zeros_(self.internal_release[-1].weight)
        nn.init.constant_(self.internal_release[-1].bias, -1.5)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        core_prediction, aux = super().forward(history, return_aux=True)
        representation = aux["shared_representation"]
        local_history = aux["local_history"]
        batch = history.shape[0]
        knot_count = len(self.knot_steps)

        variable_tokens = self.long_temporal_projection(
            local_history.transpose(1, 2)
        ) + self.long_variable_embedding
        variable_tokens = self.long_variable_mixer(variable_tokens).flatten(1)
        long_points = self.long_head(
            torch.cat((variable_tokens, representation), dim=-1)
        ).view(batch, knot_count, 2)
        long_residual = self._interpolate(
            long_points.transpose(1, 2)
        ).transpose(1, 2)
        steps = torch.arange(
            1, self.prediction_steps + 1,
            dtype=history.dtype,
            device=history.device,
        )
        long_residual = (
            (steps / float(self.prediction_steps)).pow(1.5).view(1, -1, 1)
            * long_residual
        )
        global_long_residual = self._to_global(
            long_residual,
            aux["frame_origin"],
            aux["frame_cosine"],
            aux["frame_sine"],
            add_origin=False,
        )
        candidates = torch.stack(
            (core_prediction, core_prediction + global_long_residual), dim=1
        )

        knot_index = torch.tensor(
            [step - 1 for step in self.knot_steps],
            dtype=torch.long,
            device=history.device,
        )
        disagreement = torch.linalg.vector_norm(
            long_residual.index_select(1, knot_index), dim=-1
        ).detach()
        router_input = torch.cat(
            (representation, torch.log1p(disagreement)), dim=-1
        )
        logits = self.internal_router(router_input).view(batch, 2, knot_count)
        raw_knot_weights = torch.softmax(logits, dim=1)
        entropy = -(
            raw_knot_weights * torch.log(raw_knot_weights.clamp_min(1e-8))
        ).sum(dim=1) / math.log(2.0)
        confidence = 1.0 - entropy.detach()
        learned_release = (
            self.release_scale * torch.sigmoid(self.internal_release(representation))
        ).clamp_max(1.0)
        effective_release = learned_release * (0.5 + 0.5 * confidence)
        core_prior = torch.zeros_like(raw_knot_weights)
        core_prior[:, 0] = 1.0
        knot_weights = core_prior + effective_release[:, None] * (
            raw_knot_weights - core_prior
        )
        weights = self._interpolate(knot_weights)
        prediction = torch.sum(weights.unsqueeze(-1) * candidates, dim=1)
        if not return_aux:
            return prediction
        aux.update(
            {
                "core_prediction": core_prediction,
                "internal_candidates": candidates,
                "internal_expert_weights": weights,
                "internal_raw_knot_weights": raw_knot_weights,
                "internal_knot_weights": knot_weights,
                "internal_release": effective_release,
                "internal_disagreement": disagreement[:, None],
                "internal_active_mask": self.internal_active_mask,
                "internal_branch_roles": ("long",),
            }
        )
        return prediction, aux
