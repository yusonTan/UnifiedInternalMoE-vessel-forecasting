from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F

from .model import MotionDescriptors, TSKFuzzyGate


def _logit(probability: float) -> float:
    return math.log(probability / (1.0 - probability))


class AdaptivePhysicsExperts(nn.Module):
    """Physics experts whose acceleration persistence is inferred per trajectory."""

    def __init__(self, prediction_steps: int = 180):
        super().__init__()
        self.prediction_steps = prediction_steps

    @staticmethod
    def _cv(positions: torch.Tensor, window: int, horizon: torch.Tensor) -> torch.Tensor:
        velocity = torch.diff(positions[:, -window:], dim=1).mean(dim=1)
        return positions[:, -1:] + horizon * velocity[:, None]

    def forward(
        self,
        positions: torch.Tensor,
        tau: torch.Tensor,
        clip_ratio: torch.Tensor,
    ) -> torch.Tensor:
        dtype, device = positions.dtype, positions.device
        steps = torch.arange(1, self.prediction_steps + 1, dtype=dtype, device=device)
        horizon = steps.view(1, -1, 1)
        cv3 = self._cv(positions, 3, horizon)
        cv6 = self._cv(positions, 6, horizon)
        cv15 = self._cv(positions, 15, horizon)

        displacement = torch.diff(positions[:, -6:], dim=1)
        velocity = displacement[:, -3:].mean(dim=1)
        acceleration = 0.5 * (displacement[:, -1] - displacement[:, -3])
        acceleration_norm = torch.linalg.vector_norm(acceleration, dim=-1, keepdim=True)
        velocity_norm = torch.linalg.vector_norm(velocity, dim=-1, keepdim=True)
        acceleration_cap = clip_ratio * velocity_norm
        acceleration = acceleration * torch.clamp(
            acceleration_cap / (acceleration_norm + 1e-8), max=1.0
        )
        decay = torch.exp(-steps[None, :] / tau).unsqueeze(-1)
        dca_velocity = velocity[:, None] + decay * acceleration[:, None]
        dca = positions[:, -1:] + torch.cumsum(dca_velocity, dim=1)
        return torch.stack((cv3, cv6, cv15, dca), dim=1)


class AdaptiveHorizonMoE(nn.Module):
    """Domain-agnostic, sample- and horizon-adaptive physics/neural predictor.

    The network receives no domain identifier. Positions are translated and rotated
    to a trajectory-local frame, the router mixes physics experts at six horizon
    knots, and a monotone gate controls when the neural residual may override the
    physics prior.
    """

    knot_steps = (15, 30, 60, 90, 135, 180)
    expert_names = ("CV3", "CV6", "CV15", "AdaptiveDCA")
    variants = (
        "full",
        "no_local_frame",
        "fixed_dynamics",
        "uniform_router",
        "no_residual_gate",
    )

    def __init__(
        self,
        input_size: int = 6,
        hidden_size: int = 128,
        prediction_steps: int = 180,
        dropout: float = 0.1,
        tau_range: tuple[float, float] = (3.0, 120.0),
        clip_ratio_range: tuple[float, float] = (0.05, 0.80),
        variant: str = "full",
    ):
        super().__init__()
        if variant not in self.variants:
            raise ValueError(f"Unknown AdaptiveHorizonMoE variant: {variant}")
        self.prediction_steps = prediction_steps
        self.tau_range = tau_range
        self.clip_ratio_range = clip_ratio_range
        self.variant = variant
        self.encoder = nn.LSTM(
            input_size,
            hidden_size,
            num_layers=2,
            batch_first=True,
            dropout=dropout,
        )
        self.descriptors = MotionDescriptors()
        representation_size = hidden_size + 6
        self.dynamics_head = nn.Sequential(
            nn.Linear(representation_size, 32),
            nn.GELU(),
            nn.Linear(32, 2),
        )
        self.router = nn.Sequential(
            nn.Linear(representation_size, 64),
            nn.GELU(),
            nn.Linear(64, len(self.expert_names) * len(self.knot_steps)),
        )
        self.residual = nn.Sequential(
            nn.Linear(representation_size, 128),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(128, prediction_steps * 2),
        )
        self.residual_gate = nn.Sequential(
            nn.Linear(representation_size, 32),
            nn.GELU(),
            nn.Linear(32, len(self.knot_steps) + 1),
        )
        self.experts = AdaptivePhysicsExperts(prediction_steps)
        self._initialize_heads()

    def _initialize_heads(self) -> None:
        nn.init.zeros_(self.router[-1].weight)
        nn.init.zeros_(self.router[-1].bias)
        nn.init.zeros_(self.residual[-1].weight)
        nn.init.zeros_(self.residual[-1].bias)
        nn.init.zeros_(self.dynamics_head[-1].weight)
        tau_probability = (30.0 - self.tau_range[0]) / (self.tau_range[1] - self.tau_range[0])
        clip_probability = (0.20 - self.clip_ratio_range[0]) / (
            self.clip_ratio_range[1] - self.clip_ratio_range[0]
        )
        with torch.no_grad():
            self.dynamics_head[-1].bias.copy_(
                torch.tensor((_logit(tau_probability), _logit(clip_probability)))
            )
        nn.init.zeros_(self.residual_gate[-1].weight)
        nn.init.zeros_(self.residual_gate[-1].bias)

    @staticmethod
    def _local_frame(positions: torch.Tensor):
        origin = positions[:, -1:, :]
        recent_velocity = torch.diff(positions[:, -6:], dim=1).mean(dim=1)
        speed = torch.linalg.vector_norm(recent_velocity, dim=-1, keepdim=True)
        cosine = torch.where(speed > 1e-7, recent_velocity[:, :1] / speed, torch.ones_like(speed))
        sine = torch.where(speed > 1e-7, recent_velocity[:, 1:] / speed, torch.zeros_like(speed))
        centered = positions - origin
        local_x = centered[..., :1] * cosine[:, None] + centered[..., 1:] * sine[:, None]
        local_y = -centered[..., :1] * sine[:, None] + centered[..., 1:] * cosine[:, None]
        return torch.cat((local_x, local_y), dim=-1), origin, cosine, sine

    @staticmethod
    def _to_global(
        local: torch.Tensor,
        origin: torch.Tensor,
        cosine: torch.Tensor,
        sine: torch.Tensor,
        add_origin: bool,
    ) -> torch.Tensor:
        broadcast_shape = (local.shape[0],) + (1,) * (local.ndim - 2) + (1,)
        cosine = cosine.reshape(broadcast_shape)
        sine = sine.reshape(broadcast_shape)
        global_x = local[..., :1] * cosine - local[..., 1:] * sine
        global_y = local[..., :1] * sine + local[..., 1:] * cosine
        result = torch.cat((global_x, global_y), dim=-1)
        if add_origin:
            origin_shape = (origin.shape[0],) + (1,) * (local.ndim - 2) + (2,)
            result = result + origin[:, 0].reshape(origin_shape)
        return result

    def _interpolate(self, knot_values: torch.Tensor) -> torch.Tensor:
        dtype, device = knot_values.dtype, knot_values.device
        query = torch.arange(1, self.prediction_steps + 1, dtype=dtype, device=device)
        knots = torch.tensor(self.knot_steps, dtype=dtype, device=device)
        right = torch.searchsorted(knots, query, right=False).clamp(max=len(self.knot_steps) - 1)
        left = (right - 1).clamp(min=0)
        x0, x1 = knots[left], knots[right]
        ratio = torch.where(x1 > x0, (query - x0) / (x1 - x0), torch.zeros_like(query))
        left_values = knot_values.index_select(-1, left)
        right_values = knot_values.index_select(-1, right)
        expand = (1,) * (knot_values.ndim - 1) + (-1,)
        return left_values + ratio.view(expand) * (right_values - left_values)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        positions = history[..., :2]
        if self.variant == "no_local_frame":
            local_positions = positions
            origin = torch.zeros_like(positions[:, -1:])
            cosine = torch.ones_like(positions[:, -1, :1])
            sine = torch.zeros_like(positions[:, -1, :1])
            local_history = history
        else:
            local_positions, origin, cosine, sine = self._local_frame(positions)
            local_history = torch.cat((local_positions, history[..., 2:]), dim=-1)
        encoded, _ = self.encoder(local_history)
        descriptor_values = self.descriptors(local_positions)
        representation = torch.cat((encoded[:, -1], descriptor_values), dim=-1)

        dynamics = torch.sigmoid(self.dynamics_head(representation))
        tau = self.tau_range[0] + (self.tau_range[1] - self.tau_range[0]) * dynamics[:, :1]
        clip_ratio = self.clip_ratio_range[0] + (
            self.clip_ratio_range[1] - self.clip_ratio_range[0]
        ) * dynamics[:, 1:]
        if self.variant == "fixed_dynamics":
            tau = torch.full_like(tau, 30.0)
            clip_ratio = torch.full_like(clip_ratio, 0.20)
        local_candidates = self.experts(local_positions, tau, clip_ratio)

        knot_logits = self.router(representation).view(
            -1, len(self.expert_names), len(self.knot_steps)
        )
        expert_weights = torch.softmax(self._interpolate(knot_logits), dim=1)
        if self.variant == "uniform_router":
            expert_weights = torch.full_like(expert_weights, 1.0 / len(self.expert_names))
        local_prior = torch.sum(expert_weights.unsqueeze(-1) * local_candidates, dim=1)

        local_residual = self.residual(representation).view(-1, self.prediction_steps, 2)
        gate_parameters = self.residual_gate(representation)
        base = -4.0 + 1.5 * torch.tanh(gate_parameters[:, :1])
        increments = F.softplus(gate_parameters[:, 1:])
        knot_gate = torch.sigmoid(base + torch.cumsum(increments, dim=-1))
        residual_strength = self._interpolate(knot_gate[:, None]).squeeze(1)
        if self.variant == "no_residual_gate":
            residual_strength = torch.ones_like(residual_strength)
        local_prediction = local_prior + residual_strength.unsqueeze(-1) * local_residual

        prediction = self._to_global(local_prediction, origin, cosine, sine, add_origin=True)
        if not return_aux:
            return prediction
        candidates = self._to_global(local_candidates, origin, cosine, sine, add_origin=True)
        prior = self._to_global(local_prior, origin, cosine, sine, add_origin=True)
        residual = self._to_global(local_residual, origin, cosine, sine, add_origin=False)
        return prediction, {
            "prior": prior,
            "residual": residual,
            "candidates": candidates,
            "expert_weights": expert_weights,
            "rule_weights": expert_weights.mean(dim=-1),
            "descriptors": descriptor_values,
            "residual_gate": residual_strength,
            "adaptive_tau": tau,
            "adaptive_clip_ratio": clip_ratio,
        }

    @property
    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())


class IntentMultiScaleMoE(AdaptiveHorizonMoE):
    """A-MoE v6 with zero-init multi-scale context and implicit endpoint intent.

    Every v6 variant is checkpoint-compatible with the original A-MoE.  The new
    branches start as exact zero corrections, allowing safe warm-started ablations.
    """

    v6_variants = (
        "multiscale", "intent", "joint", "joint_aligned_intent",
        "joint_aligned_intent_ctrv", "joint_aligned_intent_spline",
        "joint_aligned_intent_horizon_scale", "joint_aligned_intent_anchor_residual",
    )

    component_ablations = (
        "full", "no_local_frame", "single_scale", "no_descriptors",
        "fixed_dynamics", "uniform_router", "no_dca", "cv3_only",
        "no_residual", "ungated_residual", "no_spline", "no_intent",
        "tau_cap80", "dca_cap55", "residual_cap50", "guarded_router",
        "tau_max180", "tau_max240", "residual_boost125", "residual_boost150",
        "router_sharp125", "router_sharp150", "adaptive_sharp150",
        "add_temporal_attention", "add_tsk",
    )

    def __init__(
        self, *args, v6_variant: str = "joint",
        component_ablation: str = "full", router_temperature_override: float | None = None, **kwargs,
    ):
        if v6_variant not in self.v6_variants:
            raise ValueError(f"Unknown v6 variant: {v6_variant}")
        if component_ablation not in self.component_ablations:
            raise ValueError(f"Unknown component ablation: {component_ablation}")
        super().__init__(*args, variant="full", **kwargs)
        self.v6_variant = v6_variant
        self.component_ablation = component_ablation
        if router_temperature_override is not None and router_temperature_override <= 0:
            raise ValueError("router_temperature_override must be positive")
        self.router_temperature_override = router_temperature_override
        self.scale_windows = (15, 30, 90)
        self.scale_branches = nn.ModuleList(
            nn.Sequential(
                nn.Conv1d(6, 32, kernel_size=3, padding=1),
                nn.GELU(),
                nn.Conv1d(32, 32, kernel_size=3, padding=1),
                nn.GELU(),
            )
            for _ in self.scale_windows
        )
        self.scale_projection = nn.Sequential(
            nn.Linear(32 * len(self.scale_windows), 128),
            nn.GELU(),
            nn.Linear(128, 128),
        )
        self.intent_correction = nn.Sequential(
            nn.Linear(128 + 6, 64),
            nn.GELU(),
            nn.Linear(64, 2),
        )
        self.intent_release = nn.Sequential(
            nn.Linear(128 + 6, 32),
            nn.GELU(),
            nn.Linear(32, 1),
        )
        if self.v6_variant == "joint_aligned_intent_ctrv":
            # Keep the original 4x6 router checkpoint-compatible.  CTRV gets a
            # separate, initially suppressed logit instead of resizing it.
            self.expert_names = (*self.expert_names, "CTRV")
            self.turn_router = nn.Sequential(
                nn.Linear(128 + 6, 32),
                nn.GELU(),
                nn.Linear(32, len(self.knot_steps)),
            )
        if self.v6_variant == "joint_aligned_intent_spline":
            self.spline_residual = nn.Sequential(
                nn.Linear(128 + 6, 64),
                nn.GELU(),
                nn.Linear(64, len(self.knot_steps) * 2),
            )
        if self.v6_variant == "joint_aligned_intent_anchor_residual":
            self.anchor_residual = nn.Sequential(
                nn.Linear(128 + 6, 128),
                nn.GELU(),
                nn.Dropout(kwargs.get("dropout", 0.1)),
                nn.Linear(128, len(self.knot_steps) * 2),
            )
        if self.v6_variant == "joint_aligned_intent_horizon_scale":
            self.horizon_scale_gate = nn.Sequential(
                nn.Linear(128 + 6, 64),
                nn.GELU(),
                nn.Linear(64, len(self.knot_steps) * len(self.scale_windows)),
            )
            self.horizon_router_delta = nn.Sequential(
                nn.Linear(32, 32),
                nn.GELU(),
                nn.Linear(32, len(self.expert_names)),
            )
        if self.component_ablation == "add_temporal_attention":
            self.temporal_attention = nn.Linear(128, 1)
        if self.component_ablation == "add_tsk":
            self.tsk_router = TSKFuzzyGate(
                input_dim=6,
                rules=8,
                output_dim=len(self.expert_names) * len(self.knot_steps),
            )
        with torch.no_grad():
            nn.init.zeros_(self.scale_projection[-1].weight)
            nn.init.zeros_(self.scale_projection[-1].bias)
            nn.init.zeros_(self.intent_correction[-1].weight)
            nn.init.zeros_(self.intent_correction[-1].bias)
            nn.init.zeros_(self.intent_release[-1].weight)
            self.intent_release[-1].bias.fill_(-3.0)
            if self.v6_variant == "joint_aligned_intent_ctrv":
                nn.init.zeros_(self.turn_router[-1].weight)
                self.turn_router[-1].bias.fill_(-3.0)
            if self.v6_variant == "joint_aligned_intent_spline":
                nn.init.zeros_(self.spline_residual[-1].weight)
                nn.init.zeros_(self.spline_residual[-1].bias)
            if self.v6_variant == "joint_aligned_intent_anchor_residual":
                nn.init.zeros_(self.anchor_residual[-1].weight)
                nn.init.zeros_(self.anchor_residual[-1].bias)
            if self.v6_variant == "joint_aligned_intent_horizon_scale":
                # Uniform scale selection and an exact zero route correction at
                # initialization preserve the aligned-intent baseline.
                nn.init.zeros_(self.horizon_scale_gate[-1].weight)
                nn.init.zeros_(self.horizon_scale_gate[-1].bias)
                nn.init.zeros_(self.horizon_router_delta[-1].weight)
                nn.init.zeros_(self.horizon_router_delta[-1].bias)

    def _multiscale_delta(self, local_history: torch.Tensor) -> torch.Tensor:
        summaries = []
        for window, branch in zip(self.scale_windows, self.scale_branches):
            encoded = branch(local_history[:, -window:].transpose(1, 2))
            summaries.append(encoded.mean(dim=-1))
        return self.scale_projection(torch.cat(summaries, dim=-1))

    def _disjoint_scale_summaries(self, local_history: torch.Tensor) -> torch.Tensor:
        """Encode recent, preceding, and older history without window overlap."""
        segments = (
            local_history[:, -15:],
            local_history[:, -30:-15],
            local_history[:, -90:-30],
        )
        summaries = []
        for segment, branch in zip(segments, self.scale_branches):
            encoded = branch(segment.transpose(1, 2))
            summaries.append(encoded.mean(dim=-1))
        return torch.stack(summaries, dim=1)

    def _ctrv_candidate(self, positions: torch.Tensor) -> torch.Tensor:
        """Constant-turn-rate/velocity trajectory in the local frame.

        Turn rate is a speed-weighted circular mean over the latest six
        displacement pairs.  The bound prevents noisy low-speed headings from
        producing implausibly tight circles over the long horizon.
        """
        displacement = torch.diff(positions[:, -10:], dim=1)
        previous, current = displacement[:, -7:-1], displacement[:, -6:]
        previous_speed = torch.linalg.vector_norm(previous, dim=-1)
        current_speed = torch.linalg.vector_norm(current, dim=-1)
        cross = previous[..., 0] * current[..., 1] - previous[..., 1] * current[..., 0]
        dot = (previous * current).sum(dim=-1)
        angles = torch.atan2(cross, dot)
        reliability = torch.minimum(previous_speed, current_speed)
        reliability = torch.where(reliability > 1e-5, reliability, torch.zeros_like(reliability))
        turn_rate = (angles * reliability).sum(dim=1) / reliability.sum(dim=1).clamp_min(1e-6)
        turn_rate = turn_rate.clamp(-0.20, 0.20)

        velocity = displacement[:, -3:].mean(dim=1)
        steps = torch.arange(
            1, self.prediction_steps + 1, dtype=positions.dtype, device=positions.device
        )
        angle = turn_rate[:, None] * steps[None]
        cosine, sine = torch.cos(angle), torch.sin(angle)
        vx = velocity[:, :1] * cosine - velocity[:, 1:] * sine
        vy = velocity[:, :1] * sine + velocity[:, 1:] * cosine
        future_velocity = torch.stack((vx, vy), dim=-1)
        return positions[:, -1:] + torch.cumsum(future_velocity, dim=1)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        positions = history[..., :2]
        if self.component_ablation == "no_local_frame":
            local_positions = positions
            origin = torch.zeros_like(positions[:, -1:])
            cosine = torch.ones_like(positions[:, -1, :1])
            sine = torch.zeros_like(positions[:, -1, :1])
            local_history = history
        else:
            local_positions, origin, cosine, sine = self._local_frame(positions)
            local_history = torch.cat((local_positions, history[..., 2:]), dim=-1)
        encoded, _ = self.encoder(local_history)
        if self.component_ablation == "add_temporal_attention":
            attention_weights = torch.softmax(
                self.temporal_attention(encoded).squeeze(-1), dim=1
            )
            encoded_last = torch.sum(attention_weights.unsqueeze(-1) * encoded, dim=1)
        else:
            attention_weights = None
            encoded_last = encoded[:, -1]
        scale_delta = self._multiscale_delta(local_history)
        if self.v6_variant == "intent" or self.component_ablation == "single_scale":
            scale_delta = torch.zeros_like(scale_delta)
        enhanced_state = encoded_last + scale_delta
        descriptor_values = self.descriptors(local_positions)
        router_descriptors = (
            torch.zeros_like(descriptor_values)
            if self.component_ablation == "no_descriptors"
            else descriptor_values
        )
        representation = torch.cat((enhanced_state, router_descriptors), dim=-1)

        dynamics = torch.sigmoid(self.dynamics_head(representation))
        if self.component_ablation in ("tau_cap80", "guarded_router"):
            tau_upper = 80.0
        elif self.component_ablation == "tau_max180":
            tau_upper = 180.0
        elif self.component_ablation == "tau_max240":
            tau_upper = 240.0
        else:
            tau_upper = self.tau_range[1]
        tau = self.tau_range[0] + (tau_upper - self.tau_range[0]) * dynamics[:, :1]
        clip_ratio = self.clip_ratio_range[0] + (
            self.clip_ratio_range[1] - self.clip_ratio_range[0]
        ) * dynamics[:, 1:]
        if self.component_ablation == "fixed_dynamics":
            tau = torch.full_like(tau, 30.0)
            clip_ratio = torch.full_like(clip_ratio, 0.20)
        local_candidates = self.experts(local_positions, tau, clip_ratio)
        base_expert_count = local_candidates.shape[1]
        knot_logits = self.router(representation).view(
            -1, base_expert_count, len(self.knot_steps)
        )
        tsk_rule_weights = None
        if self.component_ablation == "add_tsk":
            tsk_delta, tsk_rule_weights = self.tsk_router(descriptor_values)
            knot_logits = knot_logits + tsk_delta.view(
                -1, base_expert_count, len(self.knot_steps)
            )
        horizon_scale_weights = None
        router_delta = None
        if self.v6_variant == "joint_aligned_intent_horizon_scale":
            scale_summaries = self._disjoint_scale_summaries(local_history)
            scale_logits = self.horizon_scale_gate(representation).view(
                -1, len(self.knot_steps), len(self.scale_windows)
            )
            horizon_scale_weights = torch.softmax(scale_logits, dim=-1)
            horizon_context = torch.einsum(
                "bks,bsd->bkd", horizon_scale_weights, scale_summaries
            )
            router_delta = self.horizon_router_delta(horizon_context).transpose(1, 2)
            knot_logits = knot_logits + router_delta
        interpolated_logits = self._interpolate(knot_logits)
        if self.v6_variant == "joint_aligned_intent_ctrv":
            ctrv = self._ctrv_candidate(local_positions)
            local_candidates = torch.cat((local_candidates, ctrv[:, None]), dim=1)
            turn_logits = self._interpolate(self.turn_router(representation)[:, None])
            interpolated_logits = torch.cat((interpolated_logits, turn_logits), dim=1)
        router_temperature_scale = {
            "router_sharp125": 1.25,
            "router_sharp150": 1.50,
        }.get(self.component_ablation, 1.0)
        if self.router_temperature_override is not None:
            router_temperature_scale = self.router_temperature_override
        if self.component_ablation == "adaptive_sharp150":
            base_weights = torch.softmax(interpolated_logits, dim=1)
            normalized_entropy = -(
                base_weights * torch.log(base_weights.clamp_min(1e-8))
            ).sum(dim=1, keepdim=True) / math.log(float(base_weights.shape[1]))
            # Detaching the confidence prevents the router from gaming the
            # temperature controller simply by changing its entropy.
            router_temperature_scale = 1.0 + 0.50 * (1.0 - normalized_entropy.detach())
        expert_weights = torch.softmax(interpolated_logits * router_temperature_scale, dim=1)
        if self.component_ablation == "uniform_router":
            expert_weights = torch.full_like(
                expert_weights, 1.0 / expert_weights.shape[1]
            )
        elif self.component_ablation == "no_dca":
            expert_weights = expert_weights.clone()
            expert_weights[:, 3:] = 0.0
            expert_weights = expert_weights / expert_weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        elif self.component_ablation in ("dca_cap55", "guarded_router"):
            # A softmax router can otherwise put virtually all mass on the
            # adaptive-acceleration expert.  Preserve sample/horizon adaptation
            # while retaining at least 45% support from the stable CV experts.
            dca_weight = expert_weights[:, 3:4].clamp_max(0.55)
            stable_weights = expert_weights[:, :3]
            stable_weights = stable_weights * (
                (1.0 - dca_weight)
                / stable_weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
            )
            expert_weights = torch.cat((stable_weights, dca_weight), dim=1)
        elif self.component_ablation == "cv3_only":
            expert_weights = torch.zeros_like(expert_weights)
            expert_weights[:, 0] = 1.0
        local_prior = torch.sum(expert_weights.unsqueeze(-1) * local_candidates, dim=1)

        local_residual = self.residual(representation).view(-1, self.prediction_steps, 2)
        gate_parameters = self.residual_gate(representation)
        base = -4.0 + 1.5 * torch.tanh(gate_parameters[:, :1])
        increments = F.softplus(gate_parameters[:, 1:])
        knot_gate = torch.sigmoid(base + torch.cumsum(increments, dim=-1))
        residual_strength = self._interpolate(knot_gate[:, None]).squeeze(1)
        if self.component_ablation == "no_residual":
            residual_strength = torch.zeros_like(residual_strength)
        elif self.component_ablation == "ungated_residual":
            residual_strength = torch.ones_like(residual_strength)
        elif self.component_ablation == "residual_cap50":
            residual_strength = residual_strength.clamp_max(0.50)
        elif self.component_ablation == "residual_boost125":
            residual_strength = (1.25 * residual_strength).clamp_max(1.0)
        elif self.component_ablation == "residual_boost150":
            residual_strength = (1.50 * residual_strength).clamp_max(1.0)
        local_prediction = local_prior + residual_strength.unsqueeze(-1) * local_residual
        spline_correction = None
        if (
            self.v6_variant == "joint_aligned_intent_spline"
            and self.component_ablation != "no_spline"
        ):
            control_points = self.spline_residual(representation).view(
                -1, len(self.knot_steps), 2
            )
            spline_correction = self._interpolate(control_points.transpose(1, 2)).transpose(1, 2)
            local_prediction = local_prediction + (
                residual_strength.unsqueeze(-1) * spline_correction
            )
        anchor_correction = None
        if self.v6_variant == "joint_aligned_intent_anchor_residual":
            anchor_points = self.anchor_residual(representation).view(
                -1, len(self.knot_steps), 2
            )
            anchor_correction = self._interpolate(
                anchor_points.transpose(1, 2)
            ).transpose(1, 2)
            anchor_steps = torch.arange(
                1, self.prediction_steps + 1,
                dtype=history.dtype, device=history.device,
            )
            late_release = ((anchor_steps - 30.0) / 150.0).clamp(0.0, 1.0).view(1, -1, 1)
            local_prediction = local_prediction + late_release * anchor_correction

        endpoint_correction = self.intent_correction(representation)
        intent_strength = torch.sigmoid(self.intent_release(representation))
        if self.v6_variant == "multiscale" or self.component_ablation == "no_intent":
            intent_strength = torch.zeros_like(intent_strength)
        steps = torch.arange(
            1, self.prediction_steps + 1,
            dtype=history.dtype, device=history.device,
        )
        intent_profile = (steps / float(self.prediction_steps)).square().view(1, -1, 1)
        local_prediction = local_prediction + (
            intent_profile * intent_strength[:, None] * endpoint_correction[:, None]
        )
        # The original v6 auxiliary target ignored both the learned release and
        # the residual contribution.  Keep it untouched for reproducibility,
        # while the aligned ablation supervises the endpoint actually emitted.
        if self.v6_variant in (
            "joint_aligned_intent", "joint_aligned_intent_ctrv",
            "joint_aligned_intent_spline", "joint_aligned_intent_horizon_scale",
            "joint_aligned_intent_anchor_residual",
        ):
            local_intent_endpoint = local_prediction[:, -1]
        else:
            local_intent_endpoint = local_prior[:, -1] + endpoint_correction

        prediction = self._to_global(local_prediction, origin, cosine, sine, add_origin=True)
        if not return_aux:
            return prediction
        candidates = self._to_global(local_candidates, origin, cosine, sine, add_origin=True)
        prior = self._to_global(local_prior, origin, cosine, sine, add_origin=True)
        residual = self._to_global(local_residual, origin, cosine, sine, add_origin=False)
        intent_endpoint = self._to_global(
            local_intent_endpoint[:, None], origin, cosine, sine, add_origin=True
        ).squeeze(1)
        return prediction, {
            "prior": prior,
            "residual": residual,
            "candidates": candidates,
            "expert_weights": expert_weights,
            "rule_weights": expert_weights.mean(dim=-1),
            "descriptors": descriptor_values,
            "residual_gate": residual_strength,
            "adaptive_tau": tau,
            "adaptive_clip_ratio": clip_ratio,
            "intent_endpoint": intent_endpoint,
            "intent_strength": intent_strength,
            "multiscale_delta": scale_delta,
            "spline_correction": spline_correction,
            "anchor_correction": anchor_correction,
            "horizon_scale_weights": horizon_scale_weights,
            "horizon_router_delta": router_delta,
            "temporal_attention": attention_weights,
            "tsk_rule_weights": tsk_rule_weights,
            # Expose the already-computed local/shared context to lightweight
            # internal experts.  These are training-time tensors, not extra
            # inputs or domain identifiers.
            "shared_representation": representation,
            "shared_sequence": encoded,
            "local_history": local_history,
            "frame_origin": origin,
            "frame_cosine": cosine,
            "frame_sine": sine,
        }
