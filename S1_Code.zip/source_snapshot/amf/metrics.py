from __future__ import annotations

import numpy as np
import torch
from torch.nn import functional as F


HORIZONS = {"5": 15, "10": 30, "20": 60, "30": 90, "45": 135, "60": 180}


def weighted_huber(prediction: torch.Tensor, target: torch.Tensor, delta: float = 1.0):
    error = prediction - target
    absolute = error.abs()
    loss = torch.where(absolute <= delta, 0.5 * error.square(), delta * (absolute - 0.5 * delta))
    weights = torch.ones(prediction.shape[1], device=prediction.device, dtype=prediction.dtype)
    weights[:30] = 2.0
    return (loss.sum(dim=-1) * weights[None, :]).sum() / (
        prediction.shape[0] * weights.sum()
    )


def kinematic_multitask_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    *,
    velocity_weight: float = 0.0,
    acceleration_weight: float = 0.0,
    heading_weight: float = 0.0,
    anchor_weight: float = 0.0,
    tail_weight: float = 0.0,
    anchor_steps: tuple[int, ...] = (15, 30, 90, 180),
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    """Position loss plus scale-safe kinematic and key-horizon supervision.

    All derivative terms are computed in the same local/scaled coordinate system as
    the model output.  Heading uses cosine distance, so the circular wrap at +/-pi
    cannot create an artificial discontinuity.
    """

    position = weighted_huber(prediction, target)
    tail = torch.linalg.vector_norm(prediction[:, 30:] - target[:, 30:], dim=-1).mean()
    pred_velocity = prediction[:, 1:] - prediction[:, :-1]
    true_velocity = target[:, 1:] - target[:, :-1]
    velocity = F.smooth_l1_loss(pred_velocity, true_velocity)

    pred_acceleration = pred_velocity[:, 1:] - pred_velocity[:, :-1]
    true_acceleration = true_velocity[:, 1:] - true_velocity[:, :-1]
    acceleration = F.smooth_l1_loss(pred_acceleration, true_acceleration)

    pred_speed = torch.linalg.vector_norm(pred_velocity, dim=-1)
    true_speed = torch.linalg.vector_norm(true_velocity, dim=-1)
    valid_heading = (pred_speed > 1e-5) & (true_speed > 1e-5)
    cosine = (pred_velocity * true_velocity).sum(dim=-1) / (
        pred_speed * true_speed
    ).clamp_min(1e-6)
    heading_error = 1.0 - cosine.clamp(-1.0, 1.0)
    heading = (
        heading_error[valid_heading].mean()
        if valid_heading.any()
        else heading_error.sum() * 0.0
    )

    indices = [step - 1 for step in anchor_steps if 0 < step <= prediction.shape[1]]
    if indices:
        index = torch.tensor(indices, dtype=torch.long, device=prediction.device)
        anchor_distance = torch.linalg.vector_norm(
            prediction.index_select(1, index) - target.index_select(1, index), dim=-1
        )
        # Charbonnier is stable at zero and directly optimizes Euclidean displacement.
        anchor = torch.sqrt(anchor_distance.square() + 1e-6).mean()
    else:
        anchor = position * 0.0

    total = (
        position
        + velocity_weight * velocity
        + acceleration_weight * acceleration
        + heading_weight * heading
        + anchor_weight * anchor
        + tail_weight * tail
    )
    return total, {
        "position": position,
        "velocity": velocity,
        "acceleration": acceleration,
        "heading": heading,
        "anchor": anchor,
        "tail": tail,
    }


def trajectory_shape_losses(
    prediction: torch.Tensor,
    target: torch.Tensor,
    anchor_steps: tuple[int, ...] = (15, 30, 60, 90, 135, 180),
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return scale-normalized path alignment and signed-turn losses."""

    indices = torch.tensor(
        [step - 1 for step in anchor_steps if step <= prediction.shape[1]],
        dtype=torch.long,
        device=prediction.device,
    )
    pred_knots = prediction.index_select(1, indices)
    true_knots = target.index_select(1, indices)
    pred_knots = pred_knots - prediction[:, :1]
    true_knots = true_knots - target[:, :1]
    pred_scale = torch.linalg.vector_norm(pred_knots[:, -1], dim=-1, keepdim=True).clamp_min(1e-3)
    true_scale = torch.linalg.vector_norm(true_knots[:, -1], dim=-1, keepdim=True).clamp_min(1e-3)
    alignment = F.smooth_l1_loss(
        pred_knots / pred_scale.unsqueeze(-1),
        true_knots / true_scale.unsqueeze(-1),
    )

    pred_velocity = prediction[:, 1:] - prediction[:, :-1]
    true_velocity = target[:, 1:] - target[:, :-1]
    pred_v0, pred_v1 = pred_velocity[:, :-1], pred_velocity[:, 1:]
    true_v0, true_v1 = true_velocity[:, :-1], true_velocity[:, 1:]
    pred_cross = pred_v0[..., 0] * pred_v1[..., 1] - pred_v0[..., 1] * pred_v1[..., 0]
    true_cross = true_v0[..., 0] * true_v1[..., 1] - true_v0[..., 1] * true_v1[..., 0]
    pred_dot = (pred_v0 * pred_v1).sum(dim=-1)
    true_dot = (true_v0 * true_v1).sum(dim=-1)
    pred_turn = torch.atan2(pred_cross, pred_dot)
    true_turn = torch.atan2(true_cross, true_dot)
    valid = (
        torch.linalg.vector_norm(pred_v0, dim=-1) > 1e-5
    ) & (
        torch.linalg.vector_norm(pred_v1, dim=-1) > 1e-5
    ) & (
        torch.linalg.vector_norm(true_v0, dim=-1) > 1e-5
    ) & (
        torch.linalg.vector_norm(true_v1, dim=-1) > 1e-5
    )
    curvature = (
        F.smooth_l1_loss(pred_turn[valid], true_turn[valid])
        if valid.any()
        else alignment * 0.0
    )
    return alignment, curvature


def displacement_metrics(prediction_m: np.ndarray, target_m: np.ndarray):
    distance = np.linalg.norm(prediction_m - target_m, axis=-1)
    result: dict[str, float] = {}
    for label, step in HORIZONS.items():
        result[f"ADE@{label}"] = float(distance[:, :step].mean())
        result[f"FDE@{label}"] = float(distance[:, step - 1].mean())
    return result


def fit_cv3_calibration(model_prediction: np.ndarray, cv3: np.ndarray, target: np.ndarray):
    difference = model_prediction - cv3
    residual = target - cv3
    numerator = np.sum(difference * residual, axis=(0, 2))
    denominator = np.maximum(np.sum(difference * difference, axis=(0, 2)), 1e-12)
    return np.clip(numerator / denominator, 0.0, 1.0).astype(np.float32)


def apply_calibration(model_prediction: np.ndarray, cv3: np.ndarray, alpha: np.ndarray):
    return alpha[None, :, None] * model_prediction + (1.0 - alpha[None, :, None]) * cv3
