"""Sensors 2022 BLSTM-MDN, explicitly adapted to EnvShip direct trajectories.

Architecture source: doi:10.3390/s22052058, Fig. 2 / Table 1.
Independent PyTorch implementation; not an exact TensorFlow port. See NOTICE.
"""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.special import ndtr


@dataclass(frozen=True)
class MDNConfig:
    input_features: int = 6
    history_steps: int = 90
    horizon: int = 180
    shared_width: int = 456
    branch_width: int = 256
    mixtures: int = 11
    dropout: float = .3
    sigma_floor: float = .001

    def dictionary(self):
        return asdict(self)


class BLSTMBlock(nn.Module):
    def __init__(self, incoming, outgoing, dropout):
        super().__init__()
        self.rnn = nn.LSTM(incoming, outgoing, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        # TensorFlow momentum=.99 corresponds to PyTorch update momentum=.01.
        # Trainable BN follows paper description, not frozen BN in author code.
        self.bn = nn.BatchNorm1d(2 * outgoing, eps=.001, momentum=.01)
        for name, parameter in self.rnn.named_parameters():
            if 'weight_ih' in name:
                nn.init.normal_(parameter, std=1 / math.sqrt(incoming))
            elif 'weight_hh' in name:
                for gate in parameter.chunk(4, dim=0):
                    nn.init.orthogonal_(gate)
            else:
                nn.init.zeros_(parameter)
                if 'bias_ih' in name:
                    parameter.data[outgoing:2 * outgoing].fill_(1)

    def forward(self, x, final=False):
        sequence, (hidden, _) = self.rnn(x)
        # Backward summary is h_n, NOT the backward part at the final timestep.
        value = torch.cat((hidden[-2], hidden[-1]), -1) if final else sequence
        value = self.dropout(F.leaky_relu(value, negative_slope=.1))
        if final:
            return self.bn(value)
        return self.bn(value.transpose(1, 2)).transpose(1, 2).contiguous()


class BLSTMTrajectoryMDN(nn.Module):
    def __init__(self, config=MDNConfig()):
        super().__init__()
        self.config = config
        a, b = config.shared_width, config.branch_width
        self.shared1 = BLSTMBlock(config.input_features, a, config.dropout)
        self.shared2 = BLSTMBlock(2*a, a, config.dropout)
        self.branches = nn.ModuleList([nn.ModuleList([
            BLSTMBlock(2*a, a, config.dropout),
            BLSTMBlock(2*a, b, config.dropout)]) for _ in range(2)])
        self.means = nn.Linear(2*b, config.mixtures*config.horizon*2)
        self.scales = nn.Linear(2*b, config.mixtures*config.horizon*2)
        self.weights = nn.Linear(2*b, config.mixtures)
        for layer in (self.means, self.scales, self.weights):
            nn.init.normal_(layer.weight, std=1/math.sqrt(2*b))
            nn.init.zeros_(layer.bias)

    def forward(self, history):
        if history.shape[1:] != (self.config.history_steps, self.config.input_features):
            raise ValueError(f'Expected historical input Bx90x6, got {history.shape}')
        x = self.shared2(self.shared1(history))
        vectors = [tail(head(x), final=True) for head, tail in self.branches]
        encoded = (vectors[0] + vectors[1]) * .5
        shape = (-1, self.config.mixtures, self.config.horizon, 2)
        # Compute likelihood in float32 even when the encoder uses AMP.
        mu = F.leaky_relu(self.means(encoded).float(), .1).reshape(shape)
        raw = self.scales(encoded).float().reshape(shape)
        sigma = (F.elu(raw) + 1).clamp_min(self.config.sigma_floor)
        return self.weights(encoded).float(), mu, sigma


def joint_nll(logits, mu, sigma, target, steps=None):
    h = target.shape[1] if steps is None else steps
    residual = (target[:, None, :h] - mu[:, :, :h]) / sigma[:, :, :h]
    log_density = (-.5*residual.square() - sigma[:, :, :h].log()
                   - .5*math.log(2*math.pi)).sum(dim=(-1, -2))
    return -torch.logsumexp(F.log_softmax(logits, -1) + log_density, -1)


def meter_jacobian(scales, steps):
    return steps * torch.as_tensor(scales).log().sum()


def conditional_mean(logits, mu):
    return (logits.softmax(-1)[:, :, None, None] * mu).sum(dim=1)


def draw_trajectories(logits, mu, sigma, count, generator=None):
    # A single component is shared by all 180 positions in each sampled path.
    indices = torch.multinomial(logits.softmax(-1), count, True, generator=generator)
    batch = torch.arange(mu.shape[0], device=mu.device)[:, None]
    means, scales = mu[batch, indices], sigma[batch, indices]
    noise = torch.randn(means.shape, device=mu.device, dtype=mu.dtype, generator=generator)
    return means + noise * scales, indices


def energy_score(a, b, target, steps):
    # Independent A/B sets, not a biased diagonal-including single-set estimate.
    a = a[:, :, :steps].flatten(2)
    b = b[:, :, :steps].flatten(2)
    y = target[:, :steps].flatten(1)
    first = torch.linalg.vector_norm(a-y[:, None], dim=-1).mean(1)
    second = torch.cdist(a, b, compute_mode='donot_use_mm_for_euclid_dist').mean((1, 2))
    return (first - .5*second) / math.sqrt(2*steps)


def marginal_quantile(logits, mu, sigma, probability):
    """CPU float64 mixture CDF inverse for BxKx... marginal coordinates."""
    logits = np.asarray(logits, dtype=np.float64)
    mu, sigma = np.asarray(mu, dtype=np.float64), np.asarray(sigma, dtype=np.float64)
    weights = np.exp(logits-logits.max(1, keepdims=True))
    weights /= weights.sum(1, keepdims=True)
    weights = weights.reshape((*weights.shape, *((1,)*(mu.ndim-2))))
    lo, hi = (mu-12*sigma).min(1), (mu+12*sigma).max(1)
    for _ in range(48):
        middle = (lo+hi)*.5
        cdf = (weights*ndtr((middle[:, None]-mu)/sigma)).sum(1)
        lo = np.where(cdf < probability, middle, lo)
        hi = np.where(cdf >= probability, middle, hi)
    return (lo+hi)*.5
