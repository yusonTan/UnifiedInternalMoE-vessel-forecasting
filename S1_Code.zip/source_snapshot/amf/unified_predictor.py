from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import torch
from torch import nn

from .adaptive_moe import IntentMultiScaleMoE


class UnifiedInternalMoE(nn.Module):
    """A single-checkpoint heterogeneous predictor distilled from the study.

    The five branches and their sample/horizon router are part of one module and
    one state dict.  No domain identifier is consumed at inference.  Existing
    validation-selected expert checkpoints are used as staged pretraining, while
    the final predictor is called once and returns one trajectory.
    """

    expert_order = (
        "sa_repair",
        "transformer_cv",
        "itransformer_fa_faithful",
        "mstformer_faithful",
        "direct_gru",
    )
    internal_expert_names = (
        "SA-Repair",
        "Transformer-CV",
        "iTransformer-FA",
        "MSTFormer",
        "Direct-GRU",
    )
    route_knot_steps = (15, 30, 180)

    def __init__(self, router_width: int = 64, max_logit_delta: float = 1.5):
        super().__init__()
        # Local imports avoid making the core amf package depend on experiment
        # modules unless this terminal predictor is explicitly requested.
        from comparison_models import build_comparison_model
        from faithful_sota_models import build_faithful_model

        self.sa_repair = IntentMultiScaleMoE(
            v6_variant="joint_aligned_intent_spline",
            component_ablation="router_sharp150",
        )
        self.transformer_cv = build_comparison_model("transformer_cv")
        self.itransformer_fa_faithful = build_faithful_model(
            "itransformer_fa_faithful"
        )
        self.mstformer_faithful = build_faithful_model("mstformer_faithful")
        self.direct_gru = build_comparison_model("direct_gru")
        self.expert_modules = (
            self.sa_repair,
            self.transformer_cv,
            self.itransformer_fa_faithful,
            self.mstformer_faithful,
            self.direct_gru,
        )

        self.global_route_logits = nn.Parameter(
            torch.zeros(len(self.expert_order), len(self.route_knot_steps))
        )
        self.router_encoder = nn.GRU(6, router_width, batch_first=True)
        disagreement_size = (len(self.expert_order) - 1) * len(self.route_knot_steps)
        self.router_head = nn.Sequential(
            nn.Linear(router_width + disagreement_size, router_width),
            nn.GELU(),
            nn.Linear(
                router_width,
                len(self.expert_order) * len(self.route_knot_steps),
            ),
        )
        nn.init.zeros_(self.router_head[-1].weight)
        nn.init.zeros_(self.router_head[-1].bias)
        self.max_logit_delta = float(max_logit_delta)
        self.register_buffer(
            "internal_active_mask",
            torch.ones(len(self.expert_order), dtype=torch.bool),
        )
        self.freeze_experts()

    @property
    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())

    # These properties retain the established adaptive-diagnostic interface.
    @property
    def expert_names(self):
        return self.sa_repair.expert_names

    @property
    def knot_steps(self):
        return self.sa_repair.knot_steps

    @property
    def tau_range(self):
        return self.sa_repair.tau_range

    @property
    def clip_ratio_range(self):
        return self.sa_repair.clip_ratio_range

    def freeze_experts(self) -> None:
        for expert in self.expert_modules:
            expert.requires_grad_(False)
            expert.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        # Dropout in frozen experts must stay disabled, including while the
        # sample router is trained, or the protected initial committee drifts.
        for expert in self.expert_modules:
            expert.eval()
        return self

    @staticmethod
    def _load_model_state(module: nn.Module, checkpoint: Path) -> None:
        payload = torch.load(checkpoint, map_location="cpu", weights_only=False)
        module.load_state_dict(payload["model"], strict=True)

    def load_staged_experts(
        self,
        study_root: Path,
        diagnostic_root: Path,
        domain: str,
        seed: int,
    ) -> dict:
        study_root = Path(study_root)
        diagnostic_root = Path(diagnostic_root)
        seed_dir = f"seed_{seed}"
        paths = {
            "sa_repair": diagnostic_root / "repairs" / "router_sharp150_cov_0p0"
            / domain / seed_dir / "best.pt",
            "transformer_cv": study_root / "comparisons" / "runs"
            / "transformer_cv" / domain / seed_dir / "best.pt",
            "itransformer_fa_faithful": study_root / "comparisons" / "faithful_sota"
            / "itransformer_fa_faithful" / domain / seed_dir / "best.pt",
            "mstformer_faithful": study_root / "comparisons" / "faithful_sota"
            / "mstformer_faithful" / domain / seed_dir / "best.pt",
            "direct_gru": study_root / "comparisons" / "runs"
            / "direct_gru" / domain / seed_dir / "best.pt",
        }
        missing = [str(path) for path in paths.values() if not path.exists()]
        if missing:
            raise FileNotFoundError("Missing staged checkpoints: " + ", ".join(missing))
        for name, module in zip(self.expert_order, self.expert_modules):
            self._load_model_state(module, paths[name])

        selection_path = diagnostic_root / "committee" / domain / seed_dir / "selection.json"
        selection = json.loads(selection_path.read_text(encoding="utf-8"))
        selected_names = selection["selected"]["candidates"]
        selected_weights = torch.as_tensor(
            selection["knot_weights_5_10_60"], dtype=torch.float32
        )
        full_weights = torch.zeros(
            len(self.expert_order), len(self.route_knot_steps), dtype=torch.float32
        )
        for selected_index, name in enumerate(selected_names):
            if name not in self.expert_order:
                raise ValueError(f"Unsupported selected committee expert: {name}")
            full_weights[self.expert_order.index(name)] = selected_weights[:, selected_index]
        full_weights /= full_weights.sum(dim=0, keepdim=True).clamp_min(1e-12)

        route_plan = self._select_domain_short_specialist(
            diagnostic_root, domain
        )
        specialist = route_plan["selected_short_specialist"]
        if specialist is not None:
            full_weights[:, :2] = 0.0
            full_weights[self.expert_order.index(specialist), :2] = 1.0
        with torch.no_grad():
            self.global_route_logits.copy_(torch.log(full_weights.clamp_min(1e-12)))
        self.freeze_experts()
        return {
            "protocol": "validation-only compact committee initialization",
            "selection": str(selection_path.resolve()),
            "selected_experts": selected_names,
            "full_knot_weights": full_weights.tolist(),
            "domain_short_route_plan": route_plan,
            "expert_checkpoints": {
                name: str(path.resolve()) for name, path in paths.items()
            },
        }

    @classmethod
    def _select_domain_short_specialist(cls, diagnostic_root: Path, domain: str) -> dict:
        """Select one shared 5--10 minute specialist using validation only.

        The same rule is evaluated for every data domain.  Aggregating the
        three training replications prevents a seed-specific test-time policy.
        """
        seeds = (42, 52, 62)
        cache_root = diagnostic_root / "committee" / "prediction_cache"

        def expand(knots: np.ndarray) -> np.ndarray:
            output = np.empty((180, knots.shape[1]), dtype=np.float64)
            output[:15] = knots[0]
            for step in range(15, 30):
                alpha = (step - 14) / 15.0
                output[step] = (1.0 - alpha) * knots[0] + alpha * knots[1]
            for step in range(30, 180):
                alpha = (step - 29) / 150.0
                output[step] = (1.0 - alpha) * knots[1] + alpha * knots[2]
            return output / np.maximum(output.sum(axis=1, keepdims=True), 1e-12)

        def goal(prediction: np.ndarray, target: np.ndarray) -> float:
            distance = np.linalg.norm(prediction - target, axis=-1)
            return float(
                distance[:, :15].mean() / 20.0
                + distance[:, :30].mean() / 50.0
                + 2.0 * distance[:, :180].mean() / 600.0
            )

        records = []
        for selected_seed in seeds:
            selection = json.loads(
                (
                    diagnostic_root / "committee" / domain
                    / f"seed_{selected_seed}" / "selection.json"
                ).read_text(encoding="utf-8")
            )
            loaded = {
                name: np.load(cache_root / name / domain / f"seed_{selected_seed}.npz")
                for name in cls.expert_order
            }
            candidates = np.stack(
                [loaded[name]["prediction"].astype(np.float64) for name in cls.expert_order]
            )
            target = loaded[cls.expert_order[0]]["target"].astype(np.float64)
            knots = np.zeros((3, len(cls.expert_order)), dtype=np.float64)
            selected = selection["selected"]["candidates"]
            selected_weights = np.asarray(
                selection["knot_weights_5_10_60"], dtype=np.float64
            )
            for selected_index, name in enumerate(selected):
                knots[:, cls.expert_order.index(name)] = selected_weights[:, selected_index]
            records.append((candidates, target, knots))

        scores = {}
        for option in (None, *cls.expert_order):
            option_scores = []
            for candidates, target, original_knots in records:
                knots = original_knots.copy()
                if option is not None:
                    knots[:2] = 0.0
                    knots[:2, cls.expert_order.index(option)] = 1.0
                prediction = np.einsum("knte,tk->nte", candidates, expand(knots))
                option_scores.append(goal(prediction, target))
            scores["keep_committee" if option is None else option] = float(
                np.mean(option_scores)
            )
        baseline = scores["keep_committee"]
        best_name = min(cls.expert_order, key=lambda name: scores[name])
        selected_specialist = best_name if scores[best_name] < baseline - 1e-5 else None
        return {
            "method": "three-seed aggregate validation goal; no test labels",
            "selected_short_specialist": selected_specialist,
            "mean_validation_goal": scores,
            "improvement": (
                baseline - scores[selected_specialist]
                if selected_specialist is not None else 0.0
            ),
        }

    @staticmethod
    def expand_three_knot_weights(knot_weights: torch.Tensor) -> torch.Tensor:
        """Match evaluate_compact_committee.expanded_weights exactly."""
        batch, experts, _ = knot_weights.shape
        output = knot_weights.new_empty(batch, experts, 180)
        output[:, :, :15] = knot_weights[:, :, 0:1]
        short_alpha = torch.arange(
            1, 16, dtype=knot_weights.dtype, device=knot_weights.device
        ).view(1, 1, 15) / 15.0
        output[:, :, 15:30] = (
            (1.0 - short_alpha) * knot_weights[:, :, 0:1]
            + short_alpha * knot_weights[:, :, 1:2]
        )
        long_alpha = torch.arange(
            1, 151, dtype=knot_weights.dtype, device=knot_weights.device
        ).view(1, 1, 150) / 150.0
        output[:, :, 30:180] = (
            (1.0 - long_alpha) * knot_weights[:, :, 1:2]
            + long_alpha * knot_weights[:, :, 2:3]
        )
        return output / output.sum(dim=1, keepdim=True).clamp_min(1e-12)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        # Frozen branches need no activation graph.  The router still learns
        # directly from history and detached inter-model disagreement.
        with torch.no_grad():
            sa_prediction, sa_aux = self.sa_repair(history, return_aux=True)
            predictions = [
                sa_prediction,
                self.transformer_cv(history),
                self.itransformer_fa_faithful(history),
                self.mstformer_faithful(history),
                self.direct_gru(history),
            ]
            candidates = torch.stack(predictions, dim=1)
            indices = torch.tensor(
                [step - 1 for step in self.route_knot_steps],
                dtype=torch.long,
                device=history.device,
            )
            disagreement = torch.linalg.vector_norm(
                candidates[:, 1:].index_select(2, indices)
                - candidates[:, :1].index_select(2, indices),
                dim=-1,
            )

        encoded, _ = self.router_encoder(history)
        router_features = torch.cat(
            (encoded[:, -1], torch.log1p(disagreement).flatten(1)), dim=-1
        )
        delta = self.max_logit_delta * torch.tanh(
            self.router_head(router_features).view(
                history.shape[0], len(self.expert_order), len(self.route_knot_steps)
            )
        )
        raw_knot_weights = torch.softmax(
            self.global_route_logits.unsqueeze(0) + delta, dim=1
        )
        weights = self.expand_three_knot_weights(raw_knot_weights)
        prediction = torch.sum(weights.unsqueeze(-1) * candidates, dim=1)
        if not return_aux:
            return prediction

        # Six-knot summaries are provided solely for the existing diagnostics.
        diagnostic_indices = torch.tensor(
            [step - 1 for step in self.knot_steps],
            dtype=torch.long,
            device=history.device,
        )
        diagnostic_disagreement = torch.linalg.vector_norm(
            candidates[:, 1:].index_select(2, diagnostic_indices)
            - candidates[:, :1].index_select(2, diagnostic_indices),
            dim=-1,
        )
        sa_aux.update(
            {
                "calibration_reference": prediction,
                "core_prediction": sa_prediction,
                "internal_candidates": candidates,
                "internal_expert_weights": weights,
                "internal_raw_knot_weights": raw_knot_weights,
                "internal_knot_weights": raw_knot_weights,
                "internal_release": torch.ones(
                    history.shape[0], len(self.knot_steps),
                    dtype=history.dtype, device=history.device,
                ),
                "internal_disagreement": diagnostic_disagreement,
                "internal_active_mask": self.internal_active_mask,
                "internal_branch_roles": ("generic",) * (len(self.expert_order) - 1),
                "internal_oracle_steps": self.route_knot_steps,
            }
        )
        return prediction, sa_aux
