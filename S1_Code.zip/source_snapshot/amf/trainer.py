from __future__ import annotations

import json
import os
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch.amp import GradScaler, autocast

from .metrics import (
    HORIZONS,
    apply_calibration,
    displacement_metrics,
    fit_cv3_calibration,
    kinematic_multitask_loss,
    trajectory_shape_losses,
    weighted_huber,
)
from .model import fuzzy_coverage_kl


def heterogeneous_internal_losses(aux, target):
    """Specialize internal branches and teach the router a soft oracle.

    Oracle targets are computed only from the current training target.  They use
    no domain id and never inspect validation/test examples.
    """

    candidates = aux.get("internal_candidates")
    knot_weights = aux.get("internal_raw_knot_weights")
    if candidates is None or knot_weights is None:
        zero = target.sum() * 0.0
        return zero, zero

    roles = aux.get("internal_branch_roles", ("recurrent", "long", "manoeuvre"))
    branch_losses = []
    for index, role in enumerate(roles, start=1):
        if role == "long":
            loss = weighted_huber(candidates[:, index, 30:], target[:, 30:])
        elif role == "manoeuvre":
            loss = weighted_huber(candidates[:, index, :30], target[:, :30])
        else:
            loss = weighted_huber(candidates[:, index], target)
        branch_losses.append(loss)
    active = aux.get("internal_active_mask")
    if active is None:
        active = torch.ones(4, dtype=torch.bool, device=target.device)
    selected_branch_losses = [
        loss for index, loss in enumerate(branch_losses, start=1) if bool(active[index])
    ]
    expert_loss = (
        torch.stack(selected_branch_losses).mean()
        if selected_branch_losses else target.sum() * 0.0
    )

    distances = torch.linalg.vector_norm(candidates - target[:, None], dim=-1)
    knot_steps = tuple(aux.get("internal_oracle_steps", (15, 30, 60, 90, 135, 180)))
    cumulative_errors = torch.stack(
        [distances[:, :, :step].mean(dim=-1) for step in knot_steps], dim=-1
    )
    detached = cumulative_errors.detach()
    scale = detached.mean(dim=1, keepdim=True).clamp_min(1e-4)
    # A small core preference demands a meaningful reduction before a more
    # complex branch becomes the oracle winner.
    role_penalty = {"recurrent": 0.02, "long": 0.03, "manoeuvre": 0.02}
    complexity = torch.tensor(
        (0.0, *[role_penalty.get(role, 0.02) for role in roles]),
        dtype=target.dtype,
        device=target.device,
    ).view(1, candidates.shape[1], 1)
    oracle_logits = -detached / (0.20 * scale) - complexity
    oracle_logits = oracle_logits.masked_fill(
        ~active.view(1, -1, 1), -1e4
    )
    oracle = torch.softmax(oracle_logits, dim=1)
    router_loss = -(
        oracle * torch.log(knot_weights.clamp_min(1e-8))
    ).sum(dim=1).mean()
    return expert_loss, router_loss


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True


def _append_jsonl(path: Path, payload: dict) -> None:
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False) + "\n")


def _atomic_torch_save(payload: dict, path: Path) -> None:
    """Never leave a half-written checkpoint after an interrupted save."""
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


@torch.no_grad()
def collect_predictions(model, loader, scaler, device):
    model.eval()
    predictions, targets, cv3_predictions = [], [], []
    total_loss, count = 0.0, 0
    for history, target, _ in loader:
        history = history.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        prediction, aux = model(history, return_aux=True)
        batch = history.shape[0]
        total_loss += float(weighted_huber(prediction, target)) * batch
        count += batch
        predictions.append(prediction.cpu().numpy())
        targets.append(target.cpu().numpy())
        calibration_reference = aux.get("calibration_reference", aux["candidates"][:, 0])
        cv3_predictions.append(calibration_reference.cpu().numpy())
    pred = np.concatenate(predictions)
    truth = np.concatenate(targets)
    cv3 = np.concatenate(cv3_predictions)
    pred_m = scaler.inverse_positions(pred)
    truth_m = scaler.inverse_positions(truth)
    cv3_m = scaler.inverse_positions(cv3)
    return total_loss / max(count, 1), pred_m, truth_m, cv3_m


def _distribution_summary(values: np.ndarray) -> dict[str, float]:
    return {
        "mean": float(np.mean(values)),
        "std": float(np.std(values)),
        "q10": float(np.quantile(values, 0.10)),
        "median": float(np.quantile(values, 0.50)),
        "q90": float(np.quantile(values, 0.90)),
    }


@torch.no_grad()
def collect_adaptive_diagnostics(model, loader, scaler, device):
    """Summarize adaptive dynamics, routing and residual release by motion regime."""

    model.eval()
    predictions, targets = [], []
    descriptors, taus, clip_ratios = [], [], []
    expert_weights, residual_gates = [], []
    internal_weights, internal_releases, internal_disagreements = [], [], []
    knot_indices = np.asarray([step - 1 for step in model.knot_steps], dtype=np.int64)
    for history, target, _ in loader:
        history = history.to(device, non_blocking=True)
        prediction, aux = model(history, return_aux=True)
        required = {
            "descriptors", "adaptive_tau", "adaptive_clip_ratio",
            "expert_weights", "residual_gate",
        }
        if not required.issubset(aux):
            return None
        predictions.append(prediction.cpu().numpy())
        targets.append(target.numpy())
        descriptors.append(aux["descriptors"].cpu().numpy())
        taus.append(aux["adaptive_tau"].cpu().numpy())
        clip_ratios.append(aux["adaptive_clip_ratio"].cpu().numpy())
        expert_weights.append(aux["expert_weights"].cpu().numpy()[..., knot_indices])
        residual_gates.append(aux["residual_gate"].cpu().numpy()[:, knot_indices])
        if "internal_expert_weights" in aux:
            internal_weights.append(
                aux["internal_expert_weights"].cpu().numpy()[..., knot_indices]
            )
            internal_releases.append(aux["internal_release"].cpu().numpy())
            internal_disagreements.append(aux["internal_disagreement"].cpu().numpy())

    prediction_m = scaler.inverse_positions(np.concatenate(predictions))
    target_m = scaler.inverse_positions(np.concatenate(targets))
    descriptor_values = np.concatenate(descriptors)
    tau = np.concatenate(taus).reshape(-1)
    clip_ratio = np.concatenate(clip_ratios).reshape(-1)
    weights = np.concatenate(expert_weights)
    gates = np.concatenate(residual_gates)
    hetero_weights = np.concatenate(internal_weights) if internal_weights else None
    hetero_release = np.concatenate(internal_releases) if internal_releases else None
    hetero_disagreement = (
        np.concatenate(internal_disagreements) if internal_disagreements else None
    )

    turn_score = descriptor_values[:, 1] + descriptor_values[:, 4]
    dynamics_score = (
        descriptor_values[:, 0]
        + np.abs(descriptor_values[:, 2])
        + descriptor_values[:, 3]
        + np.abs(descriptor_values[:, 5])
    )
    turn_median, turn_high = np.quantile(turn_score, (0.50, 0.75))
    dynamics_median, dynamics_high = np.quantile(dynamics_score, (0.50, 0.75))
    regimes = np.full(len(tau), "mixed", dtype=object)
    regimes[(turn_score <= turn_median) & (dynamics_score <= dynamics_median)] = "steady"
    regimes[dynamics_score >= dynamics_high] = "speed_change"
    regimes[turn_score >= turn_high] = "turning"

    horizon_labels = tuple(HORIZONS)
    expert_names = tuple(model.expert_names)

    def summarize(mask: np.ndarray) -> dict:
        selected_weights = weights[mask]
        selected_gates = gates[mask]
        summary = {
            "count": int(mask.sum()),
            "fraction": float(mask.mean()),
            "adaptive_tau": _distribution_summary(tau[mask]),
            "adaptive_clip_ratio": _distribution_summary(clip_ratio[mask]),
            "expert_usage_by_horizon": {
                label: {
                    expert: float(selected_weights[:, expert_index, horizon_index].mean())
                    for expert_index, expert in enumerate(expert_names)
                }
                for horizon_index, label in enumerate(horizon_labels)
            },
            "residual_gate_by_horizon": {
                label: float(selected_gates[:, horizon_index].mean())
                for horizon_index, label in enumerate(horizon_labels)
            },
            "raw_metrics": displacement_metrics(prediction_m[mask], target_m[mask]),
        }
        if hetero_weights is not None:
            internal_names = tuple(model.internal_expert_names)
            summary.update(
                {
                    "internal_expert_usage_by_horizon": {
                        label: {
                            expert: float(
                                hetero_weights[mask, expert_index, horizon_index].mean()
                            )
                            for expert_index, expert in enumerate(internal_names)
                        }
                        for horizon_index, label in enumerate(horizon_labels)
                    },
                    "internal_release_by_horizon": {
                        label: float(hetero_release[mask, horizon_index].mean())
                        for horizon_index, label in enumerate(horizon_labels)
                    },
                    "internal_disagreement_by_horizon": {
                        label: {
                            expert: float(
                                hetero_disagreement[mask, expert_index, horizon_index].mean()
                            )
                            for expert_index, expert in enumerate(internal_names[1:])
                        }
                        for horizon_index, label in enumerate(horizon_labels)
                    },
                }
            )
        return summary

    global_summary = summarize(np.ones(len(tau), dtype=bool))
    tau_low, tau_high = model.tau_range
    clip_low, clip_high = model.clip_ratio_range
    tau_margin = 0.05 * (tau_high - tau_low)
    clip_margin = 0.05 * (clip_high - clip_low)
    global_summary.update(
        {
            "router_entropy": float(
                -(weights * np.log(np.maximum(weights, 1e-12))).sum(axis=1).mean()
            ),
            "tau_lower_boundary_fraction": float((tau <= tau_low + tau_margin).mean()),
            "tau_upper_boundary_fraction": float((tau >= tau_high - tau_margin).mean()),
            "clip_lower_boundary_fraction": float((clip_ratio <= clip_low + clip_margin).mean()),
            "clip_upper_boundary_fraction": float((clip_ratio >= clip_high - clip_margin).mean()),
            "regime_thresholds": {
                "turn_median": float(turn_median),
                "turn_q75": float(turn_high),
                "dynamics_median": float(dynamics_median),
                "dynamics_q75": float(dynamics_high),
            },
        }
    )
    return {
        "global": global_summary,
        "by_motion_regime": {
            name: summarize(regimes == name)
            for name in ("steady", "speed_change", "turning", "mixed")
            if np.any(regimes == name)
        },
    }


def train_model(
    model,
    train_loader,
    validation_loader,
    test_loader,
    scaler,
    device,
    output_dir: Path,
    epochs: int = 80,
    learning_rate: float = 5e-4,
    weight_decay: float = 1e-4,
    min_learning_rate: float = 1e-6,
    patience: int = 20,
    max_training_seconds: float = 0.0,
    coverage_weight: float = 1e-3,
    velocity_weight: float = 0.0,
    acceleration_weight: float = 0.0,
    heading_weight: float = 0.0,
    anchor_weight: float = 0.0,
    tail_weight: float = 0.0,
    intent_weight: float = 0.0,
    alignment_weight: float = 0.0,
    curvature_weight: float = 0.0,
    distillation_weight: float = 0.0,
    heterogeneous_expert_weight: float = 0.0,
    heterogeneous_router_weight: float = 0.0,
    ema_decay: float = 0.0,
    selection_score: str = "legacy",
    resume: bool = False,
    protect_initial_validation: bool = False,
):
    output_dir.mkdir(parents=True, exist_ok=True)
    log_path = output_dir / "training.jsonl"
    checkpoint_path = output_dir / "last.pt"
    best_path = output_dir / "best.pt"
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max(epochs, 1), eta_min=min_learning_rate
    )
    amp_enabled = device.type == "cuda"
    grad_scaler = GradScaler("cuda", enabled=amp_enabled)
    start_epoch, best_score, stale = 1, float("inf"), 0
    if not 0.0 <= ema_decay < 1.0:
        raise ValueError("ema_decay must be in [0, 1)")
    if selection_score not in ("legacy", "goal_normalized", "ade60"):
        raise ValueError(f"Unknown selection score: {selection_score}")
    ema_state = None
    ema_updates = 0
    if ema_decay > 0.0:
        ema_state = {
            name: value.detach().clone()
            for name, value in model.state_dict().items()
        }

    if resume and checkpoint_path.exists():
        state = torch.load(checkpoint_path, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        optimizer.load_state_dict(state["optimizer"])
        scheduler.load_state_dict(state["scheduler"])
        start_epoch = state["epoch"] + 1
        best_score, stale = state["best_score"], state["stale"]
        if ema_decay > 0.0 and state.get("ema_state") is not None:
            ema_state = state["ema_state"]
            ema_updates = int(state.get("ema_updates", 0))

    if protect_initial_validation and start_epoch == 1:
        validation_loss, val_pred, val_truth, _ = collect_predictions(
            model, validation_loader, scaler, device
        )
        val_metrics = displacement_metrics(val_pred, val_truth)
        if selection_score == "goal_normalized":
            best_score = (
                val_metrics["ADE@5"] / 20.0
                + val_metrics["ADE@10"] / 50.0
                + val_metrics["ADE@60"] / 600.0
            )
        elif selection_score == "legacy":
            best_score = val_metrics["ADE@60"] + 2.0 * val_metrics["ADE@10"]
        else:
            best_score = val_metrics["ADE@60"]
        _atomic_torch_save(
            {"model": model.state_dict(), "epoch": 0, "score": best_score}, best_path
        )
        initial_payload = {
            "epoch": 0,
            "phase": "protected_initialization",
            "validation_loss": validation_loss,
            "score": best_score,
            "best_score": best_score,
            "stale": 0,
            "selection_score": selection_score,
            **{f"val_{key}": value for key, value in val_metrics.items()},
        }
        _append_jsonl(log_path, initial_payload)
        print(json.dumps(initial_payload, ensure_ascii=False), flush=True)

    training_started = time.time()
    for epoch in range(start_epoch, epochs + 1):
        started = time.time()
        model.train()
        running_loss, seen = 0.0, 0
        running_components = {
            name: 0.0 for name in (
                "position", "velocity", "acceleration", "heading", "anchor",
                "tail", "intent", "alignment", "curvature",
                "distillation",
                "heterogeneous_expert", "heterogeneous_router",
            )
        }
        for batch in train_loader:
            history, target = batch[0], batch[1]
            teacher = batch[3] if len(batch) == 4 else None
            history = history.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            if teacher is not None:
                teacher = teacher.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with autocast(device_type=device.type, enabled=amp_enabled):
                prediction, aux = model(history, return_aux=True)
                prediction_loss, loss_components = kinematic_multitask_loss(
                    prediction,
                    target,
                    velocity_weight=velocity_weight,
                    acceleration_weight=acceleration_weight,
                    heading_weight=heading_weight,
                    anchor_weight=anchor_weight,
                    tail_weight=tail_weight,
                )
                intent_loss = prediction_loss * 0.0
                if "intent_endpoint" in aux:
                    intent_loss = torch.linalg.vector_norm(
                        aux["intent_endpoint"] - target[:, -1], dim=-1
                    ).mean()
                alignment_loss, curvature_loss = trajectory_shape_losses(
                    prediction, target
                )
                prediction_loss = (
                    prediction_loss
                    + intent_weight * intent_loss
                    + alignment_weight * alignment_loss
                    + curvature_weight * curvature_loss
                )
                distillation_loss = prediction_loss * 0.0
                if teacher is not None and distillation_weight > 0.0:
                    distillation_loss = weighted_huber(prediction, teacher)
                    prediction_loss = prediction_loss + distillation_weight * distillation_loss
                heterogeneous_expert_loss, heterogeneous_router_loss = (
                    heterogeneous_internal_losses(aux, target)
                )
                prediction_loss = (
                    prediction_loss
                    + heterogeneous_expert_weight * heterogeneous_expert_loss
                    + heterogeneous_router_weight * heterogeneous_router_loss
                )
                loss_components.update(
                    {
                        "intent": intent_loss,
                        "alignment": alignment_loss,
                        "curvature": curvature_loss,
                        "distillation": distillation_loss,
                        "heterogeneous_expert": heterogeneous_expert_loss,
                        "heterogeneous_router": heterogeneous_router_loss,
                    }
                )
                coverage_loss = fuzzy_coverage_kl(aux["rule_weights"])
                loss = prediction_loss + coverage_weight * coverage_loss
            grad_scaler.scale(loss).backward()
            grad_scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            grad_scaler.step(optimizer)
            grad_scaler.update()
            if ema_state is not None:
                ema_updates += 1
                # Fast warm-up removes initialization bias; the requested
                # decay becomes active after the first few optimizer steps.
                effective_decay = min(
                    ema_decay, (1.0 + ema_updates) / (10.0 + ema_updates)
                )
                with torch.no_grad():
                    for name, value in model.state_dict().items():
                        if value.is_floating_point():
                            ema_state[name].mul_(effective_decay).add_(
                                value.detach(), alpha=1.0 - effective_decay
                            )
                        else:
                            ema_state[name].copy_(value)
            running_loss += float(loss.detach()) * history.shape[0]
            for name, value in loss_components.items():
                running_components[name] += float(value.detach()) * history.shape[0]
            seen += history.shape[0]

        online_state = None
        if ema_state is not None:
            online_state = {
                name: value.detach().clone()
                for name, value in model.state_dict().items()
            }
            model.load_state_dict(ema_state)
        validation_loss, val_pred, val_truth, _ = collect_predictions(
            model, validation_loader, scaler, device
        )
        val_metrics = displacement_metrics(val_pred, val_truth)
        if selection_score == "goal_normalized":
            score = (
                val_metrics["ADE@5"] / 20.0
                + val_metrics["ADE@10"] / 50.0
                + val_metrics["ADE@60"] / 600.0
            )
        elif selection_score == "legacy":
            score = val_metrics["ADE@60"] + 2.0 * val_metrics["ADE@10"]
        else:
            score = val_metrics["ADE@60"]
        improved = score < best_score - 1e-6
        if improved:
            best_score, stale = score, 0
            _atomic_torch_save({"model": model.state_dict(), "epoch": epoch, "score": score}, best_path)
        else:
            stale += 1
        if online_state is not None:
            model.load_state_dict(online_state)
        scheduler.step()
        payload = {
            "epoch": epoch,
            "train_loss": running_loss / max(seen, 1),
            **{
                f"train_{name}_loss": value / max(seen, 1)
                for name, value in running_components.items()
            },
            "validation_loss": validation_loss,
            "score": score,
            "best_score": best_score,
            "stale": stale,
            "lr": optimizer.param_groups[0]["lr"],
            "ema_decay": ema_decay,
            "ema_updates": ema_updates,
            "selection_score": selection_score,
            "seconds": time.time() - started,
            "elapsed_training_seconds": time.time() - training_started,
            **{f"val_{key}": value for key, value in val_metrics.items()},
        }
        _append_jsonl(log_path, payload)
        print(json.dumps(payload, ensure_ascii=False), flush=True)
        _atomic_torch_save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "epoch": epoch,
                "best_score": best_score,
                "stale": stale,
                "ema_state": ema_state,
                "ema_updates": ema_updates,
            },
            checkpoint_path,
        )
        time_limit_reached = (
            max_training_seconds > 0.0
            and time.time() - training_started >= max_training_seconds
        )
        if stale >= patience or time_limit_reached:
            break

    best = torch.load(best_path, map_location=device, weights_only=False)
    model.load_state_dict(best["model"])
    _, val_pred, val_truth, val_cv3 = collect_predictions(model, validation_loader, scaler, device)
    alpha = fit_cv3_calibration(val_pred, val_cv3, val_truth)
    np.save(output_dir / "calibration_alpha.npy", alpha)

    _, test_pred, test_truth, test_cv3 = collect_predictions(model, test_loader, scaler, device)
    raw_metrics = displacement_metrics(test_pred, test_truth)
    calibrated = apply_calibration(test_pred, test_cv3, alpha)
    calibrated_metrics = displacement_metrics(calibrated, test_truth)
    np.savez_compressed(
        output_dir / "test_predictions.npz",
        prediction=calibrated.astype(np.float32),
        raw_prediction=test_pred.astype(np.float32),
        target=test_truth.astype(np.float32),
    )
    results = {
        "selected_epoch": best["epoch"],
        "validation_score": best["score"],
        "raw": raw_metrics,
        "calibrated": calibrated_metrics,
    }
    if hasattr(model, "expert_names") and hasattr(model, "tau_range"):
        diagnostics = collect_adaptive_diagnostics(model, test_loader, scaler, device)
        if diagnostics is not None:
            diagnostics_path = output_dir / "adaptive_diagnostics.json"
            diagnostics_path.write_text(
                json.dumps(diagnostics, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            results["adaptive_diagnostics"] = diagnostics_path.name
    (output_dir / "test_metrics.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({"test": results}, ensure_ascii=False), flush=True)
    return results
