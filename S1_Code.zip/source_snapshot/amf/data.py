from __future__ import annotations

import csv
import gzip
import json
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset


FEATURE_COLUMNS = (
    "hist_x_json",
    "hist_y_json",
    "hist_time_of_day_sin_json",
    "hist_sog_json",
    "hist_cog_sin_json",
    "hist_cog_cos_json",
)
TARGET_COLUMNS = ("fut_x_json", "fut_y_json")


def _read_json_array(row: dict[str, str], key: str) -> np.ndarray:
    return np.asarray(json.loads(row[key]), dtype=np.float32)


def build_cache(csv_gz: Path, cache_dir: Path, force: bool = False) -> Path:
    """Convert one EnvShip CSV.GZ split into mmap-friendly NPY arrays."""
    cache_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{csv_gz.parents[1].name}_{csv_gz.parent.name}"
    out_dir = cache_dir / stem
    marker = out_dir / "complete.json"
    if marker.exists() and not force:
        return out_dir

    out_dir.mkdir(parents=True, exist_ok=True)
    with gzip.open(csv_gz, "rt", encoding="utf-8", newline="") as stream:
        count = sum(1 for _ in stream) - 1
    if count <= 0:
        raise ValueError(f"No samples in {csv_gz}")

    histories = np.lib.format.open_memmap(
        out_dir / "history.npy", mode="w+", dtype=np.float32, shape=(count, 90, 6)
    )
    futures = np.lib.format.open_memmap(
        out_dir / "future.npy", mode="w+", dtype=np.float32, shape=(count, 180, 2)
    )
    mmsi = np.lib.format.open_memmap(
        out_dir / "mmsi.npy", mode="w+", dtype=np.int64, shape=(count,)
    )

    with gzip.open(csv_gz, "rt", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        for index, row in enumerate(reader):
            histories[index] = np.stack(
                [_read_json_array(row, key) for key in FEATURE_COLUMNS], axis=-1
            )
            futures[index] = np.stack(
                [_read_json_array(row, key) for key in TARGET_COLUMNS], axis=-1
            )
            mmsi[index] = int(row["mmsi"])

    histories.flush()
    futures.flush()
    mmsi.flush()
    marker.write_text(
        json.dumps(
            {"source": str(csv_gz.resolve()), "count": count, "features": FEATURE_COLUMNS},
            indent=2,
        ),
        encoding="utf-8",
    )
    return out_dir


@dataclass
class RobustTrajectoryScaler:
    center: list[float]
    scale: list[float]
    isotropic_position: bool = True

    @classmethod
    def fit(
        cls,
        history: np.ndarray,
        future: np.ndarray,
        isotropic_position: bool = True,
        eps: float = 1e-6,
    ) -> "RobustTrajectoryScaler":
        hx = np.asarray(history)
        fy = np.asarray(future)
        centers = np.zeros(6, dtype=np.float64)
        scales = np.ones(6, dtype=np.float64)

        for dim in range(2):
            values = np.concatenate((hx[..., dim].reshape(-1), fy[..., dim].reshape(-1)))
            q25, med, q75 = np.quantile(values, [0.25, 0.5, 0.75])
            centers[dim] = med
            scales[dim] = max(q75 - q25, eps)
        if isotropic_position:
            shared = float(np.sqrt(scales[0] * scales[1]))
            scales[:2] = max(shared, eps)

        for dim in range(2, 6):
            values = hx[..., dim].reshape(-1)
            q25, med, q75 = np.quantile(values, [0.25, 0.5, 0.75])
            centers[dim] = med
            scales[dim] = max(q75 - q25, eps)
        return cls(centers.tolist(), scales.tolist(), isotropic_position)

    def transform_history(self, history: np.ndarray) -> np.ndarray:
        center = np.asarray(self.center, dtype=np.float32)
        scale = np.asarray(self.scale, dtype=np.float32)
        return (history - center) / scale

    def transform_future(self, future: np.ndarray) -> np.ndarray:
        center = np.asarray(self.center[:2], dtype=np.float32)
        scale = np.asarray(self.scale[:2], dtype=np.float32)
        return (future - center) / scale

    def inverse_positions(self, positions: np.ndarray) -> np.ndarray:
        center = np.asarray(self.center[:2], dtype=np.float32)
        scale = np.asarray(self.scale[:2], dtype=np.float32)
        return positions * scale + center

    def save(self, path: Path) -> None:
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "RobustTrajectoryScaler":
        return cls(**json.loads(path.read_text(encoding="utf-8")))


class EnvShipDataset(Dataset):
    def __init__(self, cache_path: Path, scaler: RobustTrajectoryScaler):
        self.history = np.load(cache_path / "history.npy", mmap_mode="r")
        self.future = np.load(cache_path / "future.npy", mmap_mode="r")
        self.mmsi = np.load(cache_path / "mmsi.npy", mmap_mode="r")
        self.scaler = scaler

    def __len__(self) -> int:
        return int(self.history.shape[0])

    def __getitem__(self, index: int):
        history = self.scaler.transform_history(np.asarray(self.history[index]))
        future = self.scaler.transform_future(np.asarray(self.future[index]))
        return (
            torch.from_numpy(history.copy()),
            torch.from_numpy(future.copy()),
            int(self.mmsi[index]),
        )


def resolve_split_file(data_root: Path, domain: str, split: str) -> Path:
    candidates = [
        data_root / domain / split / "part-000.csv.gz",
        data_root
        / "track_b_medium-term_Cross-domain_Datasets"
        / domain
        / "standard_track_v1"
        / split
        / "part-000.csv.gz",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"Cannot find {domain}/{split}/part-000.csv.gz below {data_root}")

