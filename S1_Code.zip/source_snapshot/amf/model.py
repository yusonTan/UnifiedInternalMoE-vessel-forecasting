from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F


class MotionExperts(nn.Module):
    def __init__(self, prediction_steps: int = 180, accel_clip: float = 0.15, tau: float = 15.0):
        super().__init__()
        self.prediction_steps = prediction_steps
        self.accel_clip = accel_clip
        self.tau = tau

    @staticmethod
    def _cv(positions: torch.Tensor, window: int, horizon: torch.Tensor):
        recent = positions[:, -window:, :]
        velocity = torch.diff(recent, dim=1).mean(dim=1)
        return positions[:, -1:, :] + horizon * velocity[:, None, :]

    def forward(self, positions: torch.Tensor):
        dtype, device = positions.dtype, positions.device
        steps = torch.arange(1, self.prediction_steps + 1, device=device, dtype=dtype)
        horizon = steps.view(1, -1, 1)
        cv3 = self._cv(positions, 3, horizon)
        cv6 = self._cv(positions, 6, horizon)
        cv15 = self._cv(positions, 15, horizon)

        displacement = torch.diff(positions[:, -6:, :], dim=1)
        velocity0 = displacement[:, -3:, :].mean(dim=1)
        accel0 = 0.5 * (
            displacement[:, -1, :] - displacement[:, -2, :]
            + displacement[:, -2, :] - displacement[:, -3, :]
        )
        magnitude = torch.linalg.vector_norm(accel0, dim=-1, keepdim=True)
        clipped = accel0 * torch.clamp(self.accel_clip / (magnitude + 1e-8), max=1.0)
        decay = torch.exp(-steps / self.tau).view(1, -1, 1)
        velocities = velocity0[:, None, :] + decay * clipped[:, None, :]
        dca = positions[:, -1:, :] + torch.cumsum(velocities, dim=1)
        return torch.stack((cv3, cv6, cv15, dca), dim=1)


class MotionDescriptors(nn.Module):
    def forward(self, positions: torch.Tensor):
        displacement = torch.diff(positions[:, -15:, :], dim=1)
        speed = torch.linalg.vector_norm(displacement, dim=-1)
        eps = 1e-6
        mean_speed = speed.mean(dim=1).clamp_min(eps)

        speed_fluctuation = speed.std(dim=1, unbiased=False) / mean_speed
        first, second = displacement[:, :-1], displacement[:, 1:]
        cross = first[..., 0] * second[..., 1] - first[..., 1] * second[..., 0]
        dot = (first * second).sum(dim=-1)
        angles = torch.atan2(cross, dot + eps)
        valid = (torch.linalg.vector_norm(first, dim=-1) > eps) & (
            torch.linalg.vector_norm(second, dim=-1) > eps
        )
        valid_f = valid.to(positions.dtype)
        valid_count = valid_f.sum(dim=1).clamp_min(1.0)
        abs_turn = (angles.abs() * valid_f).sum(dim=1) / valid_count
        angle_mean = (angles * valid_f).sum(dim=1) / valid_count
        turn_var = ((angles - angle_mean[:, None]).square() * valid_f).sum(dim=1) / valid_count
        turn_dispersion = torch.sqrt(turn_var + eps)

        speed_trend = (speed[:, -5:].mean(dim=1) - speed[:, :5].mean(dim=1)) / mean_speed
        v3 = displacement[:, -2:, :].mean(dim=1)
        v15 = displacement.mean(dim=1)
        window_inconsistency = torch.linalg.vector_norm(v3 - v15, dim=-1) / (
            torch.linalg.vector_norm(v15, dim=-1) + eps
        )
        recent_offset = (speed[:, -5:].mean(dim=1) - mean_speed) / mean_speed
        raw = torch.stack(
            (
                speed_fluctuation,
                abs_turn / math.pi,
                speed_trend,
                window_inconsistency,
                turn_dispersion / math.pi,
                recent_offset,
            ),
            dim=-1,
        )
        return torch.clamp(torch.tanh(raw), -1.0, 1.0)


class TSKFuzzyGate(nn.Module):
    def __init__(self, input_dim: int = 6, rules: int = 8, output_dim: int = 24):
        super().__init__()
        semantic_centers = torch.tensor(
            [
                [-0.7, -0.7, 0.0, -0.7, -0.7, 0.0],
                [0.0, -0.7, 0.6, 0.0, -0.7, 0.6],
                [0.0, -0.7, -0.6, 0.0, -0.7, -0.6],
                [0.2, 0.6, 0.0, 0.4, 0.5, 0.0],
                [0.7, 0.0, 0.5, 0.6, 0.2, 0.5],
                [0.7, 0.0, -0.5, 0.6, 0.2, -0.5],
                [0.4, 0.7, 0.0, 0.8, 0.7, 0.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            ],
            dtype=torch.float32,
        )
        self.centers = nn.Parameter(semantic_centers[:, :input_dim].clone())
        initial_sigma = torch.full((rules, input_dim), 0.55)
        self.raw_sigmas = nn.Parameter(torch.log(torch.expm1(initial_sigma)))
        self.consequents = nn.Parameter(torch.zeros(rules, input_dim + 1, output_dim))

    def forward(self, descriptors: torch.Tensor):
        sigma = F.softplus(self.raw_sigmas) + 1e-4
        difference = descriptors[:, None, :] - self.centers[None, :, :]
        log_firing = -0.5 * ((difference / sigma[None, :, :]) ** 2).sum(dim=-1)
        normalized = torch.softmax(log_firing, dim=1)
        augmented = torch.cat((torch.ones_like(descriptors[:, :1]), descriptors), dim=-1)
        rule_outputs = torch.einsum("bi,qio->bqo", augmented, self.consequents)
        correction = torch.sum(normalized.unsqueeze(-1) * rule_outputs, dim=1)
        return correction, normalized


class DescriptorRouterResidual(nn.Module):
    """Small non-fuzzy descriptor branch for horizon-aware expert routing."""

    def __init__(self, input_dim: int = 6, hidden_dim: int = 32, output_dim: int = 24):
        super().__init__()
        self.network = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, output_dim),
        )
        with torch.no_grad():
            self.network[-1].weight.zero_()
            self.network[-1].bias.zero_()

    def forward(self, descriptors: torch.Tensor) -> torch.Tensor:
        return self.network(descriptors)


class MonotoneHorizonGate(nn.Module):
    """Infer a sample-specific release schedule that cannot decrease with horizon."""

    def __init__(self, input_dim: int, initial_probabilities: tuple[float, ...]):
        super().__init__()
        if len(initial_probabilities) < 2:
            raise ValueError("At least two horizon knots are required")
        if any(not 0.0 < value < 1.0 for value in initial_probabilities):
            raise ValueError("Initial gate probabilities must lie strictly between zero and one")
        if any(right <= left for left, right in zip(initial_probabilities, initial_probabilities[1:])):
            raise ValueError("Initial gate probabilities must be strictly increasing")

        self.projection = nn.Linear(input_dim, len(initial_probabilities))
        logits = [math.log(value / (1.0 - value)) for value in initial_probabilities]
        increments = [right - left for left, right in zip(logits, logits[1:])]
        raw_increments = [math.log(math.expm1(value)) for value in increments]
        with torch.no_grad():
            self.projection.weight.zero_()
            self.projection.bias.copy_(
                torch.tensor((logits[0], *raw_increments), dtype=self.projection.bias.dtype)
            )

    def forward(self, representation: torch.Tensor) -> torch.Tensor:
        parameters = self.projection(representation)
        base = parameters[:, :1]
        increments = F.softplus(parameters[:, 1:])
        logits = torch.cat((base, base + torch.cumsum(increments, dim=-1)), dim=-1)
        return torch.sigmoid(logits)


class AMFResLSTM(nn.Module):
    knot_steps = (15, 30, 60, 90, 135, 180)

    def __init__(
        self,
        input_size: int = 6,
        hidden_size: int = 128,
        prediction_steps: int = 180,
        dropout: float = 0.1,
        accel_clip: float = 0.15,
        accel_tau: float = 15.0,
        use_tsk: bool = False,
        use_descriptor_router: bool = False,
        variant: str = "full",
    ):
        super().__init__()
        self.prediction_steps = prediction_steps
        self.use_tsk = use_tsk
        if use_tsk and use_descriptor_router:
            raise ValueError("TSK and descriptor router cannot be enabled together")
        self.use_descriptor_router = use_descriptor_router
        self.variant = variant
        self.encoder = nn.LSTM(
            input_size,
            hidden_size,
            num_layers=2,
            batch_first=True,
            dropout=dropout,
        )
        self.neural_gate = nn.Linear(hidden_size, 4 * len(self.knot_steps))
        self.descriptors = MotionDescriptors()
        self.tsk = TSKFuzzyGate(6, 8, 4 * len(self.knot_steps)) if use_tsk else None
        self.descriptor_router = (
            DescriptorRouterResidual(6, 32, 4 * len(self.knot_steps))
            if use_descriptor_router
            else None
        )
        self.experts = MotionExperts(prediction_steps, accel_clip, accel_tau)
        self.residual = nn.Sequential(
            nn.Linear(hidden_size, 128),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(128, prediction_steps * 2),
        )
        self.residual_release = MonotoneHorizonGate(
            hidden_size, (0.05, 0.08, 0.15, 0.30, 0.55, 0.80)
        )
        self.dca_release = MonotoneHorizonGate(
            hidden_size, (0.10, 0.15, 0.25, 0.45, 0.70, 0.90)
        )

    def _interpolate_logits(self, knot_logits: torch.Tensor) -> torch.Tensor:
        # Exact knots at steps 15/30/60/90/135/180, constant before step 15.
        device, dtype = knot_logits.device, knot_logits.dtype
        query = torch.arange(1, self.prediction_steps + 1, device=device, dtype=dtype)
        knots = torch.tensor(self.knot_steps, device=device, dtype=dtype)
        right = torch.searchsorted(knots, query, right=False).clamp(max=len(self.knot_steps) - 1)
        left = (right - 1).clamp(min=0)
        x0, x1 = knots[left], knots[right]
        ratio = torch.where(x1 > x0, (query - x0) / (x1 - x0), torch.zeros_like(query))
        left_values = knot_logits.index_select(-1, left)
        right_values = knot_logits.index_select(-1, right)
        expand = (1,) * (knot_logits.ndim - 1) + (-1,)
        return left_values + ratio.view(expand) * (right_values - left_values)

    def forward(self, history: torch.Tensor, return_aux: bool = False):
        positions = history[..., :2]
        candidates = self.experts(positions)
        encoded, _ = self.encoder(history)
        representation = encoded[:, -1]

        neural_logits = self.neural_gate(representation).view(-1, 4, len(self.knot_steps))
        descriptor_values = self.descriptors(positions)
        knot_logits = neural_logits
        if self.tsk is not None:
            correction, rule_weights = self.tsk(descriptor_values)
            correction = correction.view(-1, 4, len(self.knot_steps))
            knot_logits = knot_logits + 0.5 * torch.tanh(correction)
        elif self.descriptor_router is not None:
            correction = self.descriptor_router(descriptor_values)
            correction = correction.view(-1, 4, len(self.knot_steps))
            knot_logits = knot_logits + 0.5 * torch.tanh(correction)
            rule_weights = torch.ones(
                descriptor_values.shape[0], 1,
                dtype=descriptor_values.dtype, device=descriptor_values.device,
            )
        else:
            rule_weights = torch.ones(
                descriptor_values.shape[0], 1,
                dtype=descriptor_values.dtype, device=descriptor_values.device,
            )
        weights = torch.softmax(self._interpolate_logits(knot_logits), dim=1)
        dca_release_knots = self.dca_release(representation)
        dca_release = self._interpolate_logits(dca_release_knots)
        if self.variant == "uniform_gate":
            weights = torch.full_like(weights, 0.25)
        elif self.variant == "cv3_only":
            weights = torch.zeros_like(weights)
            weights[:, 0] = 1.0
        elif self.variant == "no_dca":
            weights = torch.cat((weights[:, :3], torch.zeros_like(weights[:, 3:4])), dim=1)
            weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        else:
            weights = torch.cat(
                (weights[:, :3], weights[:, 3:4] * dca_release.unsqueeze(1)), dim=1
            )
            weights = weights / weights.sum(dim=1, keepdim=True).clamp_min(1e-8)
        prior = torch.sum(weights.unsqueeze(-1) * candidates, dim=1)
        raw_residual = self.residual(representation).view(-1, self.prediction_steps, 2)
        residual_release_knots = self.residual_release(representation)
        residual_release = self._interpolate_logits(residual_release_knots)
        residual = raw_residual * residual_release.unsqueeze(-1)
        if self.variant == "no_residual":
            residual = torch.zeros_like(residual)
        elif self.variant == "lstm_only":
            prior = torch.zeros_like(prior)
        prediction = prior + residual
        if not return_aux:
            return prediction
        return prediction, {
            "prior": prior,
            "residual": residual,
            "candidates": candidates,
            "expert_weights": weights,
            "neural_knot_logits": neural_logits,
            "combined_knot_logits": knot_logits,
            "rule_weights": rule_weights,
            "descriptors": descriptor_values,
            "residual_release": residual_release,
            "dca_release": dca_release,
        }

    @property
    def parameter_count(self) -> int:
        return sum(parameter.numel() for parameter in self.parameters())


def load_amf_state_compatible(
    model: AMFResLSTM, state_dict: dict[str, torch.Tensor]
) -> dict[str, int | bool]:
    """Strictly load shared AMF weights while dropping legacy TSK tensors.

    This keeps old checkpoints usable after TSK removal. Only ``tsk.*`` keys may
    be discarded; every remaining tensor is still checked by strict loading.
    """
    tsk_keys = [key for key in state_dict if key.startswith("tsk.")]
    if model.tsk is None:
        state_dict = {
            key: value for key, value in state_dict.items() if not key.startswith("tsk.")
        }
    result = model.load_state_dict(state_dict, strict=False)
    allowed_missing = (
        {
            key
            for key in model.state_dict()
            if key.startswith("descriptor_router.") and key not in state_dict
        }
        if model.descriptor_router is not None
        else set()
    )
    if set(result.missing_keys) != allowed_missing or result.unexpected_keys:
        raise RuntimeError(
            "Incompatible AMF checkpoint: "
            f"missing={result.missing_keys}, unexpected={result.unexpected_keys}"
        )
    return {
        "checkpoint_has_tsk": bool(tsk_keys),
        "tsk_removed": bool(tsk_keys and model.tsk is None),
        "dropped_tsk_tensors": len(tsk_keys) if model.tsk is None else 0,
        "initialized_descriptor_tensors": len(allowed_missing),
    }


def fuzzy_coverage_kl(rule_weights: torch.Tensor) -> torch.Tensor:
    average = rule_weights.mean(dim=0).clamp_min(1e-8)
    uniform = 1.0 / average.numel()
    return torch.sum(average * torch.log(average / uniform))
