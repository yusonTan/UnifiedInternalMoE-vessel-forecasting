"""Frozen plan and standard-library safety helpers for the queued 16-hour run."""
from __future__ import annotations
import ctypes
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'revision_followup16_20261010'
RUN_STORAGE = Path('E:/OE_revision16_20261010')
DEPENDENCY = ROOT / 'revision_probability_20261010'
PREVIOUS = ROOT / 'revision_2h_20261009'
REFERENCE = ROOT / 'revision_7h_20261009'
DOMAINS = ('dma', 'noaa', 'norway', 'piraeus')
SMALL = ('norway', 'piraeus')
SEEDS = (42, 52, 62)
FIVE_SEEDS = (*SEEDS, 72, 82)
PRIMARY = ('full', 'no_dca', 'no_residual')
VARIANTS = ('full', 'no_dca', 'no_residual', 'uniform_router',
            'single_scale', 'ungated_residual', 'no_spline', 'no_intent')
RESERVE_SECONDS = 90 * 60
BUDGET_SECONDS = 16 * 3600
SOURCE_FILES = ('revision_followup16_common.py', 'run_revision_followup16.py',
    'revision_followup16_training.py', 'revision_followup16_results.py',
    'tests/test_revision_followup16.py', 'train.py', 'amf/trainer.py',
    'amf/adaptive_moe.py', 'amf/metrics.py', 'amf/data.py',
    'run_complete_study_stage.py', 'evaluate_compact_committee.py',
    'revision_2h_results.py', 'revision_5h_analysis.py', 'run_plos_rigor_suite.py')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    os.replace(temp, path)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            digest.update(block)
    return digest.hexdigest()


def sources():
    # Include all imported model implementations, not just the entry point.
    paths = set(SOURCE_FILES) | {str(p.relative_to(ROOT)) for p in (ROOT / 'amf').glob('*.py')}
    paths |= {'run_revision_5h.py', 'run_revision_2h.py', 'run_revision_7h.py',
              'amf/unified_predictor.py', 'train_comparison_model.py', 'train_faithful_sota.py'}
    return {name: sha(ROOT / name) for name in sorted(paths)}


def emit(event, **details):
    row = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, **details}
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / 'events.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
    atomic(OUT / 'STATUS.json', row)
    print(json.dumps(row, ensure_ascii=False, default=str), flush=True)


class FileLock:
    """Windows advisory lock released by the OS on process exit/crash."""
    def __init__(self, path):
        self.path, self.stream = Path(path), None

    def acquire(self):
        import msvcrt
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.stream = self.path.open('a+b')
        self.stream.seek(0)
        try:
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self.stream.close()
            self.stream = None
            return False
        return True

    def release(self):
        if self.stream is not None:
            import msvcrt
            self.stream.seek(0)
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            self.stream.close()
            self.stream = None


def keep_awake(enabled):
    if os.name == 'nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001 if enabled else 0x80000000)


def unit(variant, domain, seed, priority):
    return {'variant': variant, 'domain': domain, 'seed': seed, 'priority': priority,
            'label': f'{variant}/{domain}/seed_{seed}'}


def plan():
    main = [unit(v, d, s, 'primary_four_domain_three_seed')
            for s in SEEDS for v in PRIMARY for d in DOMAINS]
    extra = [unit(v, d, s, 'secondary_small_domain_five_seed')
             for s in FIVE_SEEDS for v in VARIANTS for d in SMALL
             if not (s in SEEDS and v in PRIMARY)]
    optional = [unit('uniform_router', d, s, 'optional_complete_large_uniform_cohort')
                for s in SEEDS for d in ('dma', 'noaa')]
    return main, extra, optional


def new_run(item, stage):
    return RUN_STORAGE / 'SA_matched' / item['variant'] / stage / item['domain'] / f"seed_{item['seed']}"


def existing_run(item, stage):
    if item['domain'] not in SMALL:
        return None  # All large-domain controls are freshly retrained.
    if item['seed'] in SEEDS and item['variant'] in ('full', 'no_dca', 'no_residual', 'uniform_router'):
        return PREVIOUS / 'SA_matched' / item['variant'] / stage / item['domain'] / f"seed_{item['seed']}"
    if item['seed'] in (72, 82) and item['variant'] == 'full':
        base = 'SA_seed_pretraining' if stage == 'pretraining' else 'SA_seed_repair'
        return PREVIOUS / base / item['domain'] / f"seed_{item['seed']}"
    return None


def finished(run):
    if run is None:
        return False
    return all((run / name).exists() for name in ('best.pt', 'config.json', 'test_metrics.json', 'test_predictions.npz'))


def selected_run(item, stage):
    fresh, previous = new_run(item, stage), existing_run(item, stage)
    return fresh if finished(fresh) else previous if finished(previous) else fresh


def estimate_seconds(item):
    # Admission estimate includes both training stages and test/diagnostics I/O.
    if item['domain'] == 'dma':
        return 47 * 60
    if item['domain'] == 'noaa':
        return 40 * 60
    return (3.5 if item['domain'] == 'norway' else 2.5) * 60


def can_admit(item, deadline, now=None):
    return (time.time() if now is None else now) + estimate_seconds(item) + RESERVE_SECONDS < deadline


def validate_config(item, run, stage):
    c = read(run / 'config.json')
    component = 'router_sharp150' if stage == 'repair' and item['variant'] == 'full' else item['variant']
    expected = {'domain': item['domain'], 'seed': item['seed'], 'model': 'intent_multiscale_moe',
        'v6_variant': 'joint_aligned_intent_spline', 'component_ablation': component,
        'epochs': 120 if stage == 'pretraining' else 60, 'batch_size': 256, 'num_workers': 0,
        'learning_rate': .0001 if stage == 'pretraining' else .00002,
        'weight_decay': .0001, 'min_learning_rate': .0000005,
        'patience': 24 if stage == 'pretraining' else 12,
        'router_temperature_override': 1.0 if stage == 'pretraining' else 1.5,
        'selection_score': 'ade60', 'coverage_weight': 0., 'velocity_weight': .08,
        'acceleration_weight': .02, 'heading_weight': .008, 'anchor_weight': .08,
        'tail_weight': 1., 'intent_weight': .05, 'alignment_weight': .005,
        'curvature_weight': .002, 'ema_decay': 0., 'difficulty_sampling_strength': 0.,
        'distillation_weight': 0., 'quick_smoke': False, 'protect_initial_validation': False,
        'max_training_seconds': 0. if stage == 'pretraining' else (240. if item['domain'] in SMALL else 600.)}
    errors = {k: (c.get(k), v) for k, v in expected.items() if c.get(k) != v}
    if errors:
        raise RuntimeError(f'Unmatched training protocol at {run}: {errors}')
    if stage == 'pretraining' and c.get('init_checkpoint') is not None:
        raise RuntimeError('Ablation pretraining must start from random initialization')
    if stage == 'repair':
        predecessor = selected_run(item, 'pretraining') / 'best.pt'
        if Path(c['init_checkpoint']).resolve() != predecessor.resolve():
            raise RuntimeError(f'Repair does not use its own ablated pretrained model: {run}')
        if c['initialization']['missing_tensors'] or c['initialization']['unexpected_tensors']:
            raise RuntimeError('Partial checkpoint initialization is not a matched ablation')
    return c


def validate_dependency(path=DEPENDENCY):
    """A process exiting is insufficient: require all twenty evaluated runs."""
    completion = path / 'COMPLETE.json'
    if not completion.exists():
        return False
    marker = read(completion)
    if marker.get('complete') is not True or marker.get('runs') != 20:
        raise RuntimeError('Probability dependency completion marker is invalid')
    protocol = read(path / 'PROTOCOL.json')
    for name, digest in protocol['source_hashes'].items():
        if sha(ROOT / name) != digest:
            raise RuntimeError(f'Probability dependency source drift: {name}')
    for domain in DOMAINS:
        for seed in FIVE_SEEDS:
            run = path / domain / f'seed_{seed}'
            for name in ('TRAINING_COMPLETE.json', 'result.json', 'best.pt', 'test_predictions.npz'):
                if not (run / name).exists():
                    raise RuntimeError(f'Incomplete probability dependency: {run / name}')
            r = read(run / 'result.json')
            if r.get('domain') != domain or r.get('seed') != seed or r.get('primary_prediction') != 'conditional_mean':
                raise RuntimeError('Unexpected probability result identity')
            if r['checkpoint_sha256'] != sha(run / 'best.pt'):
                raise RuntimeError('Probability checkpoint changed after evaluation')
    return True
