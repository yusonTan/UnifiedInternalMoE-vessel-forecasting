from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
import torch
from torch.amp import GradScaler, autocast
from torch.utils.data import DataLoader, Subset

from amf.data import EnvShipDataset, RobustTrajectoryScaler, build_cache, resolve_split_file
from amf.metrics import displacement_metrics, weighted_huber
from amf.trainer import seed_everything
from faithful_sota_models import FAITHFUL_SPECS, build_faithful_model


ROOT = Path(__file__).resolve().parent


def atomic_torch_save(payload, path: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save(payload, temporary)
    os.replace(temporary, path)


def append_jsonl(path: Path, payload: dict) -> None:
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(payload, ensure_ascii=False) + "\n")


@torch.no_grad()
def evaluate(model, loader, scaler, device, save_path: Path | None = None):
    model.eval()
    predictions, targets, identifiers = [], [], []
    for history, target, mmsi in loader:
        prediction = model(history.to(device, non_blocking=True))
        predictions.append(prediction.float().cpu().numpy())
        targets.append(target.numpy())
        identifiers.append(np.asarray(mmsi))
    prediction_m = scaler.inverse_positions(np.concatenate(predictions))
    target_m = scaler.inverse_positions(np.concatenate(targets))
    if save_path is not None:
        np.savez_compressed(
            save_path,
            prediction=prediction_m.astype(np.float32),
            target=target_m.astype(np.float32),
            mmsi=np.concatenate(identifiers).astype(np.int64),
        )
    return displacement_metrics(prediction_m, target_m)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=tuple(FAITHFUL_SPECS), required=True)
    parser.add_argument("--domain", choices=("dma", "noaa", "norway", "piraeus"), default="dma")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-root", type=Path, default=ROOT / "submission_experiments")
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--quick-smoke", action="store_true")
    args = parser.parse_args()

    seed_everything(args.seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True
    spec = FAITHFUL_SPECS[args.model]
    epochs = 2 if args.quick_smoke else int(spec["epochs"])
    patience = 2 if args.quick_smoke else int(spec["patience"])
    run = args.output_root / "faithful_sota" / args.model / args.domain / f"seed_{args.seed}"
    run.mkdir(parents=True, exist_ok=True)

    scaler = RobustTrajectoryScaler.load(ROOT / "cache" / args.domain / "scaler.json")
    datasets = {}
    for split in ("train", "val", "test"):
        source = resolve_split_file(ROOT.parent / "data", args.domain, split)
        cache = build_cache(source, ROOT / "cache" / args.domain, force=False)
        datasets[split] = EnvShipDataset(cache, scaler)
    if args.quick_smoke:
        limits = {"train": 256, "val": 128, "test": 128}
        datasets = {name: Subset(dataset, range(min(len(dataset), limits[name]))) for name, dataset in datasets.items()}

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = int(spec["batch_size"])
    loaders = {
        name: DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=name == "train",
            num_workers=args.num_workers,
            pin_memory=device.type == "cuda",
            persistent_workers=args.num_workers > 0,
        )
        for name, dataset in datasets.items()
    }
    model = build_faithful_model(args.model).to(device)
    optimizer_class = torch.optim.Adam if spec["optimizer"] == "Adam" else torch.optim.AdamW
    optimizer = optimizer_class(model.parameters(), lr=float(spec["lr"]), weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-6)
    scaler_amp = GradScaler("cuda", enabled=device.type == "cuda")
    accumulation = int(spec["accumulation"])
    best_score, stale, start_epoch = float("inf"), 0, 1
    best_path, last_path = run / "best.pt", run / "last.pt"
    if args.resume and last_path.exists():
        checkpoint = torch.load(last_path, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_epoch = int(checkpoint["epoch"]) + 1
        best_score, stale = float(checkpoint["best_score"]), int(checkpoint["stale"])

    config = {
        "model": args.model,
        "paper": spec["paper"],
        "reproduction_status": "paper-faithful common-protocol implementation",
        "shared_protocol": {
            "domain": args.domain,
            "input": "90x6",
            "output": "180x2",
            "sampling_seconds": 20,
            "split": "released MMSI-disjoint train/validation/test",
            "scaler": "current-domain train-only RobustScaler",
            "loss": "weighted Huber; steps 1-30 weight 2",
            "checkpoint": "validation ADE@60 + 2*ADE@10",
            "metrics": "meter ADE/FDE at 5/10/20/30/45/60 min",
        },
        "optimizer": spec["optimizer"],
        "learning_rate": spec["lr"],
        "batch_size": batch_size,
        "gradient_accumulation": accumulation,
        "effective_batch_size": batch_size * accumulation,
        "epochs": epochs,
        "patience": patience,
        "seed": args.seed,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
        "device": str(device),
    }
    (run / "config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    started = time.time()
    for epoch in range(start_epoch, epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss_sum, count = 0.0, 0
        epoch_started = time.time()
        for batch_index, (history, target, _) in enumerate(loaders["train"], start=1):
            history = history.to(device, non_blocking=True)
            target = target.to(device, non_blocking=True)
            with autocast(device_type=device.type, enabled=device.type == "cuda"):
                prediction = model(history)
                loss = weighted_huber(prediction, target) / accumulation
            scaler_amp.scale(loss).backward()
            if batch_index % accumulation == 0 or batch_index == len(loaders["train"]):
                scaler_amp.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler_amp.step(optimizer)
                scaler_amp.update()
                optimizer.zero_grad(set_to_none=True)
            loss_sum += float(loss.detach()) * accumulation * history.shape[0]
            count += history.shape[0]
        validation = evaluate(model, loaders["val"], scaler, device)
        score = validation["ADE@60"] + 2.0 * validation["ADE@10"]
        if score < best_score - 1e-6:
            best_score, stale = score, 0
            atomic_torch_save({"model": model.state_dict(), "epoch": epoch, "score": score}, best_path)
        else:
            stale += 1
        scheduler.step()
        record = {
            "epoch": epoch,
            "train_loss": loss_sum / max(count, 1),
            "score": score,
            "best_score": best_score,
            "stale": stale,
            "lr": optimizer.param_groups[0]["lr"],
            "seconds": time.time() - epoch_started,
            **{f"val_{key}": value for key, value in validation.items()},
        }
        append_jsonl(run / "training.jsonl", record)
        print(json.dumps(record), flush=True)
        atomic_torch_save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "scheduler": scheduler.state_dict(),
                "epoch": epoch,
                "best_score": best_score,
                "stale": stale,
            },
            last_path,
        )
        if stale >= patience:
            break

    best = torch.load(best_path, map_location=device, weights_only=False)
    model.load_state_dict(best["model"])
    validation = evaluate(model, loaders["val"], scaler, device, run / "validation_predictions.npz")
    test = evaluate(model, loaders["test"], scaler, device, run / "test_predictions.npz")
    result = {
        "model": args.model,
        "domain": args.domain,
        "seed": args.seed,
        "selected_epoch": int(best["epoch"]),
        "validation_score": float(best["score"]),
        "validation": validation,
        "test": test,
        "parameter_count": config["parameter_count"],
        "training_seconds": time.time() - started,
    }
    temporary = run / "result.json.tmp"
    temporary.write_text(json.dumps(result, indent=2), encoding="utf-8")
    os.replace(temporary, run / "result.json")
    print(json.dumps({"result": result}), flush=True)


if __name__ == "__main__":
    main()
