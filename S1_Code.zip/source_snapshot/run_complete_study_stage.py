from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parent
STUDY = ROOT / "complete_3seed_4domain_study"
DOMAINS = ("dma", "noaa", "norway", "piraeus")
SEEDS = (42, 52, 62)
BASELINES = ("direct_lstm", "direct_gru", "tcn_cv", "transformer_cv")
SOTA = ("mstformer_faithful", "itransformer_fa_faithful")
CORE_ABLATIONS = (
    "no_local_frame", "single_scale", "no_descriptors", "fixed_dynamics",
    "uniform_router", "no_dca", "cv3_only", "no_residual",
    "ungated_residual", "no_spline", "no_intent",
)
NEGATIVE_CONTROLS = ("add_temporal_attention", "add_tsk")


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def emit(stage_root: Path, event: str, **payload) -> None:
    row = {"time": datetime.now().isoformat(timespec="seconds"), "event": event, **payload}
    stage_root.mkdir(parents=True, exist_ok=True)
    with (stage_root / "events.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    atomic_json(stage_root / "status.json", row)
    print(json.dumps(row, ensure_ascii=False), flush=True)


def common_sa_command(output: Path, domain: str, seed: int, ablation: str) -> list[str]:
    return [
        sys.executable, "-u", "train.py",
        "--data-root", str(ROOT.parent / "data"),
        "--cache-dir", str(ROOT / "cache"),
        "--output-dir", str(output),
        "--domain", domain,
        "--seed", str(seed),
        "--model", "intent_multiscale_moe",
        "--v6-variant", "joint_aligned_intent_spline",
        "--component-ablation", ablation,
        "--epochs", "120",
        "--batch-size", "256",
        "--num-workers", "2",
        "--learning-rate", "0.0001",
        "--weight-decay", "0.0001",
        "--min-learning-rate", "0.0000005",
        "--patience", "24",
        "--coverage-weight", "0",
        "--velocity-weight", "0.08",
        "--acceleration-weight", "0.02",
        "--heading-weight", "0.008",
        "--anchor-weight", "0.08",
        "--tail-weight", "1.0",
        "--intent-weight", "0.05",
        "--alignment-weight", "0.005",
        "--curvature-weight", "0.002",
        "--selection-score", "ade60",
    ]


def stage1_tasks(smoke: bool):
    domains = DOMAINS[:1] if smoke else DOMAINS
    seeds = SEEDS[:1] if smoke else SEEDS
    comparison = STUDY / "comparisons"
    for domain in domains:
        for model in BASELINES:
            for seed in seeds:
                marker = comparison / "runs" / model / domain / f"seed_{seed}" / "result.json"
                command = [
                    sys.executable, "-u", "train_comparison_model.py",
                    "--model", model, "--domain", domain, "--seed", str(seed),
                    "--output-root", str(comparison), "--num-workers", "2",
                ]
                if smoke:
                    command.append("--quick-smoke")
                yield f"baseline/{model}/{domain}/seed_{seed}", marker, command
        for model in SOTA:
            for seed in seeds:
                marker = comparison / "faithful_sota" / model / domain / f"seed_{seed}" / "result.json"
                command = [
                    sys.executable, "-u", "train_faithful_sota.py",
                    "--model", model, "--domain", domain, "--seed", str(seed),
                    "--output-root", str(comparison), "--num-workers", "2",
                ]
                if smoke:
                    command.append("--quick-smoke")
                yield f"sota/{model}/{domain}/seed_{seed}", marker, command
        for seed in seeds:
            predecessor = comparison / "ours" / "amf_predecessor"
            marker = predecessor / domain / f"seed_{seed}" / "test_metrics.json"
            command = [
                sys.executable, "-u", "train.py", "--data-root", str(ROOT.parent / "data"),
                "--cache-dir", str(ROOT / "cache"), "--output-dir", str(predecessor),
                "--domain", domain, "--seed", str(seed), "--model", "amf_reslstm",
                "--variant", "full", "--epochs", "80", "--batch-size", "256",
                "--num-workers", "2", "--learning-rate", "0.0005",
                "--weight-decay", "0.0001", "--patience", "20",
                "--coverage-weight", "0", "--selection-score", "ade60",
            ]
            if smoke:
                command.append("--quick-smoke")
            yield f"ours/amf_predecessor/{domain}/seed_{seed}", marker, command

            final_root = comparison / "ours" / "sa_moe"
            marker = final_root / domain / f"seed_{seed}" / "test_metrics.json"
            command = common_sa_command(final_root, domain, seed, "full")
            if smoke:
                command.append("--quick-smoke")
            yield f"ours/sa_moe/{domain}/seed_{seed}", marker, command


def ablation_tasks(variants, stage_number: int, smoke: bool):
    domains = DOMAINS[:1] if smoke else DOMAINS
    seeds = SEEDS[:1] if smoke else SEEDS
    variants = variants[:2] if smoke else variants
    for variant in variants:
        output = STUDY / "ablations" / variant
        for domain in domains:
            for seed in seeds:
                marker = output / domain / f"seed_{seed}" / "test_metrics.json"
                command = common_sa_command(output, domain, seed, variant)
                if smoke:
                    command.append("--quick-smoke")
                yield f"ablation/{variant}/{domain}/seed_{seed}", marker, command


def run_task(stage_root: Path, index: int, total: int, label: str, marker: Path, command: list[str]) -> bool:
    if marker.exists():
        emit(stage_root, "run_skipped", index=index, total=total, label=label)
        return True
    marker.parent.mkdir(parents=True, exist_ok=True)
    if (marker.parent / "last.pt").exists() and "--resume" not in command:
        command.append("--resume")
    log = marker.parent / "terminal.log"
    for attempt in (1, 2):
        emit(stage_root, "run_started", index=index, total=total, label=label, attempt=attempt)
        with log.open("a", encoding="utf-8") as stream:
            process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        if process.returncode == 0 and marker.exists():
            emit(stage_root, "run_completed", index=index, total=total, label=label)
            return True
        if (marker.parent / "last.pt").exists() and "--resume" not in command:
            command.append("--resume")
    emit(stage_root, "run_failed", index=index, total=total, label=label)
    return False


def main() -> int:
    global STUDY
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", type=int, choices=(1, 2, 3), required=True)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.smoke:
        STUDY = ROOT / "complete_3seed_4domain_study_smoke"
    if not args.smoke and args.stage > 1:
        prerequisite = STUDY / f"stage{args.stage - 1}" / "STAGE_COMPLETE.json"
        if not prerequisite.exists():
            raise RuntimeError(
                f"Stage {args.stage - 1} must complete before stage {args.stage}: {prerequisite}"
            )
    stage_root = STUDY / f"stage{args.stage}"
    if args.stage == 1:
        tasks = list(stage1_tasks(args.smoke))
    elif args.stage == 2:
        tasks = list(ablation_tasks(CORE_ABLATIONS, 2, args.smoke))
    else:
        tasks = list(ablation_tasks(NEGATIVE_CONTROLS, 3, args.smoke))
    failures = []
    emit(stage_root, "stage_started", stage=args.stage, smoke=args.smoke, total=len(tasks))
    for index, (label, marker, command) in enumerate(tasks, start=1):
        if not run_task(stage_root, index, len(tasks), label, marker, command):
            failures.append(label)
    if args.stage == 3 and not args.smoke:
        emit(stage_root, "summary_started", failures=len(failures))
        log = stage_root / "summary.log"
        with log.open("a", encoding="utf-8") as stream:
            process = subprocess.run(
                [sys.executable, "-u", "summarize_complete_study.py", "--study", str(STUDY)],
                cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
            )
        if process.returncode != 0:
            failures.append("summary_and_statistics")
            emit(stage_root, "summary_failed", returncode=process.returncode)
        else:
            emit(stage_root, "summary_completed")
    result = {"stage": args.stage, "complete": not failures, "failures": failures}
    atomic_json(stage_root / ("STAGE_COMPLETE.json" if not failures else "STAGE_FAILED.json"), result)
    emit(stage_root, "stage_completed" if not failures else "stage_failed", **result)
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
