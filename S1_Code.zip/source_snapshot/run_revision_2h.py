"""Two-region independent seed expansion and fully retrained SA ablations."""
from __future__ import annotations
import argparse
import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
import torch
from run_complete_study_stage import common_sa_command
from run_plos_rigor_suite import atomic_json, write_csv

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "revision_2h_20261009"
DOMAINS = ("norway", "piraeus")
NEW_SEEDS = (72, 82)
ALL_SEEDS = (42, 52, 62, 72, 82)
BASELINES = ("direct_lstm", "direct_gru", "tcn_cv", "transformer_cv")
FAITHFUL = ("itransformer_fa_faithful", "mstformer_faithful")
ABLATIONS = ("full", "no_dca", "uniform_router", "no_residual")


def log(event, **kw):
    row = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "event": event, **kw}
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "events.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    atomic_json(OUT / "STATUS.json", row)
    print(json.dumps(row, ensure_ascii=False, default=str), flush=True)


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for part in iter(lambda: f.read(2**20), b""):
            h.update(part)
    return h.hexdigest()


def protocol():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "PROTOCOL.json"
    if not path.exists():
        atomic_json(path, {"created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "deadline_unix": time.time() + 7200,
                    "domains": DOMAINS, "new_independent_backbone_seeds": NEW_SEEDS, "all_seeds": ALL_SEEDS,
                    "SA_training": "120-epoch random-init pretraining, then own-seed 60-epoch repair; no cross-seed warm start",
                    "SA_pretraining": {"lr": .0001, "patience": 24, "router_temperature": 1.0},
                    "SA_repair": {"lr": .00002, "patience": 12, "max_training_seconds": 240, "router_temperature": 1.5},
                    "SA_ablation_seeds": [42, 52, 62], "SA_ablations": ABLATIONS,
                    "SA_ablations_active_from_random_initialization": True,
                    "no_residual_definition": "disable gated dense residual and gated spline; retain separate intent endpoint correction",
                    "fusion": "five-expert pool, original compact subset/ridge procedure; shared short-specialist choice across five validation replications",
                    "fusion_old_three_seeds_refitted": True, "fusion_results_separate_from_original_submission": True,
                    "shared_fusion_selection_dependence": "five trained expert replications; routes are not independently selected",
                    "checkpoint_selection": "original model-specific validation rules; no test-based selection",
                    "historical_test_previously_observed": True, "std_ddof": 1, "CPU_threads": 4,
                    "budget_minutes": {"seed_training": 65, "matched_SA_training": 40, "summary_and_reserve": 15},
                    "full_four_domain_five_seed_complete": False})
    return json.loads(path.read_text(encoding="utf-8"))


def set_arg(args, name, value):
    if name in args:
        args[args.index(name) + 1] = str(value)
    else:
        args += [name, str(value)]
    return args


def sa_args(domain, seed, variant, output, stage, predecessor=None):
    ablation = "full" if variant == "full" else variant
    command = common_sa_command(output, domain, seed, ablation)[3:]
    set_arg(command, "--cache-dir", OUT / "cache")
    if stage == "repair":
        set_arg(command, "--epochs", 60)
        set_arg(command, "--learning-rate", .00002)
        set_arg(command, "--patience", 12)
        set_arg(command, "--max-training-seconds", 240)
        set_arg(command, "--router-temperature-override", 1.5)
        set_arg(command, "--component-ablation", "router_sharp150" if variant == "full" else variant)
        set_arg(command, "--init-checkpoint", predecessor)
    else:
        # Matching the original pretraining temperature, independent of later repair.
        set_arg(command, "--router-temperature-override", 1.0)
    return command


def task(label, script, args, marker):
    return {"label": label, "script": script, "args": args, "marker": marker}


def seed_tasks():
    comparison = OUT / "comparisons"
    for domain in DOMAINS:
        for seed in NEW_SEEDS:
            for name in BASELINES:
                marker = comparison / "runs" / name / domain / f"seed_{seed}" / "result.json"
                yield task(f"seed/{name}/{domain}/{seed}", "train_comparison_model",
                           ["--model", name, "--domain", domain, "--seed", str(seed), "--output-root", str(comparison), "--num-workers", "2"], marker)
            for name in FAITHFUL:
                marker = comparison / "faithful_sota" / name / domain / f"seed_{seed}" / "result.json"
                yield task(f"seed/{name}/{domain}/{seed}", "train_faithful_sota",
                           ["--model", name, "--domain", domain, "--seed", str(seed), "--output-root", str(comparison), "--num-workers", "2"], marker)
            base = OUT / "SA_seed_pretraining"
            base_run = base / domain / f"seed_{seed}"
            yield task(f"seed/SA_pretraining/{domain}/{seed}", "train", sa_args(domain, seed, "full", base, "pretrain"), base_run / "test_metrics.json")
            repair = OUT / "SA_seed_repair"
            yield task(f"seed/SA_repair/{domain}/{seed}", "train", sa_args(domain, seed, "full", repair, "repair", base_run / "best.pt"), repair / domain / f"seed_{seed}" / "test_metrics.json")


def ablation_tasks():
    # Each component is absent in BOTH training stages. No fully trained full-model warm start.
    for domain in DOMAINS:
        for seed in (42, 52, 62):
            for variant in ABLATIONS:
                pretrain = OUT / "SA_matched" / variant / "pretraining"
                run = pretrain / domain / f"seed_{seed}"
                yield task(f"ablation/{variant}/pretraining/{domain}/{seed}", "train", sa_args(domain, seed, variant, pretrain, "pretrain"), run / "test_metrics.json")
                repair = OUT / "SA_matched" / variant / "repair"
                yield task(f"ablation/{variant}/repair/{domain}/{seed}", "train", sa_args(domain, seed, variant, repair, "repair", run / "best.pt"), repair / domain / f"seed_{seed}" / "test_metrics.json")


def execute(item, deadline):
    marker = item["marker"]
    if marker.exists():
        log("task_resume_skip", label=item["label"])
        return True
    if deadline - time.time() < 30:
        log("task_not_started_budget", label=item["label"])
        return False
    args = list(item["args"])
    if (marker.parent / "last.pt").exists():
        args.append("--resume")
    command = [sys.executable, "-u", str(ROOT / "revision_training_job.py"), "--script", item["script"], *args]
    marker.parent.mkdir(parents=True, exist_ok=True)
    log("task_started", label=item["label"], command=command)
    started = time.time()
    with (marker.parent / "terminal.log").open("a", encoding="utf-8") as f:
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT,
                                    timeout=max(1, deadline - time.time()))
            success = result.returncode == 0 and marker.exists()
        except subprocess.TimeoutExpired:
            log("task_timed_out", label=item["label"], saved_progress=str(marker.parent))
            return False
    log("task_completed" if success else "task_failed", label=item["label"], returncode=result.returncode,
        seconds=round(time.time() - started, 2))
    return success


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.smoke:
        item = next(seed_tasks())
        item["args"] = [*item["args"], "--quick-smoke"]
        set_arg(item["args"], "--output-root", OUT / "smoke")
        item["marker"] = OUT / "smoke" / "runs" / "direct_lstm" / "norway" / "seed_72" / "result.json"
        execute(item, time.time() + 180)
        return
    spec = protocol()
    if os.name == "nt":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    failures = []
    try:
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is required for this campaign budget")
        for domain in DOMAINS:
            destination = OUT / "cache" / domain
            if not destination.exists():
                shutil.copytree(ROOT / "cache" / domain, destination)
        log("campaign_started", deadline=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(spec["deadline_unix"])))
        started = time.time()
        seed_complete = True
        for item in seed_tasks():
            if not execute(item, min(spec["deadline_unix"] - 900, started + 65 * 60)):
                failures.append(item["label"]); seed_complete = False
                break
        atomic_json(OUT / "SEED_PHASE.json", {"complete": seed_complete, "seconds": time.time() - started})
        if seed_complete:
            from revision_2h_results import summarize_seeds
            summarize_seeds(spec["deadline_unix"] - 300)
            log("five_seed_summary_complete")
            ablation_started = time.time()
            ablation_complete = True
            for item in ablation_tasks():
                if not execute(item, min(spec["deadline_unix"] - 300, ablation_started + 40 * 60)):
                    failures.append(item["label"]); ablation_complete = False
                    break
            atomic_json(OUT / "ABLATION_PHASE.json", {"complete": ablation_complete, "seconds": time.time() - ablation_started})
            from revision_2h_results import summarize_ablations
            summarize_ablations()
        from revision_2h_results import report
        report()
    except Exception as exc:
        failures.append(str(exc))
        traceback.print_exc()
        log("campaign_error", detail=str(exc))
    finally:
        atomic_json(OUT / "CAMPAIGN_RESULT.json", {"finished_at": time.strftime("%Y-%m-%d %H:%M:%S"), "failures": failures,
                    "complete": not failures, "full_four_domain_five_seed_complete": False})
        log("campaign_finished", failures=failures, full_four_domain_five_seed_complete=False)
        if os.name == "nt":
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)


if __name__ == "__main__":
    main()
