"""Verify independent raw AIS and build causal, MMSI-disjoint forecasting windows."""
from __future__ import annotations
import argparse
import datetime as dt
import gzip
import hashlib
import heapq
import os
from pathlib import Path
import numpy as np
import pandas as pd
import external_ais_common as c
from amf.data import RobustTrajectoryScaler

COLUMNS=('timestamp','timestampExternal','mmsi','lon','lat','sog','cog','navStat','rot','posAcc','raim','heading')
R=6371000.

def split_of(mmsi):
    bucket=int(hashlib.md5(str(int(mmsi)).encode()).hexdigest(),16)%10
    return 'val' if bucket==0 else 'test' if bucket==1 else 'train'

def project(lon,lat,lon0,lat0):
    return np.stack((R*np.cos(np.deg2rad(lat0))*np.deg2rad(lon-lon0),R*np.deg2rad(lat-lat0)),axis=-1)

def make_window(segment,k):
    # [time seconds, MMSI, lon degrees, lat degrees, SOG knots, COG degrees]
    anchor=segment[k,0];ht=anchor+np.arange(-89,1)*20.;ft=anchor+np.arange(1,181)*20.
    if ht[0]<segment[0,0] or ft[-1]>segment[-1,0]:return None
    past=segment[:k+1];lon0,lat0=segment[k,2:4]
    hlon=np.interp(ht,past[:,0],past[:,2]);hlat=np.interp(ht,past[:,0],past[:,3])
    xy=project(hlon,hlat,lon0,lat0)
    hsog=np.interp(ht,past[:,0],past[:,4])
    if np.median(hsog)<1 or np.linalg.norm(xy[-1]-xy[0])<200:return None
    # No raw report later than anchor is ever used to form any history feature.
    angle=np.interp(ht,past[:,0],np.unwrap(np.deg2rad(past[:,5])))
    h=np.column_stack((xy,np.sin(2*np.pi*(ht%86400)/86400),hsog,np.sin(angle),np.cos(angle))).astype(np.float32)
    y=project(np.interp(ft,segment[:,0],segment[:,2]),np.interp(ft,segment[:,0],segment[:,3]),lon0,lat0).astype(np.float32)
    def weak_fraction(grid,times):
        ii=np.searchsorted(times,grid);left=times[np.maximum(ii-1,0)];right=times[np.minimum(ii,len(times)-1)]
        return float((np.minimum(np.abs(grid-left),np.abs(grid-right))>10.).mean())
    hi,fi=weak_fraction(ht,past[:,0]),weak_fraction(ft,segment[:,0])
    if hi>.2 or fi>.2:return None
    return h,y,{'anchor_epoch_seconds':float(anchor),'anchor_raw_observation':True,
        'history_last_raw_epoch':float(past[-1,0]),'weak_support_fraction_history':hi,'weak_support_fraction_future':fi,
        'history_median_SOG_knots':float(np.median(hsog)),'history_displacement_m':float(np.linalg.norm(xy[-1]-xy[0]))}

def plan():
    lock=c.OUT/'SOURCE_PLAN.json'
    if lock.exists():return c.read(lock)
    upstream=c.read(Path('E:/OE_external_cv_transfer_20261016/external_feasibility/Finnish_Digitraffic_2021_2022_zenodo.json'))
    if upstream['metadata']['license']['id']!='cc-by-4.0':raise RuntimeError('Source licence not verified as CC BY 4.0')
    entries=c.zip_directory();dynamic=sorted([r for r in entries if r['name'].endswith('-location.csv')],key=lambda r:r['name'])
    selected=dynamic[:7]
    days=[dt.date.fromisoformat(Path(r['name']).name[:10]) for r in selected]
    if len(selected)!=7 or any((b-a).days!=1 for a,b in zip(days,days[1:])):raise RuntimeError('Earliest seven dynamic days are not consecutive')
    if sum(r['compressed_bytes'] for r in selected)>1024**3:raise RuntimeError('Selected week exceeds 1 GiB compressed acquisition cap')
    p={'created_at':__import__('time').strftime('%Y-%m-%d %H:%M:%S'),'source_DOI':c.SOURCE_DOI,
        'source_license':'CC BY 4.0','archive_MD5_published':'5e0414e51483469a6699b84ec8cd339a',
        'full_archive_downloaded_or_MD5_verified':False,'individual_member_CRC_and_download_SHA256_required':True,
        'subset_rule':'earliest seven consecutive available daily position members, fixed before model evaluation',
        'members':selected,'dates':[d.isoformat() for d in days],'format':'headerless 12-column CSV',
        'units':'already decoded lon/lat degrees, SOG knots, COG degrees, external timestamp milliseconds',
        'evidence':'actual first dynamic DEFLATE prefix plus publisher schema; no second division by AIS encoding scale',
        'MMSI_exclusion':'union of all EnvShip four-region train/validation/test MMSIs',
        'split':'MD5(MMSI) mod 10: 0 validation, 1 test, other train',
        'sampling_seconds':20,'history_steps':90,'future_steps':180,'window_anchor_stride_seconds':1800,
        'maximum_raw_gap_seconds':120,'maximum_position_speed_mps':40,'SOG_range_knots':[0,60],
        'COG_range_degrees':'0 <= COG < 360; 360 sentinel excluded',
        'latitude_range_degrees':[58,71.5],'longitude_range_degrees':[18,33.5],
        'history_median_SOG_min_knots':1,'history_displacement_min_m':200,
        'weak_support':'grid point over 10s from nearest raw point; max 20% in history and future separately',
        'causality':'anchor is an actual raw observation; all history interpolation uses raw times <= anchor',
        'max_windows_per_MMSI':24,'cap_rule':'lowest SHA256(MMSI/member/anchor_ms) values, not difficulty or error',
        'cross_midnight_windows':False,'projection':'anchor-local spherical equirectangular east/north, R=6371000 m',
        'minimum_counts':{'train_windows':100,'val_windows':30,'test_windows':30,'train_MMSI':30,'val_MMSI':12,'test_MMSI':12},
        'not_full_Finnish_dataset':'This is a one-week, moving-vessel, QC-screened independent subset.',
        'no_future_motion_class_or_model_error_filtering':True}
    c.atomic_json(lock,p);c.atomic_json(c.OUT/'SOURCE_LICENSE_METADATA.json',upstream)
    return p

def clean_day(path,overlap):
    with gzip.open(path,'rt',encoding='utf-8') as f:first=f.readline().strip().split(',')
    if len(first)!=12 or not first[0].lstrip('-').isdigit():raise RuntimeError('Expected headerless, decoded 12-field AIS rows')
    blocks=[];total=valid_count=overlap_rows=0;seen=set();excluded=set()
    names=['timestampExternal','mmsi','lon','lat','sog','cog']
    for frame in pd.read_csv(path,header=None,names=COLUMNS,usecols=names,chunksize=200000):
        a=frame[names].apply(pd.to_numeric,errors='coerce').to_numpy(dtype=np.float64)
        total+=len(a);finite=np.isfinite(a).all(1);a=a[finite]
        # Actual source rows are already decoded. Verify rather than guess units.
        if len(a) and not 1.5e12<float(np.median(a[:,0]))<1.8e12:raise RuntimeError('Unexpected external timestamp scale')
        valid=(a[:,1]>=100000000)&(a[:,1]<=999999999)&(a[:,2]>=18)&(a[:,2]<=33.5)&(a[:,3]>=58)&(a[:,3]<=71.5)&(a[:,4]>=0)&(a[:,4]<=60)&(a[:,5]>=0)&(a[:,5]<360)
        a=a[valid];seen.update(a[:,1].astype(np.int64).tolist());valid_count+=len(a)
        duplicated=np.isin(a[:,1].astype(np.int64),overlap);overlap_rows+=int(duplicated.sum());excluded.update(a[duplicated,1].astype(np.int64).tolist())
        a=a[~duplicated];a[:,0]/=1000.;blocks.append(a)
    result=np.concatenate(blocks) if blocks else np.empty((0,6));order=np.lexsort((result[:,0],result[:,1]));result=result[order]
    return result,{'total_raw_rows':total,'valid_decoded_rows':valid_count,'EnvShip_overlap_rows_excluded':overlap_rows,
        'valid_unique_MMSI':len(seen),'overlap_unique_MMSI':len(excluded),'overlap_MMSI':sorted(excluded),'retained_rows':len(result)}

def prepare():
    c.OUT.mkdir(parents=True,exist_ok=True);p=plan();all_ids=[]
    for d in c.DOMAINS:
        for split in ('train','val','test'):
            all_ids.extend(np.unique(np.load(c.ROOT/'cache'/d/f'{d}_{split}'/'mmsi.npy',mmap_mode='r')).tolist())
    overlap=np.unique(all_ids).astype(np.int64);c.archive(c.OUT/'EnvShip_excluded_MMSI.npz',mmsi=overlap)
    heaps={};audit=[];counter=0
    for member in p['members']:
        c.free_space();raw=c.download_member(member);a,record=clean_day(raw,overlap);generated=0
        for m in np.unique(a[:,1]).astype(np.int64):
            g=a[a[:,1]==m];_,ix=np.unique(g[:,0],return_index=True);g=g[ix]
            if len(g)<2:continue
            delta=np.diff(g[:,0]);xy=project(g[:,2],g[:,3],g[0,2],g[0,3]);speed=np.linalg.norm(np.diff(xy,axis=0),axis=1)/delta
            boundaries=np.flatnonzero((delta>120)|(speed>40))+1
            for segment in np.split(g,boundaries):
                if len(segment)<2 or segment[-1,0]-segment[0,0]<5380:continue
                desired=np.arange(segment[0,0]+1780,segment[-1,0]-3600+.001,1800)
                for anchor in desired:
                    k=int(np.searchsorted(segment[:,0],anchor));item=make_window(segment,k)
                    if item is None:continue
                    x,y,info=item;info.update(mmsi=int(m),member=member['name'],split=split_of(m))
                    key=f"{m}/{member['name']}/{round(info['anchor_epoch_seconds']*1000)}"
                    rank=int(hashlib.sha256(key.encode()).hexdigest(),16);counter+=1
                    entry=(-rank,counter,x,y,info);heap=heaps.setdefault(int(m),[])
                    if len(heap)<24:heapq.heappush(heap,entry)
                    elif rank < -heap[0][0]:heapq.heapreplace(heap,entry)
                    generated+=1
        record.update(member=member['name'],raw_gzip_sha256=c.sha(raw),QC_windows_before_per_vessel_cap=generated)
        audit.append(record);c.atomic_json(c.OUT/'RAW_DAY_AUDIT.json',audit)
        c.emit('independent_raw_day_verified',member=member['name'],rows=record['total_raw_rows'],retained_MMSI=len(heaps),candidate_windows=generated)
    rows=sorted([entry for heap in heaps.values() for entry in heap],key=lambda e:(e[4]['mmsi'],e[4]['anchor_epoch_seconds']))
    counts={};catalogue=[];sets={}
    for split in ('train','val','test'):
        selected=[r for r in rows if r[4]['split']==split];sets[split]={r[4]['mmsi'] for r in selected}
        counts[split]={'windows':len(selected),'MMSI':len(sets[split])}
        required=p['minimum_counts']
        if len(selected)<required[split+'_windows'] or len(sets[split])<required[split+'_MMSI']:
            c.atomic_json(c.OUT/'INSUFFICIENT_DATA.json',{'counts':counts,'required':required,'no_QC_relaxation_or_test_selected_extension':True})
            raise RuntimeError('Independent subset below predeclared minimum; do not relax filters after looking at errors')
        folder=c.OUT/'cache'/split;folder.mkdir(parents=True,exist_ok=True)
        for name,arr in (('history',np.stack([r[2] for r in selected])),('future',np.stack([r[3] for r in selected])),('mmsi',np.array([r[4]['mmsi'] for r in selected],np.int64))):
            np.save(folder/(name+'.npy'),arr)
        for i,r in enumerate(selected):catalogue.append({'window_index':i,**r[4]})
    if any(sets[a]&sets[b] for a,b in (('train','val'),('train','test'),('val','test'))):raise RuntimeError('MMSI split overlap')
    if set(heaps)&set(overlap.tolist()):raise RuntimeError('EnvShip MMSI exclusion failure')
    scaler=RobustTrajectoryScaler.fit(np.load(c.OUT/'cache/train/history.npy',mmap_mode='r'),np.load(c.OUT/'cache/train/future.npy',mmap_mode='r'))
    scaler.save(c.OUT/'cache/scaler.json');c.atomic_json(c.OUT/'WINDOW_CATALOGUE.json',catalogue)
    datafiles=[*sorted((c.OUT/'cache').rglob('*.npy')),c.OUT/'cache/scaler.json',c.OUT/'WINDOW_CATALOGUE.json']
    c.atomic_json(c.OUT/'DATA_READY.json',{'complete':True,'counts':counts,'all_split_MMSI_disjoint':True,'all_EnvShip_MMSI_excluded':True,
        'source_date_overlap_with_EnvShip':False,'source_is_not_EnvShip':True,'source_license':'CC BY 4.0','scaler_fitted_on':'external train only',
        'files':{str(f):c.sha(f) for f in datafiles},'raw_records_total':sum(r['total_raw_rows'] for r in audit),'source_plan_sha256':c.sha(c.OUT/'SOURCE_PLAN.json')})
    c.emit('independent_data_ready',counts=counts)

def main():
    a=argparse.ArgumentParser();a.add_argument('--plan-only',action='store_true');args=a.parse_args()
    if args.plan_only:print(plan(),flush=True)
    else:prepare()

if __name__=='__main__':main()
