"""Wait for the probability campaign, then execute a frozen 16-hour extension."""
from __future__ import annotations
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from revision_followup16_common import *


def command(item, stage, smoke=False):
    from run_complete_study_stage import common_sa_command
    from run_revision_2h import set_arg
    run = new_run(item, stage)
    output = run.parents[1]
    args = common_sa_command(output, item['domain'], item['seed'], item['variant'])[3:]
    set_arg(args, '--num-workers', 0)
    set_arg(args, '--router-temperature-override', 1.0 if stage == 'pretraining' else 1.5)
    if stage == 'repair':
        for k, v in (('--epochs', 60), ('--learning-rate', .00002), ('--patience', 12),
                     ('--max-training-seconds', 240 if item['domain'] in SMALL else 600),
                     ('--component-ablation', 'router_sharp150' if item['variant'] == 'full' else item['variant']),
                     ('--init-checkpoint', selected_run(item, 'pretraining') / 'best.pt')):
            set_arg(args, k, v)
    if smoke:
        set_arg(args, '--output-dir', OUT / 'smoke' / item['variant'] / stage)
        args.append('--quick-smoke')
    elif (run / 'last.pt').exists():
        args.append('--resume')
    return [sys.executable, '-u', str(ROOT / 'revision_followup16_training.py'), *args]


def prepare(refreeze=False):
    import numpy as np
    if refreeze and (OUT / 'ACTIVATION.json').exists():
        raise RuntimeError('Cannot revise a protocol after experimental activation')
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / 'CPU_TESTS.log').open('w', encoding='utf-8') as stream:
        test = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests',
                               '-p', 'test_revision_followup16.py', '-v'], cwd=ROOT,
                              stdout=stream, stderr=subprocess.STDOUT,
                              env={**os.environ, 'CUDA_VISIBLE_DEVICES': '-1', 'PYTHONUTF8': '1'})
    if test.returncode:
        raise RuntimeError(f'CPU tests failed (exit={test.returncode}); see CPU_TESTS.log. Do not queue training.')
    if not RUN_STORAGE.anchor or not Path(RUN_STORAGE.anchor).exists():
        raise RuntimeError('The dedicated E: experiment drive is unavailable')
    if shutil.disk_usage(Path(RUN_STORAGE.anchor)).free < 6 * 1024**3:
        raise RuntimeError('Need at least 6 GiB on E: for raw experiment artifacts')
    main, extra, optional = plan()
    previous_hashes = read(PREVIOUS / 'code_manifest.json')
    for name in ('train.py', 'amf\\adaptive_moe.py', 'evaluate_compact_committee.py'):
        if sha(ROOT / name) != previous_hashes[name]:
            raise RuntimeError(f'Reused ablation code drift: {name}')
    audit, reuse = [], []
    for domain in DOMAINS:
        groups = []
        for split in ('train', 'val', 'test'):
            folder = ROOT / 'cache' / domain / f'{domain}_{split}'
            x, y, ids = [np.load(folder / f'{n}.npy', mmap_mode='r') for n in ('history', 'future', 'mmsi')]
            if x.shape[1:] != (90, 6) or y.shape[1:] != (180, 2) or not len(x) == len(y) == len(ids):
                raise RuntimeError(f'Data shape mismatch {folder}')
            groups.append(set(map(int, np.unique(ids))))
            audit.append({'domain': domain, 'split': split, 'windows': len(ids),
                'mmsi_sha256': sha(folder / 'mmsi.npy'), 'groups': len(groups[-1]),
                'files': {n: {'bytes': (folder / f'{n}.npy').stat().st_size,
                              'mtime_ns': (folder / f'{n}.npy').stat().st_mtime_ns}
                          for n in ('history', 'future', 'mmsi')}})
            if domain in SMALL:
                older = PREVIOUS / 'cache' / domain / f'{domain}_{split}'
                for name in ('history', 'future', 'mmsi'):
                    if sha(folder / f'{name}.npy') != sha(older / f'{name}.npy'):
                        raise RuntimeError('Reused small-domain cache is not byte-identical')
        if any(groups[i] & groups[j] for i, j in ((0, 1), (0, 2), (1, 2))):
            raise RuntimeError('MMSI split overlap')
    for item in main + extra:
        r = existing_run(item, 'repair')
        if finished(r):
            for stage in ('pretraining', 'repair'):
                src = existing_run(item, stage)
                cfg = validate_config(item, src, stage)
                # Existing scalers are embedded in configs; compare numeric definitions.
                if cfg['scaler'] != read(ROOT / 'cache' / item['domain'] / 'scaler.json'):
                    raise RuntimeError('Reused scaler mismatch')
                reuse.append({'item': item, 'stage': stage, 'run': str(src),
                              'checkpoint_sha256': sha(src / 'best.pt'),
                              'config_sha256': sha(src / 'config.json')})
    protocol = {'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'dependency': str(DEPENDENCY), 'budget_seconds_from_activation': BUDGET_SECONDS,
        'training_artifacts_root': str(RUN_STORAGE), 'tables_and_report_root': str(OUT),
        'summary_reserve_seconds': RESERVE_SECONDS, 'primary': main, 'secondary': extra,
        'optional_complete_cohort': optional, 'primary_expected_completed_models': 36,
        'primary_new_large_models': 18, 'primary_reused_small_models': 18,
        'random_init_pretrain_epochs': 120, 'repair_epochs': 60,
        'repair_training_cap_large_seconds': 600, 'repair_training_cap_small_seconds': 240,
        'checkpoint_selection': 'validation ADE@60 only', 'std_ddof': 1,
        'no_test_based_variant_pruning': True, 'no_test_based_early_stop': True,
        'all_negative_results_retained': True, 'cache_audit': audit, 'reuse': reuse,
        'source_hashes': sources(), 'scaler_hashes': {d: sha(ROOT / 'cache' / d / 'scaler.json') for d in DOMAINS},
        'limitations': ['not seven internal ablations on four domains and five seeds',
            'no independent external AIS dataset', 'no capacity-matched wide-GRU in this budget',
            'ablation switches disable predictive branches, not physically prune all parameters',
            'no_residual retains the separate intent endpoint correction',
            'historical test observations remain a limitation',
            'shared validation routing makes cross-seed intervals conditional/descriptive']}
    if (OUT / 'PROTOCOL.json').exists():
        old = read(OUT / 'PROTOCOL.json')
        if refreeze:
            atomic(OUT / f"PROTOCOL_before_activation_{time.strftime('%H%M%S')}.json", old)
            atomic(OUT / 'PROTOCOL.json', protocol)
        else:
            for key in ('source_hashes', 'cache_audit', 'reuse', 'primary', 'secondary', 'scaler_hashes'):
                if old[key] != protocol[key]:
                    raise RuntimeError(f'Frozen protocol drift: {key}')
    else:
        atomic(OUT / 'PROTOCOL.json', protocol)
    atomic(OUT / 'READY_CPU.json', {'CPU_checks_passed': True, 'CUDA_smoke': 'deferred_until_dependency_releases_GPU',
                                   'source_hashes': sources()})
    emit('prepared_waiting_for_probability', primary_new_large_models=18, reused_small_models=18)


def dedicated_compute_pids(output):
    # Under WDDM, query-compute-apps also lists Explorer/Terminal/browser C+G
    # contexts. Waiting for *all* of them would never finish. Gate on dedicated
    # compute (C), plus mixed compute/graphics Python/R runtimes, not desktop UI.
    if 'Processes:' not in output or 'Type' not in output:
        raise RuntimeError('Unrecognised nvidia-smi process table; cannot safely inspect GPU')
    users = []
    for line in output.splitlines():
        match = re.match(r'^\|\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(C\+G|C|G)\s+', line)
        if not match:
            continue
        if match[2] == 'C' or (match[2] == 'C+G' and re.search(r'(pythonw?\.exe|Rscript\.exe)', line, re.I)):
            users.append(match[1])
    return users


def stop_owned(process):
    # Only stop the direct process created here, never existing training processes.
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=20)


def execute(cmd, log_path, deadline, label):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    if time.time() >= deadline:
        return False
    with log_path.open('a', encoding='utf-8') as stream:
        process = subprocess.Popen(cmd, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                   env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8'})
        atomic(OUT / 'CHILD.json', {'pid': process.pid, 'label': label, 'command': cmd})
        emit('task_started', label=label, pid=process.pid, log=str(log_path))
        try:
            code = process.wait(timeout=max(.1, deadline - time.time()))
        except subprocess.TimeoutExpired:
            stop_owned(process)
            emit('task_budget_timeout', label=label)
            return False
        finally:
            if process.poll() is None:
                stop_owned(process)
    atomic(OUT / 'CHILD.json', {'pid': None, 'last_label': label, 'exit_code': code})
    emit('task_exit', label=label, exit_code=code)
    return code == 0


def check_frozen():
    p = read(OUT / 'PROTOCOL.json')
    if p['source_hashes'] != sources():
        raise RuntimeError('Source changed after the 16-hour plan was frozen')
    for d, digest in p['scaler_hashes'].items():
        if sha(ROOT / 'cache' / d / 'scaler.json') != digest:
            raise RuntimeError('Scaler changed after preflight')
    for row in p['cache_audit']:
        folder = ROOT / 'cache' / row['domain'] / f"{row['domain']}_{row['split']}"
        for n, stat in row['files'].items():
            info = (folder / f'{n}.npy').stat()
            if info.st_size != stat['bytes'] or info.st_mtime_ns != stat['mtime_ns']:
                raise RuntimeError('Data cache modified after plan freeze')
    for row in p['reuse']:
        r = Path(row['run'])
        if sha(r / 'best.pt') != row['checkpoint_sha256'] or sha(r / 'config.json') != row['config_sha256']:
            raise RuntimeError('Reused result changed after preflight')


def smoke(deadline):
    # These are real CUDA train/eval checks, delayed until the preceding run ends.
    import torch
    RUN_STORAGE.mkdir(parents=True, exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; do not silently train on CPU')
    for v in PRIMARY:
        item = unit(v, 'piraeus', 42, 'smoke')
        cmd = command(item, 'pretraining', smoke=True)
        if not execute(cmd, OUT / 'smoke' / v / 'terminal.log', min(deadline, time.time() + 300), f'smoke/{v}'):
            raise RuntimeError(f'CUDA smoke failed for {v}')
        result = read(OUT / 'smoke' / v / 'pretraining' / 'piraeus' / 'seed_42' / 'test_metrics.json')
        if not all(__import__('math').isfinite(x) for x in result['raw'].values()):
            raise RuntimeError('Nonfinite smoke metrics')
        repair_cmd = command(item, 'repair', smoke=True)
        repair_cmd[repair_cmd.index('--init-checkpoint') + 1] = str(
            OUT / 'smoke' / v / 'pretraining' / 'piraeus' / 'seed_42' / 'best.pt')
        if not execute(repair_cmd, OUT / 'smoke' / v / 'repair.log',
                       min(deadline, time.time() + 300), f'smoke/{v}/own_pretrained_repair'):
            raise RuntimeError(f'CUDA repair smoke failed for {v}')
        repaired = read(OUT / 'smoke' / v / 'repair' / 'piraeus' / 'seed_42' / 'config.json')
        if repaired['initialization']['missing_tensors'] or repaired['initialization']['unexpected_tensors']:
            raise RuntimeError('Smoke repair loaded a partial initialization')
    atomic(OUT / 'READY_CUDA.json', {'complete': True, 'GPU': torch.cuda.get_device_name(),
        'variants': PRIMARY, 'own_pretraining_plus_repair_smoke_runs': 6})


def train_unit(item, deadline):
    if finished(selected_run(item, 'repair')):
        for stage in ('pretraining', 'repair'):
            validate_config(item, selected_run(item, stage), stage)
        emit('reuse_complete_unit', label=item['label'], run=str(selected_run(item, 'repair')))
        return True
    if not can_admit(item, deadline):
        emit('unit_deferred_budget', label=item['label'])
        return False
    if shutil.disk_usage(ROOT).free < 1.5 * 1024**3 or shutil.disk_usage(RUN_STORAGE).free < 1.25 * 1024**3:
        emit('unit_deferred_low_disk', label=item['label'])
        return False
    for stage in ('pretraining', 'repair'):
        run = selected_run(item, stage)
        if finished(run):
            validate_config(item, run, stage)
            continue
        ok = False
        for attempt in (1, 2):
            check_frozen()
            ok = execute(command(item, stage), run / 'terminal.log', deadline - RESERVE_SECONDS,
                         f"{item['label']}/{stage}/attempt_{attempt}")
            if ok and finished(run):
                validate_config(item, run, stage)
                break
            if time.time() >= deadline - RESERVE_SECONDS:
                return False
        if not ok or not finished(run):
            emit('unit_failed', label=item['label'], stage=stage)
            return False
    atomic(new_run(item, 'repair') / 'UNIT_COMPLETE.json', {'complete': True, 'item': item,
        'checkpoint_sha256': sha(new_run(item, 'repair') / 'best.pt')})
    return True


def active_campaign():
    check_frozen()
    activation_path = OUT / 'ACTIVATION.json'
    if activation_path.exists():
        activation = read(activation_path)
    else:
        activation = {'activated_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'start_unix': time.time(),
                      'deadline_unix': time.time() + BUDGET_SECONDS, 'budget_seconds': BUDGET_SECONDS}
        atomic(activation_path, activation)
    deadline = activation['deadline_unix']
    if time.time() >= deadline:
        emit('activation_budget_already_elapsed', deadline=deadline)
        return 1
    emit('campaign_activated', **activation)
    if not (OUT / 'READY_CUDA.json').exists():
        smoke(deadline)
    prob_ok = execute([sys.executable, '-u', str(ROOT / 'revision_followup16_results.py'),
                       '--phase', 'probability', '--deadline', str(min(deadline, time.time() + 1800))],
                      OUT / 'probability_summary.log', min(deadline, time.time() + 1800), 'probability_comparison')
    main, extra, optional = plan()
    failures, deferred = [], []
    for item in main + extra:
        if not train_unit(item, deadline):
            (deferred if not can_admit(item, deadline) or shutil.disk_usage(ROOT).free < 1.5 * 1024**3
             or shutil.disk_usage(RUN_STORAGE).free < 1.25 * 1024**3 else failures).append(item)
    # Admit the uniform-routing extension only if its entire large-domain cohort fits.
    required = sum(estimate_seconds(i) for i in optional if not finished(selected_run(i, 'repair')))
    if time.time() + required + RESERVE_SECONDS < deadline:
        for item in optional:
            if not train_unit(item, deadline):
                deferred.append(item)
    else:
        deferred += [i for i in optional if not finished(selected_run(i, 'repair'))]
    atomic(OUT / 'TRAINING_OUTCOME.json', {'failures': failures, 'deferred': deferred,
        'probability_comparison_complete': prob_ok, 'training_cutoff_unix': deadline - RESERVE_SECONDS})
    report_ok = execute([sys.executable, '-u', str(ROOT / 'revision_followup16_results.py'),
                         '--phase', 'ablations', '--deadline', str(deadline - 30)],
                        OUT / 'ablation_summary.log', deadline - 15, 'ablation_summary_and_validation_refits')
    primary_complete = all(finished(selected_run(i, 'repair')) for i in main)
    result = {'finished_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'primary_training_complete': primary_complete, 'probability_comparison_complete': prob_ok,
        'ablation_report_complete': report_ok, 'all_planned_training_complete': not failures and not deferred,
        'full_revision_experiment_list_complete': False, 'failures': failures, 'deferred': deferred,
        'complete': primary_complete and prob_ok and report_ok, 'activation': activation}
    atomic(OUT / 'RESULT.json', result)
    emit('campaign_finished', primary_training_complete=primary_complete, report_complete=report_ok,
         deferred=len(deferred), failures=len(failures))
    return 0 if result['complete'] else 1


def wait_and_run():
    guard = FileLock(OUT / 'guardian.lock')
    if not guard.acquire():
        raise RuntimeError('Another continuation guardian is already running')
    dependency_lock = FileLock(DEPENDENCY / 'campaign.lock')
    try:
        keep_awake(True)
        atomic(OUT / 'GUARDIAN.json', {'pid': os.getpid(), 'started_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                                     'dependency': str(DEPENDENCY)})
        emit('waiting_for_probability_complete', pid=os.getpid(), budget_not_started=True)
        last_state = None
        while not (OUT / 'RESULT.json').exists():
            if (DEPENDENCY / 'COMPLETE.json').exists():
                if dependency_lock.acquire():
                    validate_dependency()
                    # Query compute users only after the probability campaign releases its lock.
                    gpu = subprocess.run(['nvidia-smi'], capture_output=True, text=True,
                                         encoding='utf-8', errors='replace', timeout=20)
                    if gpu.returncode:
                        raise RuntimeError('Unable to verify GPU process inventory')
                    users = dedicated_compute_pids(gpu.stdout)
                    if users:
                        dependency_lock.release()
                        state = ('waiting_for_GPU_release', ','.join(users))
                    else:
                        return active_campaign()
                else:
                    state = ('waiting_for_probability_process_exit', '')
            elif (DEPENDENCY / 'FAILURES.json').exists():
                state = ('dependency_failed_waiting_for_recovery', str(DEPENDENCY / 'FAILURES.json'))
            else:
                state = ('waiting_for_probability_complete', '')
            if state != last_state:
                emit(state[0], details=state[1], budget_not_started=True)
                last_state = state
            time.sleep(30)
        emit('existing_result_no_duplicate_run', result=str(OUT / 'RESULT.json'))
        return 0
    except Exception as error:
        atomic(OUT / 'ERROR.json', {'error': str(error), 'traceback': traceback.format_exc()})
        emit('continuation_error', error=str(error))
        return 1
    finally:
        dependency_lock.release()
        keep_awake(False)
        guard.release()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-cpu', action='store_true')
    parser.add_argument('--refreeze-before-activation', action='store_true')
    args = parser.parse_args()
    if args.prepare_cpu:
        prepare(refreeze=args.refreeze_before_activation)
    else:
        sys.exit(wait_and_run())
