"""Synthetic CUDA workflow test: deliberately no test split exists."""
import json
from pathlib import Path
import numpy as np
import torch
import external_ais_common as c
import external_ais_train as train
from amf.data import RobustTrajectoryScaler
from amf.unified_predictor import UnifiedInternalMoE

def main():
    main_output=c.OUT;toy=main_output/'synthetic_smoke';toy.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(161026);arrays={}
    for split,n in (('train',64),('val',32)):
        velocity=rng.uniform(.5,3.,size=(n,1,2)).astype(np.float32)
        h=np.zeros((n,90,6),np.float32);h[:,:,:2]=np.arange(-89,1,dtype=np.float32)[None,:,None]*velocity
        h[:,:,2]=rng.uniform(-1,1,(n,1));h[:,:,3]=np.linalg.norm(velocity,axis=-1)*1.94384/20
        h[:,:,4]=velocity[:,:,0]/np.linalg.norm(velocity,axis=-1);h[:,:,5]=velocity[:,:,1]/np.linalg.norm(velocity,axis=-1)
        y=np.arange(1,181,dtype=np.float32)[None,:,None]*velocity;ids=np.arange(n,dtype=np.int64)+230000000+(1000 if split=='val' else 0)
        folder=toy/'cache'/split;folder.mkdir(parents=True,exist_ok=True)
        for name,value in (('history',h),('future',y),('mmsi',ids)):np.save(folder/(name+'.npy'),value)
        arrays[split]=(h,y)
    RobustTrajectoryScaler.fit(*arrays['train']).save(toy/'cache/scaler.json')
    c.OUT=toy;torch.set_num_threads(4)
    if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable for independent workflow smoke')
    train.train_sa(42,'pretrain',True);train.train_sa(42,'repair',True)
    for name in c.BACKBONES:
        if name!='sa_repair':train.train_comparator(name,42,True)
    model=UnifiedInternalMoE().cuda().eval()
    for name,module in zip(c.EXPERTS,model.expert_modules):
        stage='repair' if name=='sa_repair' else 'train'
        module.load_state_dict(torch.load(train.run_dir(name,42,stage,True)/'best.pt',map_location='cpu',weights_only=False)['model'])
    scaler=RobustTrajectoryScaler.load(toy/'cache/scaler.json');x=torch.from_numpy(scaler.transform_history(arrays['val'][0][:4])).cuda()
    with torch.no_grad():
        p,aux=model(x,return_aux=True);difference=float(torch.max(torch.abs(p-aux['internal_candidates'].mean(1))))
    if not torch.isfinite(p).all() or difference>1e-4:raise RuntimeError('Packed external-model forward parity failed')
    if (toy/'cache/test').exists():raise RuntimeError('Smoke must not require any test split')
    c.atomic_json(main_output/'CUDA_SMOKE_COMPLETE.json',{'complete':True,'synthetic_not_formal_data':True,
        'no_test_split_created_or_opened':True,'seven_backbones_plus_SA_repair_passed':True,'packed_fusion_max_abs_normalized_difference':difference,
        'GPU':torch.cuda.get_device_name(),'smoke_code_sha256':c.sha(Path(__file__))})
    print('Independent synthetic CUDA smoke passed',flush=True)

if __name__=='__main__':main()
