from __future__ import annotations

import argparse
import itertools
import json
import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from amf.adaptive_moe import IntentMultiScaleMoE
from amf.data import EnvShipDataset, RobustTrajectoryScaler, build_cache, resolve_split_file
from amf.metrics import displacement_metrics
from comparison_models import MODEL_SPECS, build_comparison_model
from faithful_sota_models import FAITHFUL_SPECS, build_faithful_model


ROOT = Path(__file__).resolve().parent
SOURCE_STUDY = ROOT / "complete_3seed_4domain_study"
DOMAINS = ("dma", "noaa", "norway", "piraeus")
SEEDS = (42, 52, 62)
CANDIDATES = (
    "sa_repair",
    "transformer_cv",
    "itransformer_fa_faithful",
    "mstformer_faithful",
    "direct_gru",
    "tcn_cv",
)
METRICS = (
    "ADE@5", "FDE@5", "ADE@10", "FDE@10", "ADE@20", "FDE@20",
    "ADE@30", "FDE@30", "ADE@45", "FDE@45", "ADE@60", "FDE@60",
)


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def run_path(output: Path, recipe_name: str, candidate: str, domain: str, seed: int) -> Path:
    if candidate == "sa_repair":
        if recipe_name == "__stage1__":
            return SOURCE_STUDY / "comparisons" / "ours" / "sa_moe" / domain / f"seed_{seed}"
        return output / "repairs" / recipe_name / domain / f"seed_{seed}"
    if candidate in FAITHFUL_SPECS:
        return (
            SOURCE_STUDY / "comparisons" / "faithful_sota" / candidate / domain / f"seed_{seed}"
        )
    return SOURCE_STUDY / "comparisons" / "runs" / candidate / domain / f"seed_{seed}"


def build_model(candidate: str, run: Path):
    if candidate == "sa_repair":
        config = json.loads((run / "config.json").read_text(encoding="utf-8"))
        return IntentMultiScaleMoE(
            v6_variant=config["v6_variant"],
            component_ablation=config.get("component_ablation", "full"),
            router_temperature_override=config.get("router_temperature_override"),
        )
    if candidate in FAITHFUL_SPECS:
        return build_faithful_model(candidate)
    return build_comparison_model(candidate)


def batch_size(candidate: str) -> int:
    if candidate in FAITHFUL_SPECS:
        return int(FAITHFUL_SPECS[candidate]["batch_size"])
    if candidate in MODEL_SPECS:
        return int(MODEL_SPECS[candidate]["batch_size"])
    return 256


@torch.no_grad()
def collect_validation(
    output: Path,
    recipe_name: str,
    candidate: str,
    domain: str,
    seed: int,
    dataset,
    scaler,
    device,
    num_workers: int,
) -> Path:
    cache_path = output / "committee" / "prediction_cache" / candidate / domain / f"seed_{seed}.npz"
    if cache_path.exists():
        return cache_path
    source_run = run_path(output, recipe_name, candidate, domain, seed)
    existing = source_run / "validation_predictions.npz"
    if existing.exists():
        data = np.load(existing)
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(
            cache_path,
            prediction=data["prediction"].astype(np.float32),
            target=data["target"].astype(np.float32),
            mmsi=data["mmsi"].astype(np.int64) if "mmsi" in data else np.arange(len(data["target"])),
        )
        return cache_path
    checkpoint = source_run / "best.pt"
    if not checkpoint.exists():
        raise FileNotFoundError(checkpoint)
    model = build_model(candidate, source_run).to(device)
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)["model"]
    model.load_state_dict(state)
    model.eval()
    loader = DataLoader(
        dataset,
        batch_size=batch_size(candidate),
        shuffle=False,
        num_workers=num_workers,
        pin_memory=device.type == "cuda",
        persistent_workers=num_workers > 0,
    )
    predictions, targets, identifiers = [], [], []
    for history, target, mmsi in loader:
        prediction = model(history.to(device, non_blocking=True))
        predictions.append(prediction.float().cpu().numpy())
        targets.append(target.numpy())
        identifiers.append(np.asarray(mmsi))
    prediction_m = scaler.inverse_positions(np.concatenate(predictions)).astype(np.float32)
    target_m = scaler.inverse_positions(np.concatenate(targets)).astype(np.float32)
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        prediction=prediction_m,
        target=target_m,
        mmsi=np.concatenate(identifiers).astype(np.int64),
    )
    del model
    if device.type == "cuda":
        torch.cuda.empty_cache()
    return cache_path


def project_simplex(values: np.ndarray) -> np.ndarray:
    if len(values) == 1:
        return np.ones(1, dtype=np.float64)
    ordered = np.sort(values)[::-1]
    cumulative = np.cumsum(ordered) - 1.0
    indices = np.arange(1, len(values) + 1)
    valid = ordered - cumulative / indices > 0
    rho = np.flatnonzero(valid)[-1]
    theta = cumulative[rho] / float(rho + 1)
    return np.maximum(values - theta, 0.0)


def fit_simplex(errors: np.ndarray, ridge: float) -> np.ndarray:
    # errors: candidates x samples x steps x xy
    count = float(np.prod(errors.shape[1:]))
    matrix = errors.reshape(errors.shape[0], -1).astype(np.float64)
    gram = (matrix @ matrix.T) / max(count, 1.0)
    anchor = np.zeros(errors.shape[0], dtype=np.float64)
    anchor[0] = 1.0
    scale = max(float(np.trace(gram) / max(len(gram), 1)), 1e-12)
    penalized = gram + ridge * scale * np.eye(len(gram), dtype=np.float64)
    lipschitz = max(2.0 * float(np.linalg.eigvalsh(penalized).max()), 1e-12)
    weights = anchor.copy()
    for _ in range(500):
        gradient = 2.0 * gram @ weights + 2.0 * ridge * scale * (weights - anchor)
        updated = project_simplex(weights - gradient / lipschitz)
        if np.max(np.abs(updated - weights)) < 1e-10:
            weights = updated
            break
        weights = updated
    return weights


def fit_horizon_weights(predictions: np.ndarray, target: np.ndarray, ridge: float) -> np.ndarray:
    errors = predictions - target[None]
    return np.stack(
        (
            fit_simplex(errors[:, :, :15], ridge),
            fit_simplex(errors[:, :, :30], ridge),
            fit_simplex(errors[:, :, :180], ridge),
        )
    )


def expanded_weights(knot_weights: np.ndarray) -> np.ndarray:
    output = np.empty((180, knot_weights.shape[1]), dtype=np.float64)
    output[:15] = knot_weights[0]
    for step in range(15, 30):
        alpha = (step - 14) / 15.0
        output[step] = (1.0 - alpha) * knot_weights[0] + alpha * knot_weights[1]
    for step in range(30, 180):
        alpha = (step - 29) / 150.0
        output[step] = (1.0 - alpha) * knot_weights[1] + alpha * knot_weights[2]
    output /= np.maximum(output.sum(axis=1, keepdims=True), 1e-12)
    return output


def blend(predictions: np.ndarray, knot_weights: np.ndarray) -> np.ndarray:
    weights = expanded_weights(knot_weights)
    return np.einsum("knte,tk->nte", predictions, weights).astype(np.float32)


def goal(metrics: dict, reference: dict) -> float:
    return float(
        (
            metrics["ADE@5"] / reference["ADE@5"]
            + metrics["ADE@10"] / reference["ADE@10"]
            + 2.0 * metrics["ADE@60"] / reference["ADE@60"]
        )
        / 4.0
    )


def group_folds(mmsi: np.ndarray, seed: int) -> list[np.ndarray]:
    unique = np.unique(mmsi)
    rng = np.random.default_rng(seed)
    rng.shuffle(unique)
    assignment = {int(identifier): index % 3 for index, identifier in enumerate(unique)}
    return [np.asarray([assignment[int(value)] == fold for value in mmsi]) for fold in range(3)]


def choose_committee(predictions: dict[str, np.ndarray], target: np.ndarray, mmsi: np.ndarray, seed: int):
    reference = displacement_metrics(predictions["sa_repair"], target)
    optional = [name for name in CANDIDATES if name != "sa_repair"]
    subsets = [("sa_repair",)]
    for count in (1, 2):
        subsets.extend(("sa_repair",) + combo for combo in itertools.combinations(optional, count))
    folds = group_folds(mmsi, seed)
    ranking = []
    for subset in subsets:
        stacked = np.stack([predictions[name] for name in subset])
        for ridge in (0.0, 0.01, 0.05, 0.20):
            scores = []
            for held_out in folds:
                training = ~held_out
                if not training.any() or not held_out.any():
                    continue
                weights = fit_horizon_weights(stacked[:, training], target[training], ridge)
                held_prediction = blend(stacked[:, held_out], weights)
                held_metrics = displacement_metrics(held_prediction, target[held_out])
                held_reference = displacement_metrics(predictions["sa_repair"][held_out], target[held_out])
                scores.append(goal(held_metrics, held_reference))
            if not scores:
                continue
            objective = float(np.mean(scores) + 0.25 * np.std(scores) + 0.002 * (len(subset) - 1))
            ranking.append(
                {
                    "candidates": list(subset),
                    "ridge": ridge,
                    "fold_scores": scores,
                    "cv_objective": objective,
                }
            )
    ranking.sort(key=lambda row: row["cv_objective"])
    chosen = ranking[0]
    # Demand an out-of-fold gain beyond numerical noise before adding models.
    if chosen["cv_objective"] >= 0.998:
        chosen = next(row for row in ranking if row["candidates"] == ["sa_repair"])
    selected_predictions = np.stack([predictions[name] for name in chosen["candidates"]])
    weights = fit_horizon_weights(selected_predictions, target, float(chosen["ridge"]))
    validation_prediction = blend(selected_predictions, weights)
    return chosen, weights, displacement_metrics(validation_prediction, target), ranking[:10]


def load_test_prediction(run: Path, candidate: str) -> tuple[np.ndarray, np.ndarray]:
    path = run / "test_predictions.npz"
    if not path.exists():
        raise FileNotFoundError(path)
    data = np.load(path)
    key = "raw_prediction" if candidate == "sa_repair" and "raw_prediction" in data else "prediction"
    return data[key].astype(np.float32), data["target"].astype(np.float32)


def source_model_metrics(output: Path, recipe_name: str, domain: str, seed: int) -> dict:
    rows = {}
    for candidate in CANDIDATES:
        prediction, target = load_test_prediction(
            run_path(output, recipe_name, candidate, domain, seed), candidate
        )
        rows[candidate] = displacement_metrics(prediction, target)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Seed-aligned validation-only compact committee")
    parser.add_argument("--output", type=Path, default=ROOT / "eight_hour_diagnostic")
    parser.add_argument("--num-workers", type=int, default=2)
    parser.add_argument("--stage1-preflight", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    final_recipe_path = output / "final_recipe.json"
    if args.stage1_preflight:
        recipe = {"name": "__stage1__", "description": "Stage-1 SA-MoE committee preflight"}
    else:
        if not final_recipe_path.exists():
            raise FileNotFoundError(final_recipe_path)
        recipe = json.loads(final_recipe_path.read_text(encoding="utf-8"))["recipe"]
    recipe_name = recipe["name"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_results = []
    for domain in DOMAINS:
        scaler = RobustTrajectoryScaler.load(ROOT / "cache" / domain / "scaler.json")
        source = resolve_split_file(ROOT.parent / "data", domain, "val")
        cache = build_cache(source, ROOT / "cache" / domain, force=False)
        dataset = EnvShipDataset(cache, scaler)
        for seed in SEEDS:
            validation_paths = {
                candidate: collect_validation(
                    output,
                    recipe_name,
                    candidate,
                    domain,
                    seed,
                    dataset,
                    scaler,
                    device,
                    args.num_workers,
                )
                for candidate in CANDIDATES
            }
            loaded = {name: np.load(path) for name, path in validation_paths.items()}
            target = loaded["sa_repair"]["target"].astype(np.float32)
            mmsi = loaded["sa_repair"]["mmsi"].astype(np.int64)
            predictions = {name: data["prediction"].astype(np.float32) for name, data in loaded.items()}
            for name, data in loaded.items():
                if data["target"].shape != target.shape or not np.allclose(data["target"], target, atol=1e-3):
                    raise RuntimeError(f"Validation alignment mismatch: {domain}/{seed}/{name}")
            chosen, weights, validation_metrics, cv_ranking = choose_committee(
                predictions, target, mmsi, seed
            )
            selection_path = output / "committee" / domain / f"seed_{seed}" / "selection.json"
            atomic_json(
                selection_path,
                {
                    "domain": domain,
                    "seed": seed,
                    "algorithm": "grouped-3-fold nonnegative simplex, maximum three models",
                    "candidate_pool": list(CANDIDATES),
                    "selected": chosen,
                    "knot_weights_5_10_60": weights.tolist(),
                    "validation_metrics": validation_metrics,
                    "top_cv_candidates": cv_ranking,
                    "test_predictions_read_before_selection": False,
                },
            )

            selected_test, test_target = [], None
            for candidate in chosen["candidates"]:
                prediction, candidate_target = load_test_prediction(
                    run_path(output, recipe_name, candidate, domain, seed), candidate
                )
                if test_target is None:
                    test_target = candidate_target
                elif candidate_target.shape != test_target.shape or not np.allclose(
                    candidate_target, test_target, atol=1e-3
                ):
                    raise RuntimeError(f"Test alignment mismatch: {domain}/{seed}/{candidate}")
                selected_test.append(prediction)
            committee_prediction = blend(np.stack(selected_test), weights)
            test_metrics = displacement_metrics(committee_prediction, test_target)
            sources = source_model_metrics(output, recipe_name, domain, seed)
            result = {
                "domain": domain,
                "seed": seed,
                "selected_candidates": chosen["candidates"],
                "weights": weights.tolist(),
                "validation": validation_metrics,
                "test": test_metrics,
                "source_test_metrics": sources,
            }
            atomic_json(selection_path.parent / "result.json", result)
            np.savez_compressed(
                selection_path.parent / "test_predictions.npz",
                prediction=committee_prediction,
                target=test_target,
            )
            all_results.append(result)
            print(json.dumps(result, ensure_ascii=False), flush=True)

    aggregate = {}
    for domain in DOMAINS:
        rows = [row for row in all_results if row["domain"] == domain]
        aggregate[domain] = {
            metric: {
                "mean": float(np.mean([row["test"][metric] for row in rows])),
                "std": float(np.std([row["test"][metric] for row in rows], ddof=0)),
            }
            for metric in METRICS
        }
        aggregate[domain]["selected_candidates_by_seed"] = {
            str(row["seed"]): row["selected_candidates"] for row in rows
        }
    atomic_json(
        output / "committee" / "summary.json",
        {
            "complete": len(all_results) == len(DOMAINS) * len(SEEDS),
            "protocol": {
                "seeds": list(SEEDS),
                "domains": list(DOMAINS),
                "same_candidate_pool_and_algorithm_all_domains": True,
                "cross_seed_ensembling": False,
                "historical_version_ensembling": False,
                "selection": "validation only; grouped three-fold CV",
                "automated_selection_reads_test": False,
                "historical_test_results_previously_observed": True,
                "publication_note": "Use a sealed holdout for a fully unbiased final claim.",
            },
            "repair_recipe": recipe,
            "aggregate": aggregate,
            "runs": all_results,
        },
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
