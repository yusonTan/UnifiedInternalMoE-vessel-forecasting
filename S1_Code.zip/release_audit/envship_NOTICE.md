# NOTICE — MARIS-Forecast attributions

This directory packages four jurisdictional AIS sub-datasets plus a derived
processing pipeline. Each upstream provider must be credited when their data
is used. The following attribution lines are recommended for any paper,
release, or product that builds on this benchmark.

## Required attributions

### DMA — Danish Maritime Authority
> Contains AIS data from the Danish Maritime Authority (DMA), aisdk-2025-09,
> made available as Danish public-sector information under the Act no. 596 of
> 24 June 2005 on the further use of public-sector information (the PSI Act).
> The DMA provides the data free of charge and without warranty as to
> correctness, and the data may not be combined so as to identify persons
> without a permit. (This is **not** a Creative Commons licence.) Source:
> https://www.dma.dk/safety-at-sea/navigational-information/ais-data

### NOAA — National Oceanic and Atmospheric Administration / MarineCadastre
> Contains AIS data from the U.S. National Oceanic and Atmospheric
> Administration (NOAA), MarineCadastre AIS, March 2025. This is a U.S.
> government work in the public domain. Source: https://marinecadastre.gov

### Piraeus — University of Piraeus / Tritsarolis et al.
> Contains the Piraeus AIS Dataset for Large-scale Maritime Data Analytics by
> Tritsarolis, Kontoulis & Theodoridis (2022). DOI:
> 10.5281/zenodo.6323416. Released under CC BY 4.0.

### Norway — Kystverket (Norwegian Coastal Administration)
> Contains data under the Norwegian Licence for Open Government Data (NLOD 2.0)
> distributed by Kystverket (Kystdatahuset). https://kystdatahuset.no/

### OpenStreetMap (environmental rasters, signed-distance fields, vectors, OSM-derived columns)
> Map data &copy; OpenStreetMap contributors, available under the Open
> Database License (ODbL). https://www.openstreetmap.org/copyright
> All OSM-derived artefacts are ODbL and carry the ODbL **share-alike**
> obligation — see [`LICENSE-DATA.md`](LICENSE-DATA.md), Section 3, for the
> exact list of ODbL files and columns.

### Geofabrik historical extracts
> Historical OSM data (e.g. `greece-200101.osm.pbf`) is sourced from
> Geofabrik's archive of OpenStreetMap snapshots and remains subject to
> ODbL.

### ERA5 / ECMWF (weather and sea-state columns)
> Contains modified Copernicus Climate Change Service information (ERA5) and
> ECMWF WAM data, obtained via Open-Meteo. The `met_*` and `sea_*` columns are
> governed by the Copernicus/ECMWF terms and Open-Meteo's terms; neither the
> Copernicus Climate Change Service nor ECMWF is responsible for any use of the
> derived information. https://open-meteo.com

## Citations to use in research papers

Cite MARIS-Forecast plus the upstream sub-datasets that were used. The exact
per-file licence mapping is in [`LICENSE-DATA.md`](LICENSE-DATA.md).

## Provenance summary

| Subset  | Raw year(s)       | Provider            | Upstream licence / terms |
|---------|-------------------|---------------------|--------------------------|
| DMA     | 2025-09           | Danish Maritime Authority   | Danish PSI Act (act 596/2005); free reuse, no warranty, no re-identification |
| NOAA    | 2025-03           | NOAA / MarineCadastre       | U.S. public domain |
| Piraeus | 2019-01..2019-12  | Tritsarolis et al. (Zenodo) | CC BY 4.0 |
| Norway  | 2025-08..2025-09  | Kystverket                  | NLOD 2.0 |
| Environmental context | — | OpenStreetMap / Geofabrik   | **ODbL (share-alike)** |
| Weather & sea state   | — | ERA5 / ECMWF WAM via Open-Meteo | Copernicus / ECMWF terms |

The four AIS entries are verified from the raw filenames and the first-row
timestamps of `standard_track_v1/train/part-000.csv.gz`.
