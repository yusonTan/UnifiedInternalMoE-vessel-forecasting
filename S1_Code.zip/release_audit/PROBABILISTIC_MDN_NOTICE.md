# BLSTM–MDN attribution and adaptation notice

Architecture reference: Sørensen, K. A., Heiselberg, P., and Heiselberg, H. (2022).
Probabilistic Maritime Trajectory Prediction in Complex Scenarios Using Deep Learning.
Sensors 22(5), 2058. https://doi.org/10.3390/s22052058

Author repository commit: 30d0fff34a9bc0384efab47e3f0d3e3a0e120c5c.
https://github.com/aalling93/probabilistic-maritime-trajectory-prediction-in-complex-scenarios-using-deep-learning

The new implementation follows paper Fig. 2, NOT the disconnected branch in the
public TensorFlow code. It is a common-task adaptation, not exact original-task
replication and not a claim of current state of the art. No upstream weights are used.

Changes: six EnvShip input channels/local coordinates; 90-step history at 20 seconds;
joint diagonal Gaussian mixture over a direct 180x2 future instead of four-feature
single-step recursion; float32 logsumexp likelihood; positive scale floor .001 in
training-scaled coordinates; trainable BN (paper description) rather than frozen
BN (author code); LeCun-normal input kernels, orthogonal recurrent gates and forget
bias 1; AdamW 1e-4 weight decay in place of source-specific L1/activity penalties;
lr .0005, 10-epoch cosine warm restarts, peak decay .7 per restart and floor 1e-8;
maximum 120 epochs, patience 50, validation trajectory NLL per coordinate selection;
AMP encoder; gradient norm clipping 1; hardware-profiled batch size rather than 3000.
Formal experiments use full 456/256 widths, 11 components, .3 dropout.
Small widths used in unit tests are not formal comparator results.

Paper batch3000, notebook batch400, and source initialization do not agree. These
changes must remain explicit in the revised paper and reproduction README.
Main ADE/FDE uses the conditional mean, never a ground-truth-selected sample.

MIT License (upstream notice retained for attribution):

Copyright (c) 2021 Kristian Aalling Sørensen

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
