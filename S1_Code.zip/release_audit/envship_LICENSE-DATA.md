# MARIS-Forecast — Data license and per-file license mapping

> This file governs the **MARIS-Forecast dataset** distributed here. The
> accompanying **source code** is separate, at
> <https://github.com/mark000071/Envship_Framework_vessel_traj_pred>, under the
> MIT License.

MARIS-Forecast is a *composite* release: different files, and different columns
within a single table, are derived from different upstream sources and therefore
carry **different licences**. The mapping below is authoritative. When you
redistribute all or part of the data, apply the licence that governs the
specific files/columns you use, preserve the attribution notices in
[`NOTICE.md`](NOTICE.md), and — for any OpenStreetMap-derived content — comply
with the ODbL share-alike obligation described in Section 3.

---

## 1. Upstream AIS source licences (trajectory / kinematic content)

The vessel-trajectory tables (per-split `part-000.csv.gz`) and the social-context
records are derived **only** from the AIS feed of their region and follow that
feed's terms:

| Region | Directory prefix | Source & terms |
|---|---|---|
| **Denmark (DMA)** | `*dma*` | **Danish public-sector information** — released by the Danish Maritime Authority under the Danish *Act no. 596 of 24 June 2005 on the further use of public-sector information (the PSI Act)*. Free to download and reuse, **with no warranty** ("The Danish Maritime Authority does not guarantee the correctness of the AIS data … and is not liable for any damages"), and on the condition that the data are **not combined so as to identify persons without a permit**. **This is *not* a Creative Commons licence.** Source: <https://www.dma.dk/safety-at-sea/navigational-information/ais-data> |
| **United States (NOAA)** | `*noaa*` | **U.S. Government work in the public domain** (no copyright). NOAA/BOEM MarineCadastre. Source: <https://marinecadastre.gov/ais/> |
| **Greece (Piraeus)** | `*piraeus*` | **CC BY 4.0** — Tritsarolis, Kontoulis & Theodoridis (2022), Zenodo DOI 10.5281/zenodo.6323416. |
| **Norway (Kystverket)** | `*norway*` | **NLOD 2.0** (Norwegian Licence for Open Government Data). Kystverket / Kystdatahuset, <https://kystdatahuset.no/>. |

## 2. Reanalysis-derived columns (weather & sea state)

The fifteen anchor-time context scalars include six weather columns (`met_*`)
and four sea-state columns (`sea_*`). These are derived from the **ERA5**
reanalysis (Copernicus Climate Change Service / ECMWF) and the **ECMWF WAM**
wave model, obtained via the **Open-Meteo** archive. They are governed by the
[Copernicus licence](https://apps.ecmwf.int/datasets/licences/copernicus/) /
ECMWF terms and Open-Meteo's terms (attribution to Copernicus/ECMWF and
Open-Meteo). "Contains modified Copernicus Climate Change Service information."

## 3. OpenStreetMap-derived content — **ODbL (share-alike)**

All environmental context artefacts are **derivative databases of OpenStreetMap**
and are distributed under the **Open Database License v1.0 (ODbL)**, © OpenStreetMap
contributors. **ODbL is share-alike:** if you publicly use a *Derivative Database*
that incorporates any of these files/columns, you must license that Derivative
Database under ODbL and keep the OpenStreetMap attribution. This obligation is
**not** waived by the "composite" nature of the release.

The following files and columns are ODbL:

| Artefact (relative to a leaf) | Kind |
|---|---|
| `context_v1/environment/rasters/<split>/masks.npz` | six-channel OSM land/water/navigable/boundary/barrier raster |
| `context_v1/environment/rasters/<split>/signed_dist_shore.npy` | shore signed-distance field |
| `context_v1/environment/rasters/<split>/signed_dist_nav.npy` | navigable-water signed-distance field |
| `context_v1/environment/vectors/<split>/vectors.jsonl.gz` | clipped OSM shoreline / waterway / pier / quay / breakwater polylines |
| `context_v1/environment/features/<split>/environment_descriptors.csv` | OSM-derived scene descriptors (scene type, water/navigable ratios, boundary densities, env-quality score) |
| `context_v1_2019osm/**` (Piraeus) | historical-OSM (2020-01-01) rebuild of the above |
| `osm_temporal_consistency/<split>_flags.csv` | Stage-17 flags computed from the OSM shore SDF |
| **Inline columns** in `<split>/part-000.csv.gz`: `port_nearest_dist_km`, `port_nearest_name`, `in_fairway`, `dist_to_fairway_m`, `in_tss`, `osm_temporal_consistent`, `osm_max_inland_depth_m`, `osm_n_inland_points`, `osm_max_consec_inland_run` | OSM-derived port / fairway / TSS / consistency columns |

Historical OSM extracts (e.g. `greece-200101.osm.pbf`) are courtesy of
[Geofabrik](https://download.geofabrik.de/) and are likewise OSM under ODbL.

## 4. Mixed tables — how the split CSV is licensed by column

Each `part-000.csv.gz` (and the merged `augmented/<split>/part-000.csv.gz`) is a
**mixed table**:

- **AIS-derived columns** — identifiers, local-metre geometry (`hist_*`, `fut_*`),
  kinematics (`*_sog_json`, `*_cog_*`, `*_heading_*`), quality scalars, `split` —
  follow the **region's AIS source licence** (Section 1).
- **Reanalysis columns** — `met_*`, `sea_*` — Section 2.
- **OSM-derived columns** — the port/fairway/TSS/consistency columns listed in
  Section 3 — are **ODbL**.

A Derivative Database that retains the OSM-derived columns or the context tensors
must be released under **ODbL** (Section 3). If you keep only the AIS-derived
trajectory columns and drop all OSM-derived content, ODbL does not attach and
the region's AIS source licence governs.

## 5. Attribution

Regardless of which subset you use, preserve the attribution notices in
[`NOTICE.md`](NOTICE.md) and attribute every upstream source listed there.
Map data © OpenStreetMap contributors, ODbL. Contains modified Copernicus
Climate Change Service information (ERA5) and ECMWF data via Open-Meteo.
