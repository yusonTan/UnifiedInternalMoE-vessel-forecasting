"""Scientific figure generation only; Word editing uses the bundled runtime."""
from pathlib import Path
import csv,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
OUT=BASE/'regenerated_figures';OUT.mkdir(parents=True,exist_ok=True)
def rows(p):
 with Path(p).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
main=rows(BASE/'results/main10/four_domain_10seed_mean_std.csv');external=rows(BASE/'results/independent5/independent_mean_std.csv');primary=rows(BASE/'results/main10/primary_ADE_paired_uncertainty.csv');mac=rows(BASE/'results/internal5/macro_objectives.csv')
models=('UnifiedInternalMoE_10seed_refit','sa_repair','transformer_cv','itransformer_fa_faithful','mstformer_faithful','direct_gru','direct_lstm','tcn_cv')
labels=dict(zip(models,('UnifiedInternalMoE','SA-Repair','Transformer-CV','iTransformer-FA','MSTFormer','Direct-GRU','Direct-LSTM','TCN-CV')));labels['UnifiedInternalMoE']='UnifiedInternalMoE'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9});colors=plt.get_cmap('tab10').colors
fig,axes=plt.subplots(2,2,figsize=(10.5,7),layout='constrained')
for ax,d in zip(axes.flat,('dma','noaa','norway','piraeus')):
 for i,m in enumerate(models):
  r=next(r for r in main if r['domain']==d and r['model']==m);x=np.array([5,10,20,30,45,60]);y=np.array([float(r[f'ADE@{h}_mean']) for h in x]);sd=np.array([float(r[f'ADE@{h}_std']) for h in x])
  ax.plot(x,y,label=labels[m],color=colors[i],lw=1.8 if i==0 else 1);ax.fill_between(x,y-sd,y+sd,color=colors[i],alpha=.08)
 ax.set_title(d.upper() if d in ('dma','noaa') else d.title());ax.set_xlabel('Forecast horizon (min)');ax.set_ylabel('ADE (m)');ax.grid(alpha=.2)
handles,ll=axes[0,0].get_legend_handles_labels();fig.legend(handles,ll,loc='outside lower center',ncol=4,frameon=False);fig.savefig(OUT/'Fig4_ten_seed_curves.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(10,5),layout='constrained');vals=np.array([float(r['difference_m_comparator_minus_final']) for r in primary]);lo=np.array([float(r['crossed_CI_low']) for r in primary]);hi=np.array([float(r['crossed_CI_high']) for r in primary]);ix=np.arange(len(vals))
ax.errorbar(vals,ix,xerr=np.maximum(0,np.stack([vals-lo,hi-vals])),fmt='o',capsize=3,color='#245b80');ax.axvline(0,color='black',lw=.8);ax.set_yticks(ix,[r['domain'].title()+' '+r['metric'] for r in primary]);ax.invert_yaxis();ax.set_xlabel('Comparator minus fusion error (m); conditional crossed 95% interval');ax.grid(axis='x',alpha=.2);fig.savefig(OUT/'Fig5_uncertainty.png',dpi=220);plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(10.4,4.2),layout='constrained')
for ax,family in zip(axes,('SA_only','whole_fusion')):
 rr=[r for r in mac if r['family']==family and r['variant']!='full'];yy=[float(r['relative_to_full_percent']) for r in rr];ax.barh([r['variant'] for r in rr],yy,color=['#b6584e' if y>0 else '#39816e' for y in yy]);ax.axvline(0,color='black',lw=.8);ax.set_title(family.replace('_',' '));ax.set_xlabel('Change from full (%)\nPositive: removing component is worse');ax.grid(axis='x',alpha=.2)
fig.savefig(OUT/'Fig6_internal_ablation.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(10.5,4.2),layout='constrained');rr=[r for r in external if r['mode']=='independently_trained'];ax.bar(np.arange(len(rr)),[float(r['ADE@60_mean']) for r in rr],yerr=[float(r['ADE@60_std']) for r in rr],capsize=3,color=[colors[0] if r['model']=='UnifiedInternalMoE' else '#8397a3' for r in rr]);ax.set_xticks(np.arange(len(rr)),[labels[r['model']] for r in rr],rotation=25,ha='right');ax.set_ylabel('Independent Finnish ADE@60 (m)');ax.grid(axis='y',alpha=.2);fig.savefig(OUT/'Fig7_external.png',dpi=220);plt.close(fig)
