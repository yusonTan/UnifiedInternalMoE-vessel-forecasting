# Vessel trajectory forecasting revision reproducibility package

The lightweight code and numerical-table archives are publicly available at
https://github.com/yusonTan/UnifiedInternalMoE-vessel-forecasting.
Large prediction arrays and checkpoints in the full local bundle are not included
in that repository. No project-specific DOI has been minted.
The completed experiments and their numerical outputs are preserved. No model is
retrained or selected while assembling this package.

## Quick checks

From this directory, using Python 3.11:

    python reproduce.py verify
    python reproduce.py tables --out regenerated
    python reproduce.py external-metrics
    python reproduce.py smoke
    python reproduce.py infer --domain finland --seed 42 --limit 2 --out replay.npy
    python plot_revision.py

`tables` uses the standard library. `external-metrics` requires NumPy. Model
smoke/inference require PyTorch and scientific dependencies. Install in a fresh
environment with `python -m pip install -r requirements.txt`. The audited training
environment used torch 2.6.0+cu124 and an RTX 3060 Laptop GPU; choose the CUDA wheel
appropriate to the machine. Do not replace the local training environment merely
to inspect these files. Full retraining and bitwise cross-device replay have not
been rerun as part of this packaging task.

## Distinct cohorts

* `results/main10`: four domains, ten seeds, seven backbones plus the final fusion.
* `results/routes10`: ten-seed router, anchor and alternative-objective controls;
  five-seed internal-uniform controls are explicitly identified in their tables.
* `results/internal5`: eight internal variants, four domains, five seeds.
* `results/capacity10`: ten-seed Wide-GRU and cost controls.
* `results/transfer10`: twelve source-target directions, ten seeds, eight predictors.
* `results/independent5`: Finnish independent AIS, five seeds. Set A is frozen
  source-only transfer; Set B independently trains the same architecture.
* `results/probability5`: adapted BLSTM-MDN and corresponding five-seed controls.
* `results/diagnostic3`: explicitly historical three-seed diagnostics.

Do not pool seed counts or substitute the five-seed fusion for the ten-seed model.
Sample SD uses ddof=1. Deterministic CV15 has no invented training-seed SD.

## Inputs, fitting and evaluation

Input is 90x6 and output 180x2, at a 20-second cadence. Channels are anchor-centred
east/north metres, UTC time-of-day sine, SOG in knots and COG sine/cosine. Models
are fitted separately by region. Outer final routing is horizon-dependent convex
stacking; sample correction is zero. Internal SA routing remains input-dependent.
Candidate subsets include SA plus at most two other experts. Ridge pulls toward
the SA vertex; prefix squared error is fitted at 5/10/60 minutes. The shared
short-specialist rule creates cross-seed selection dependence. MMSI resampling
and crossed intervals condition on those choices; few-cluster inference is approximate.

`paired_errors/main10` holds all 320 aligned per-window error sets. Full trajectory
arrays for all 200 independent evaluation groups are in `independent_predictions`.
Nine final checkpoints are supplied: EnvShip seed42 for each domain, and all five
Finnish fusion checkpoints. Other trained checkpoints are not included. The
recorded state, config and scaler must be loaded together. Only load trusted
PyTorch checkpoints; these files are native research serialization, not a safe
format for arbitrary untrusted inputs.

## Data acquisition and optional training

EnvShip v2 Track B is publicly distributed at
https://huggingface.co/datasets/mark000071/envship_v2_datasets and described by
arXiv:2606.15240. Its composite upstream terms and attribution notices are recorded
in DATA_RIGHTS.md and release_audit/. This package does not relicense the source
data. Build canonical caches with:

    python reproduce.py prepare-envship --data PATH_TO_RELEASE --out work/cache

The public Finnish source is https://zenodo.org/records/8112336 (CC BY 4.0).
`data_manifests/finland` contains the fixed first available seven-day plan,
catalogue and CRC/SHA receipts. The archive contains decoded headerless dynamic
rows. Longitude/latitude are degrees; SOG is knots; `timestampExternal` is absolute
milliseconds. `timestamp` alone is not an epoch. The original full archive is not
redistributed and its published full MD5 was not verified by downloading 43.6 GB.
The required seven ZIP members were independently checked. With canonical
EnvShip caches available, the same raw-data preparation can be invoked with:

    python reproduce.py prepare-finland --envship-cache work/cache --out work/finland

This downloads the fixed public members and excludes the union of all source
MMSIs. It is a network/disk-consuming action; it is not part of the quick checks.
The split rule is MD5(MMSI)%10: 0 validation, 1 test, others training. Future
quality support is screened but future positions are not used as history input.
No future difficulty/model-error filter chooses dates or windows.

Use `configuration_index.csv` to identify an actual model/seed configuration.
`train-one` takes caller-provided train/val cache paths and explicit config paths:

    python reproduce.py train-one --model direct_gru --seed 42 --cache DOMAIN_CACHE --config CONFIG_JSON --out NEW_WORK

SA needs `--stage pretrain`, followed by `--stage repair --pretrained BEST_PRETRAIN_PT`.
The caches can contain train/val or domain_train/domain_val subdirectories.
CUDA is required by this original training adapter. Repair has a recorded
wall-clock cap, so a different machine need not reproduce identical epoch counts.
Use validation only for selection; these commands never evaluate formal test.
Legacy SA stage files named `test_*` are validation proxies, not formal results.
After training all seven backbones for each declared seed under NEW_WORK, fit
routes with `python reproduce.py fit-routes --out NEW_WORK --seeds 42 52 62 72 82`.
The adapter preserves model architectures and training functions; historical
cohort launchers in `source_snapshot` contain original machine paths and are
provenance snapshots, not portable one-command launchers.

## Upload candidates and unresolved release steps

S1_Code.zip and S1_Data.zip are separate small upload candidates. Extract both
into the same directory, then use `python reproduce.py verify --manifest CORE_MANIFEST.json`.
They do not contain the large paired arrays, full independent trajectories,
checkpoints or local replay inputs. Those assets remain in the full local bundle.
The full MANIFEST covers those local assets; CORE_MANIFEST covers the small pair.

The author-owned code licence awaits rights-holder confirmation; MIT is proposed.
The upstream data permissions have been checked and recorded in DATA_RIGHTS.md.
The lightweight archives have been published to the GitHub repository above.
No project-specific DOI has been reserved or minted.
The source data DOI is not the DOI of this code package.
